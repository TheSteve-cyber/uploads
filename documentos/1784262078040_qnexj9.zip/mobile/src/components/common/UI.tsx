import React from 'react';
import {
  View, Text, Pressable, StyleSheet, ViewStyle, TextStyle, StyleProp, ActivityIndicator,
} from 'react-native';
import { useTheme } from '../../theme/useTheme';
import { spacing, radius, typography, elevation } from '../../theme/tokens';

// ── Card ──────────────────────────────────────────────────────────────────────

export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const { colors } = useTheme();
  return (
    <View
      style={[
        {
          backgroundColor: colors.surface,
          borderRadius: radius.lg,
          padding: spacing.lg,
          borderWidth: 1,
          borderColor: colors.border,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

// ── Button ────────────────────────────────────────────────────────────────────

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

export function Button({
  label, onPress, variant = 'primary', loading, disabled, icon, style,
}: ButtonProps) {
  const { colors } = useTheme();

  const variantStyles: Record<string, { bg: string; text: string; border?: string }> = {
    primary: { bg: colors.accent, text: '#FFFFFF' },
    secondary: { bg: colors.surfaceAlt, text: colors.textPrimary, border: colors.border },
    ghost: { bg: 'transparent', text: colors.accent },
    danger: { bg: colors.danger, text: '#FFFFFF' },
  };

  const v = variantStyles[variant];
  const isDisabled = disabled || loading;

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: v.bg,
          borderWidth: v.border ? 1 : 0,
          borderColor: v.border,
          opacity: isDisabled ? 0.5 : pressed ? 0.85 : 1,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={v.text} />
      ) : (
        <View style={styles.buttonContent}>
          {icon}
          <Text style={[styles.buttonLabel, { color: v.text }]}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
}

// ── Progress Bar ──────────────────────────────────────────────────────────────

export function ProgressBar({ progress, color, trackColor, height = 6 }: {
  progress: number; // 0–100
  color?: string;
  trackColor?: string;
  height?: number;
}) {
  const { colors } = useTheme();
  return (
    <View
      style={{
        height,
        borderRadius: height / 2,
        backgroundColor: trackColor ?? colors.surfaceAlt,
        overflow: 'hidden',
      }}
    >
      <View
        style={{
          width: `${Math.max(0, Math.min(100, progress))}%`,
          height: '100%',
          borderRadius: height / 2,
          backgroundColor: color ?? colors.accent,
        }}
      />
    </View>
  );
}

// ── Stat Block (departures-board style number + label) ────────────────────────

export function StatBlock({ value, label, accent }: {
  value: string | number;
  label: string;
  accent?: boolean;
}) {
  const { colors } = useTheme();
  return (
    <View style={styles.statBlock}>
      <Text
        style={[
          styles.statValue,
          { color: accent ? colors.accent : colors.textPrimary },
        ]}
      >
        {value}
      </Text>
      <Text style={[styles.statLabel, { color: colors.textMuted }]}>{label}</Text>
    </View>
  );
}

// ── Badge ─────────────────────────────────────────────────────────────────────

export function Badge({ label, tone = 'neutral' }: {
  label: string;
  tone?: 'neutral' | 'success' | 'warning' | 'danger' | 'accent';
}) {
  const { colors } = useTheme();
  const toneMap = {
    neutral: { bg: colors.surfaceAlt, text: colors.textSecondary },
    success: { bg: colors.successSoft, text: colors.success },
    warning: { bg: '#FDF0DC', text: colors.warning },
    danger: { bg: '#FBE2E2', text: colors.danger },
    accent: { bg: colors.accentSoft, text: colors.accent },
  };
  const t = toneMap[tone];

  return (
    <View style={[styles.badge, { backgroundColor: t.bg }]}>
      <Text style={[styles.badgeText, { color: t.text }]}>{label}</Text>
    </View>
  );
}

// ── Screen Header ─────────────────────────────────────────────────────────────

export function ScreenHeader({ title, subtitle, right }: {
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
}) {
  const { colors } = useTheme();
  return (
    <View style={styles.header}>
      <View style={{ flex: 1 }}>
        <Text style={[styles.headerTitle, { color: colors.textPrimary }]}>{title}</Text>
        {subtitle && (
          <Text style={[styles.headerSubtitle, { color: colors.textMuted }]}>{subtitle}</Text>
        )}
      </View>
      {right}
    </View>
  );
}

// ── Empty State ───────────────────────────────────────────────────────────────

export function EmptyState({ icon, title, message, action }: {
  icon?: React.ReactNode;
  title: string;
  message: string;
  action?: React.ReactNode;
}) {
  const { colors } = useTheme();
  return (
    <View style={styles.emptyState}>
      {icon}
      <Text style={[styles.emptyTitle, { color: colors.textPrimary }]}>{title}</Text>
      <Text style={[styles.emptyMessage, { color: colors.textMuted }]}>{message}</Text>
      {action}
    </View>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  buttonLabel: {
    fontSize: typography.scale.body,
    fontWeight: '600',
  },
  statBlock: {
    alignItems: 'flex-start',
  },
  statValue: {
    fontSize: typography.scale.h1,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
  },
  statLabel: {
    fontSize: typography.scale.micro,
    textTransform: 'uppercase',
    letterSpacing: 0.6,
    marginTop: 2,
  },
  badge: {
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: radius.pill,
    alignSelf: 'flex-start',
  },
  badgeText: {
    fontSize: typography.scale.micro,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.md,
  },
  headerTitle: {
    fontSize: typography.scale.h1,
    fontWeight: '700',
  },
  headerSubtitle: {
    fontSize: typography.scale.body,
    marginTop: 2,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxxl,
    paddingHorizontal: spacing.xl,
  },
  emptyTitle: {
    fontSize: typography.scale.h3,
    fontWeight: '700',
    marginTop: spacing.lg,
  },
  emptyMessage: {
    fontSize: typography.scale.body,
    textAlign: 'center',
    marginTop: spacing.xs,
    lineHeight: 20,
  },
});
