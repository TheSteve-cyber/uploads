import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated, Easing } from 'react-native';
import { useTheme } from '../../theme/useTheme';

interface SyncBeaconProps {
  active: boolean;
  size?: number;
  color?: string;
}

/**
 * The signature element: a pulsing dot-and-ring, echoing a GPS ping on a
 * tracker map. Appears next to anything actively syncing.
 */
export function SyncBeacon({ active, size = 10, color }: SyncBeaconProps) {
  const { colors } = useTheme();
  const beaconColor = color ?? colors.accent;
  const scale = useRef(new Animated.Value(1)).current;
  const opacity = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    if (!active) {
      scale.setValue(1);
      opacity.setValue(0);
      return;
    }

    const loop = Animated.loop(
      Animated.parallel([
        Animated.timing(scale, {
          toValue: 2.4,
          duration: 1400,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0,
          duration: 1400,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    );

    scale.setValue(1);
    opacity.setValue(0.6);
    loop.start();

    return () => loop.stop();
  }, [active, scale, opacity]);

  return (
    <View style={[styles.container, { width: size * 3, height: size * 3 }]}>
      {active && (
        <Animated.View
          style={[
            styles.ring,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              borderColor: beaconColor,
              transform: [{ scale }],
              opacity,
            },
          ]}
        />
      )}
      <View
        style={[
          styles.dot,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: active ? beaconColor : colors.textMuted,
          },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  dot: {
    position: 'absolute',
  },
  ring: {
    position: 'absolute',
    borderWidth: 1.5,
  },
});
