import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, ActivityIndicator } from 'react-native';
import { useTheme } from '../theme/useTheme';
import { useAuth } from '../contexts/AuthContext';

import SignInScreen from '../screens/SignInScreen';
import HomeScreen from '../screens/HomeScreen';
import StartTripScreen from '../screens/StartTripScreen';
import EndTripConfirmScreen from '../screens/EndTripConfirmScreen';
import TripSummaryScreen from '../screens/TripSummaryScreen';
import UploadQueueScreen from '../screens/UploadQueueScreen';
import MainTabNavigator from './MainTabNavigator';

export type RootStackParamList = {
  SignIn: undefined;
  Home: undefined;
  StartTrip: undefined;
  TripDashboard: undefined;
  EndTripConfirm: undefined;
  TripSummary: undefined;
  UploadQueue: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootNavigator() {
  const { colors } = useTheme();
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  return (
    <NavigationContainer
      theme={{
        dark: false,
        colors: {
          primary: colors.accent,
          background: colors.bg,
          card: colors.surface,
          text: colors.textPrimary,
          border: colors.border,
          notification: colors.accent,
        },
      }}
      linking={{
        prefixes: ['travelflow://'],
        config: {
          screens: {
            Home: 'auth',
          },
        },
      }}
    >
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!user ? (
          <Stack.Screen name="SignIn" component={SignInScreen} />
        ) : (
          <>
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="StartTrip" component={StartTripScreen} options={{ presentation: 'modal' }} />
            <Stack.Screen name="TripDashboard" component={MainTabNavigator} />
            <Stack.Screen
              name="EndTripConfirm"
              component={EndTripConfirmScreen}
              options={{ presentation: 'modal' }}
            />
            <Stack.Screen name="TripSummary" component={TripSummaryScreen} />
            <Stack.Screen
              name="UploadQueue"
              component={UploadQueueScreen}
              options={{ headerShown: true, title: 'Upload Queue' }}
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
