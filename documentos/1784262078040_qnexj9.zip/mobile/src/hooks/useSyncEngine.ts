import { useEffect, useRef, useCallback } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import MediaSync, { MediaSyncEvents, mediaSyncEmitter, MediaItem } from '../modules/MediaSync';
import { useTripStore } from '../store/tripStore';
import { useQueueStore } from '../store/queueStore';
import { useSettingsStore } from '../store/settingsStore';
import {
  getPendingItems, updateQueueItem, QueueItem, addToQueue,
} from '../services/queueService';
import { runUploadPipeline } from '../services/uploadService';
import { v4 as uuidv4 } from 'uuid';

/**
 * The central sync engine. Mount once near the app root (inside a provider
 * or top-level screen) while a trip is active.
 *
 * Responsibilities:
 *  1. Listen for new media via native ContentObserver events
 *  2. Periodically poll MediaStore as a fallback (in case events are missed)
 *  3. Process the upload queue respecting network/battery/storage settings
 *  4. Show a system delete-confirmation dialog for Android 11+ in batches
 */
export function useSyncEngine() {
  const activeTrip = useTripStore(s => s.activeTrip);
  const refreshQueue = useQueueStore(s => s.refresh);
  const setSyncing = useQueueStore(s => s.setSyncing);
  const setCurrentUpload = useQueueStore(s => s.setCurrentUpload);
  const settings = useSettingsStore();

  const isProcessingRef = useRef(false);
  const pendingBatchDeleteUris = useRef<string[]>([]);
  const appStateRef = useRef<AppStateStatus>(AppState.currentState);
  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const batchDeleteIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Detect new media and add to queue ─────────────────────────────────────
  const handleNewMediaBatch = useCallback(async (items: MediaItem[]) => {
    if (!activeTrip) return;

    for (const media of items) {
      await addToQueue({
        id: uuidv4(),
        tripId: activeTrip.id,
        mediaId: media.id,
        uri: media.uri,
        fileName: media.name,
        fileSize: media.size,
        mimeType: media.mimeType,
      });
    }

    await MediaSync.setLastScanTimestamp(Date.now());
    await refreshQueue(activeTrip.id);
  }, [activeTrip, refreshQueue]);

  const scanForNewMedia = useCallback(async () => {
    if (!activeTrip) return;
    try {
      const lastScan = await MediaSync.getLastScanTimestamp();
      const sinceTs = lastScan || activeTrip.created_at * 1000;
      const newItems = await MediaSync.getNewMedia(sinceTs);
      if (newItems.length > 0) {
        await handleNewMediaBatch(newItems);
      }
    } catch (err) {
      console.warn('[SyncEngine] Scan failed:', err);
    }
  }, [activeTrip, handleNewMediaBatch]);

  // ── Check if uploads should proceed (network/battery/storage gates) ───────
  const canUploadNow = useCallback(async (): Promise<{ ok: boolean; reason?: string }> => {
    // Network check
    const netState = await NetInfo.fetch();
    if (!netState.isConnected) return { ok: false, reason: 'offline' };

    if (settings.wifiMode === 'wifi_only' && netState.type !== 'wifi') {
      return { ok: false, reason: 'waiting_for_wifi' };
    }
    if (settings.wifiMode === 'paused') {
      return { ok: false, reason: 'paused' };
    }

    // Battery check
    try {
      const { level, isCharging } = await MediaSync.getBatteryInfo();

      if (!isCharging && level * 100 < settings.minBatteryLevel) {
        return { ok: false, reason: 'low_battery' };
      }
    } catch {
      /* Battery API unavailable – proceed anyway */
    }

    return { ok: true };
  }, [settings.wifiMode, settings.minBatteryLevel]);

  // ── Process the queue sequentially ─────────────────────────────────────────
  const processQueue = useCallback(async () => {
    if (isProcessingRef.current || !activeTrip) return;

    const gate = await canUploadNow();
    if (!gate.ok) {
      if (gate.reason === 'waiting_for_wifi') {
        await MediaSync.updateSyncNotification('Waiting for Wi-Fi…', 0);
      } else if (gate.reason === 'low_battery') {
        await MediaSync.updateSyncNotification('Paused – low battery', 0);
      }
      return;
    }

    isProcessingRef.current = true;
    setSyncing(true);

    try {
      const pending = await getPendingItems(activeTrip.id);
      if (pending.length === 0) {
        setSyncing(false);
        isProcessingRef.current = false;
        return;
      }

      for (const item of pending) {
        // Re-check gate before each item (network/battery can change mid-batch)
        const stillOk = await canUploadNow();
        if (!stillOk.ok) break;

        setCurrentUpload(item.id);
        await MediaSync.updateSyncNotification(
          `Uploading ${item.fileName}`,
          0
        );

        const result = await runUploadPipeline(item, pendingBatchDeleteUris, async (pct) => {
          await MediaSync.updateSyncNotification(`Uploading ${item.fileName}`, pct);
          await refreshQueue(activeTrip.id);
        });

        await refreshQueue(activeTrip.id);

        if (!result.success) {
          console.warn(`[SyncEngine] Upload failed for ${item.fileName}: ${result.error}`);
        }
      }

      await MediaSync.updateSyncNotification('Backup active', 0);
    } finally {
      setCurrentUpload(null);
      setSyncing(false);
      isProcessingRef.current = false;
    }
  }, [activeTrip, canUploadNow, refreshQueue, setSyncing, setCurrentUpload]);

  // ── Batch delete confirmation (Android 11+) ─────────────────────────────────
  const flushBatchDelete = useCallback(async () => {
    if (pendingBatchDeleteUris.current.length === 0) return;
    const uris = [...pendingBatchDeleteUris.current];
    pendingBatchDeleteUris.current = [];

    try {
      await MediaSync.requestBatchDelete(uris);
    } catch (err) {
      console.warn('[SyncEngine] Batch delete dialog failed:', err);
      // Re-queue for next attempt
      pendingBatchDeleteUris.current.push(...uris);
    }
  }, []);

  // ── Lifecycle: start/stop monitoring with trip state ────────────────────────
  useEffect(() => {
    if (!activeTrip) return;

    MediaSync.startMonitoring();
    scanForNewMedia();

    // Fallback poll every 30s in case ContentObserver events are missed
    pollIntervalRef.current = setInterval(scanForNewMedia, 30_000);

    // Process queue every 5s while a trip is active
    const processInterval = setInterval(processQueue, 5_000);

    // Batch delete confirmation every 20s (avoid a dialog per file)
    batchDeleteIntervalRef.current = setInterval(flushBatchDelete, 20_000);

    return () => {
      MediaSync.stopMonitoring();
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
      if (batchDeleteIntervalRef.current) clearInterval(batchDeleteIntervalRef.current);
      clearInterval(processInterval);
    };
  }, [activeTrip, scanForNewMedia, processQueue, flushBatchDelete]);

  // ── Native event listener for real-time detection ───────────────────────────
  useEffect(() => {
    if (!mediaSyncEmitter || !activeTrip) return;

    const sub = mediaSyncEmitter.addListener(MediaSyncEvents.NEW_MEDIA, () => {
      // Debounce: the native side already debounces, just trigger a scan
      scanForNewMedia();
    });

    return () => sub.remove();
  }, [activeTrip, scanForNewMedia]);

  // ── Network reconnect trigger ────────────────────────────────────────────────
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      if (state.isConnected && activeTrip) {
        processQueue();
      }
    });
    return unsubscribe;
  }, [activeTrip, processQueue]);

  // ── App foreground trigger ───────────────────────────────────────────────────
  useEffect(() => {
    const sub = AppState.addEventListener('change', (nextState) => {
      if (appStateRef.current.match(/inactive|background/) && nextState === 'active') {
        if (activeTrip) {
          scanForNewMedia();
          processQueue();
        }
      }
      appStateRef.current = nextState;
    });
    return () => sub.remove();
  }, [activeTrip, scanForNewMedia, processQueue]);

  return { scanForNewMedia, processQueue };
}
