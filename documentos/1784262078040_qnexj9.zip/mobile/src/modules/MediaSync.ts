import { NativeModules, NativeEventEmitter, Platform } from 'react-native';

const { MediaSync: NativeMediaSync } = NativeModules;

if (!NativeMediaSync && Platform.OS === 'android') {
  console.warn('[MediaSync] Native module not found. Did you rebuild the Android project?');
}

export const MediaSyncEvents = {
  NEW_MEDIA: 'onNewMediaDetected',
  STORAGE_LOW: 'onStorageLow',
} as const;

export const mediaSyncEmitter = NativeMediaSync
  ? new NativeEventEmitter(NativeMediaSync)
  : null;

export interface MediaItem {
  id: string;
  uri: string;
  name: string;
  size: number;
  mimeType: string;
  timestamp: number;   // ms
  relativePath: string;
  type: 'image' | 'video';
}

export interface StorageInfo {
  totalBytes: number;
  availableBytes: number;
  usedBytes: number;
}

export interface BatteryInfo {
  level: number;      // 0.0–1.0
  isCharging: boolean;
}

export interface DeleteResult {
  requiresPermission: boolean;
  uri?: string;
  mediaId?: string;
  success?: boolean;
}

const stub = <T>(fallback: T) => async (): Promise<T> => {
  console.warn('[MediaSync] Stub called – native module unavailable');
  return fallback;
};

const MediaSync = {
  /**
   * Start the foreground service and ContentObserver.
   * Call this when a trip becomes active.
   */
  startMonitoring: NativeMediaSync?.startMonitoring
    ? () => NativeMediaSync.startMonitoring() as Promise<boolean>
    : stub(false),

  /**
   * Stop the foreground service and ContentObserver.
   */
  stopMonitoring: NativeMediaSync?.stopMonitoring
    ? () => NativeMediaSync.stopMonitoring() as Promise<boolean>
    : stub(false),

  /**
   * Query MediaStore for all DCIM/Camera media added since sinceTimestampMs.
   */
  getNewMedia: NativeMediaSync?.getNewMedia
    ? (sinceTimestampMs: number) =>
        NativeMediaSync.getNewMedia(sinceTimestampMs) as Promise<MediaItem[]>
    : stub([] as MediaItem[]),

  /**
   * Get device external storage stats.
   */
  getStorageInfo: NativeMediaSync?.getStorageInfo
    ? () => NativeMediaSync.getStorageInfo() as Promise<StorageInfo>
    : stub({ totalBytes: 0, availableBytes: 0, usedBytes: 0 } as StorageInfo),

  /**
   * Get current battery level (0.0–1.0) and charging state via Android's
   * BATTERY_CHANGED sticky broadcast. Zero-dependency replacement for
   * expo-battery, consistent with the rest of this native bridge.
   */
  getBatteryInfo: NativeMediaSync?.getBatteryInfo
    ? () => NativeMediaSync.getBatteryInfo() as Promise<BatteryInfo>
    : stub({ level: 1, isCharging: false } as BatteryInfo),

  /**
   * Compute SHA-256 of a content:// URI, streamed in 8KB chunks natively
   * so large videos never load fully into JS memory. Zero-dependency
   * replacement for expo-crypto.
   */
  computeFileChecksum: NativeMediaSync?.computeFileChecksum
    ? (contentUri: string) => NativeMediaSync.computeFileChecksum(contentUri) as Promise<string>
    : stub(''),

  /**
   * Attempt to delete a local file after verified upload.
   * On Android 11+, returns requiresPermission=true; call requestBatchDelete().
   */
  deleteLocalFile: NativeMediaSync?.deleteLocalFile
    ? (mediaId: string, mediaType: 'image' | 'video') =>
        NativeMediaSync.deleteLocalFile(mediaId, mediaType) as Promise<DeleteResult>
    : stub({ requiresPermission: false, success: false } as DeleteResult),

  /**
   * Show system delete confirmation dialog for multiple files (Android 11+).
   */
  requestBatchDelete: NativeMediaSync?.requestBatchDelete
    ? (uris: string[]) =>
        NativeMediaSync.requestBatchDelete(uris) as Promise<boolean>
    : stub(false),

  /**
   * Schedule a WorkManager job for background upload (app may be killed).
   */
  scheduleBackgroundUpload: NativeMediaSync?.scheduleBackgroundUpload
    ? (queueJson: string, wifiOnly: boolean) =>
        NativeMediaSync.scheduleBackgroundUpload(queueJson, wifiOnly) as Promise<boolean>
    : stub(false),

  /**
   * Update the persistent sync notification text/progress.
   */
  updateSyncNotification: NativeMediaSync?.updateSyncNotification
    ? (message: string, progress: number) =>
        NativeMediaSync.updateSyncNotification(message, progress) as Promise<boolean>
    : stub(false),

  /**
   * Retrieve the last successful scan timestamp from SharedPreferences.
   */
  getLastScanTimestamp: NativeMediaSync?.getLastScanTimestamp
    ? () => NativeMediaSync.getLastScanTimestamp() as Promise<number>
    : stub(0),

  /**
   * Persist the latest scan timestamp to SharedPreferences.
   */
  setLastScanTimestamp: NativeMediaSync?.setLastScanTimestamp
    ? (timestampMs: number) =>
        NativeMediaSync.setLastScanTimestamp(timestampMs) as Promise<boolean>
    : stub(false),
};

export default MediaSync;
