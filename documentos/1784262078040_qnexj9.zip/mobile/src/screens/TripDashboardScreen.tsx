import React, { useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, RefreshControl, Pressable,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import NetInfo from '@react-native-community/netinfo';
import { useTheme } from '../theme/useTheme';
import { spacing, radius, typography } from '../theme/tokens';
import { useTripStore } from '../store/tripStore';
import { useQueueStore } from '../store/queueStore';
import { useSyncEngine } from '../hooks/useSyncEngine';
import { SyncBeacon } from '../components/common/SyncBeacon';
import { Card, ProgressBar, StatBlock, Badge, Button } from '../components/common/UI';
import MediaSync, { StorageInfo } from '../modules/MediaSync';
import { formatBytes, formatRelativeTime } from '../utils/format';

export default function TripDashboardScreen({ navigation }: any) {
  const { colors } = useTheme();
  const activeTrip = useTripStore(s => s.activeTrip);
  const refreshTrip = useTripStore(s => s.refreshTrip);
  const endTrip = useTripStore(s => s.endTrip);

  const items = useQueueStore(s => s.items);
  const refreshQueue = useQueueStore(s => s.refresh);
  const isSyncing = useQueueStore(s => s.isSyncing);
  const waitingCount = useQueueStore(s => s.waitingCount());
  const uploadingCount = useQueueStore(s => s.uploadingCount());
  const failedCount = useQueueStore(s => s.failedCount());
  const completedCount = useQueueStore(s => s.completedCount());

  const [storageInfo, setStorageInfo] = React.useState<StorageInfo | null>(null);
  const [isOnline, setIsOnline] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  // Run the sync engine while this screen tree is mounted
  useSyncEngine();

  const loadStorageInfo = useCallback(async () => {
    const info = await MediaSync.getStorageInfo();
    setStorageInfo(info);
  }, []);

  useEffect(() => {
    const unsub = NetInfo.addEventListener(state => setIsOnline(!!state.isConnected));
    return unsub;
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (activeTrip) {
        refreshQueue(activeTrip.id);
        refreshTrip();
        loadStorageInfo();
      }
    }, [activeTrip?.id])
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([
      activeTrip ? refreshQueue(activeTrip.id) : Promise.resolve(),
      refreshTrip(),
      loadStorageInfo(),
    ]);
    setRefreshing(false);
  }, [activeTrip?.id]);

  if (!activeTrip) {
    return (
      <View style={[styles.centered, { backgroundColor: colors.bg }]}>
        <Text style={{ color: colors.textMuted }}>No active trip</Text>
      </View>
    );
  }

  const totalMedia = activeTrip.photo_count + activeTrip.video_count + waitingCount + uploadingCount;
  const syncPercent = totalMedia > 0
    ? Math.round(((activeTrip.photo_count + activeTrip.video_count) / totalMedia) * 100)
    : 100;

  const freeGB = storageInfo ? (storageInfo.availableBytes / (1024 ** 3)) : 0;

  return (
    <ScrollView
      style={{ backgroundColor: colors.bg }}
      contentContainerStyle={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />}
    >
      {/* ── Trip Header ─────────────────────────────────────────────── */}
      <View style={styles.tripHeader}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.eyebrow, { color: colors.textMuted }]}>ACTIVE TRIP</Text>
          <Text style={[styles.tripName, { color: colors.textPrimary }]}>{activeTrip.name}</Text>
          {activeTrip.destination && (
            <Text style={[styles.tripDestination, { color: colors.textSecondary }]}>
              {activeTrip.destination}
            </Text>
          )}
        </View>
        <View style={styles.beaconRow}>
          <SyncBeacon active={isSyncing} />
          <Text style={[styles.beaconLabel, { color: isSyncing ? colors.accent : colors.textMuted }]}>
            {isSyncing ? 'SYNCING' : 'IDLE'}
          </Text>
        </View>
      </View>

      {!isOnline && (
        <View style={[styles.offlineBanner, { backgroundColor: colors.surfaceAlt }]}>
          <Text style={[styles.offlineBannerText, { color: colors.textSecondary }]}>
            Offline — queue will resume automatically when connected
          </Text>
        </View>
      )}

      {/* ── Sync Progress Ring Card ─────────────────────────────────── */}
      <Card style={styles.progressCard}>
        <View style={styles.progressRow}>
          <View>
            <Text style={[styles.progressPercent, { color: colors.textPrimary }]}>{syncPercent}%</Text>
            <Text style={[styles.progressLabel, { color: colors.textMuted }]}>backed up</Text>
          </View>
          <View style={styles.progressStats}>
            <StatRow label="Uploaded" value={completedCount} color={colors.success} />
            <StatRow label="Waiting" value={waitingCount} color={colors.warning} />
            <StatRow label="Failed" value={failedCount} color={failedCount > 0 ? colors.danger : colors.textMuted} />
          </View>
        </View>
        <View style={{ marginTop: spacing.lg }}>
          <ProgressBar progress={syncPercent} />
        </View>
      </Card>

      {/* ── Stats Grid ───────────────────────────────────────────────── */}
      <Card style={styles.statsCard}>
        <View style={styles.statsGrid}>
          <StatBlock value={activeTrip.photo_count} label="Photos" />
          <StatBlock value={activeTrip.video_count} label="Videos" />
          <StatBlock value={formatBytes(activeTrip.total_uploaded_bytes)} label="Uploaded" />
          <StatBlock value={formatBytes(activeTrip.total_freed_bytes)} label="Freed" accent />
        </View>
      </Card>

      {/* ── Storage Card ─────────────────────────────────────────────── */}
      <Card style={styles.storageCard}>
        <View style={styles.storageHeader}>
          <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>Free storage</Text>
          <Text style={[styles.storageValue, { color: colors.textSecondary }]}>
            {freeGB.toFixed(1)} GB free
          </Text>
        </View>
        <ProgressBar
          progress={storageInfo ? (storageInfo.usedBytes / storageInfo.totalBytes) * 100 : 0}
          color={colors.textMuted}
          trackColor={colors.surfaceAlt}
          height={8}
        />
      </Card>

      {/* ── Queue Preview ────────────────────────────────────────────── */}
      <View style={styles.sectionHeaderRow}>
        <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Recent activity</Text>
        <Pressable onPress={() => navigation.navigate('UploadQueue')}>
          <Text style={[styles.sectionLink, { color: colors.accent }]}>View all</Text>
        </Pressable>
      </View>

      {items.slice(0, 4).map(item => (
        <QueuePreviewRow key={item.id} item={item} colors={colors} />
      ))}

      {items.length === 0 && (
        <Card style={{ alignItems: 'center', paddingVertical: spacing.xl }}>
          <Text style={{ color: colors.textMuted }}>No activity yet — take a photo to see it appear here</Text>
        </Card>
      )}

      {/* ── End Trip ─────────────────────────────────────────────────── */}
      <Button
        label="End Trip"
        variant="secondary"
        onPress={() => navigation.navigate('EndTripConfirm')}
        style={{ marginTop: spacing.xl }}
      />
    </ScrollView>
  );
}

function StatRow({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <View style={styles.statRow}>
      <View style={[styles.statDot, { backgroundColor: color }]} />
      <Text style={[styles.statRowValue, { color }]}>{value}</Text>
      <Text style={styles.statRowLabel}>{label}</Text>
    </View>
  );
}

function QueuePreviewRow({ item, colors }: { item: any; colors: any }) {
  const statusConfig: Record<string, { label: string; tone: any }> = {
    waiting: { label: 'Waiting', tone: 'warning' },
    uploading: { label: 'Uploading', tone: 'accent' },
    verifying: { label: 'Verifying', tone: 'accent' },
    deleting: { label: 'Freeing space', tone: 'accent' },
    completed: { label: 'Synced', tone: 'success' },
    failed: { label: 'Failed', tone: 'danger' },
  };
  const cfg = statusConfig[item.status] ?? statusConfig.waiting;

  return (
    <Card style={styles.queueRow}>
      <View style={{ flex: 1 }}>
        <Text style={[styles.queueFileName, { color: colors.textPrimary }]} numberOfLines={1}>
          {item.fileName}
        </Text>
        <Text style={[styles.queueMeta, { color: colors.textMuted }]}>
          {formatBytes(item.fileSize)} · {formatRelativeTime(item.addedAt)}
        </Text>
        {(item.status === 'uploading') && (
          <View style={{ marginTop: spacing.sm }}>
            <ProgressBar progress={item.progress} height={4} />
          </View>
        )}
      </View>
      <Badge label={cfg.label} tone={cfg.tone} />
    </Card>
  );
}

const styles = StyleSheet.create({
  container: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  tripHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: spacing.lg,
  },
  eyebrow: {
    fontSize: typography.scale.micro,
    fontWeight: '700',
    letterSpacing: 1,
  },
  tripName: {
    fontSize: typography.scale.display,
    fontWeight: '700',
    marginTop: 2,
  },
  tripDestination: {
    fontSize: typography.scale.body,
    marginTop: 2,
  },
  beaconRow: { alignItems: 'center', gap: 4 },
  beaconLabel: {
    fontSize: typography.scale.micro,
    fontWeight: '700',
    letterSpacing: 0.6,
  },

  offlineBanner: {
    padding: spacing.md,
    borderRadius: radius.md,
    marginBottom: spacing.lg,
  },
  offlineBannerText: { fontSize: typography.scale.caption },

  progressCard: { marginBottom: spacing.md },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  progressPercent: { fontSize: 44, fontWeight: '700', fontVariant: ['tabular-nums'] },
  progressLabel: { fontSize: typography.scale.caption, marginTop: -4 },
  progressStats: { gap: spacing.xs },
  statRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statDot: { width: 6, height: 6, borderRadius: 3 },
  statRowValue: { fontSize: typography.scale.body, fontWeight: '700', minWidth: 20 },
  statRowLabel: { fontSize: typography.scale.caption, color: '#8C93A0' },

  statsCard: { marginBottom: spacing.md },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xl },

  storageCard: { marginBottom: spacing.xl },
  storageHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: spacing.md },
  cardTitle: { fontSize: typography.scale.h3, fontWeight: '700' },
  storageValue: { fontSize: typography.scale.caption },

  sectionHeaderRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: spacing.sm,
  },
  sectionTitle: { fontSize: typography.scale.h3, fontWeight: '700' },
  sectionLink: { fontSize: typography.scale.caption, fontWeight: '600' },

  queueRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    marginBottom: spacing.sm, paddingVertical: spacing.md,
  },
  queueFileName: { fontSize: typography.scale.body, fontWeight: '600' },
  queueMeta: { fontSize: typography.scale.micro, marginTop: 2 },
});
