import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, ScrollView, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useTheme } from '../theme/useTheme';
import { spacing, radius, typography } from '../theme/tokens';
import { useTripStore } from '../store/tripStore';
import { Button, Card } from '../components/common/UI';

export default function StartTripScreen({ navigation }: any) {
  const { colors } = useTheme();
  const startTrip = useTripStore(s => s.startTrip);

  const [name, setName] = useState('');
  const [destination, setDestination] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  const canSubmit = name.trim().length > 0 && !isCreating;

  const handleStart = async () => {
    if (!canSubmit) return;
    setIsCreating(true);
    try {
      const startDate = new Date().toISOString();
      await startTrip({
        name: name.trim(),
        destination: destination.trim() || undefined,
        startDate,
      });
      navigation.replace('TripDashboard');
    } catch (err: any) {
      const message = err?.response?.data?.error ?? 'Could not start trip. Please try again.';
      Alert.alert('Something went wrong', message);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={[styles.eyebrow, { color: colors.textMuted }]}>NEW JOURNEY</Text>
        <Text style={[styles.title, { color: colors.textPrimary }]}>Start a trip</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          TravelFlow will watch your camera roll and back everything up to Drive automatically.
        </Text>

        <Card style={styles.formCard}>
          <FieldLabel colors={colors}>Trip name</FieldLabel>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Argentina 2026"
            placeholderTextColor={colors.textMuted}
            style={[styles.input, { color: colors.textPrimary, borderColor: colors.border }]}
            autoFocus
          />

          <View style={{ height: spacing.lg }} />

          <FieldLabel colors={colors}>Destination (optional)</FieldLabel>
          <TextInput
            value={destination}
            onChangeText={setDestination}
            placeholder="Buenos Aires, Argentina"
            placeholderTextColor={colors.textMuted}
            style={[styles.input, { color: colors.textPrimary, borderColor: colors.border }]}
          />
        </Card>

        <View style={styles.infoBox}>
          <Text style={[styles.infoText, { color: colors.textMuted }]}>
            A folder named after this trip will be created in your Google Drive. Your native camera app keeps working exactly as before.
          </Text>
        </View>

        <Button
          label="Start Trip"
          onPress={handleStart}
          disabled={!canSubmit}
          loading={isCreating}
          style={{ marginTop: spacing.xl }}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function FieldLabel({ children, colors }: { children: string; colors: any }) {
  return (
    <Text style={[styles.fieldLabel, { color: colors.textSecondary }]}>{children}</Text>
  );
}

const styles = StyleSheet.create({
  container: { padding: spacing.lg, paddingTop: spacing.xxl, paddingBottom: spacing.xxxl },
  eyebrow: {
    fontSize: typography.scale.micro,
    fontWeight: '700',
    letterSpacing: 1,
  },
  title: {
    fontSize: typography.scale.display,
    fontWeight: '700',
    marginTop: 4,
  },
  subtitle: {
    fontSize: typography.scale.body,
    marginTop: spacing.sm,
    lineHeight: 21,
  },
  formCard: { marginTop: spacing.xxl },
  fieldLabel: {
    fontSize: typography.scale.caption,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  input: {
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    fontSize: typography.scale.body,
  },
  infoBox: {
    marginTop: spacing.lg,
    paddingHorizontal: spacing.xs,
  },
  infoText: {
    fontSize: typography.scale.caption,
    lineHeight: 18,
  },
});
