import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Animated } from 'react-native';
import { useTheme } from '../theme/useTheme';
import { spacing, radius, typography } from '../theme/tokens';
import { useTripStore } from '../store/tripStore';
import { Button, Card } from '../components/common/UI';
import { formatBytes, formatDuration } from '../utils/format';

export default function TripSummaryScreen({ navigation }: any) {
  const { colors } = useTheme();
  const lastSummary = useTripStore(s => s.lastSummary);
  const clearSummary = useTripStore(s => s.clearSummary);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 500, useNativeDriver: true }),
    ]).start();
  }, []);

  if (!lastSummary) {
    return (
      <View style={[styles.centered, { backgroundColor: colors.bg }]}>
        <Text style={{ color: colors.textMuted }}>No summary available</Text>
        <Button label="Go Home" onPress={() => navigation.replace('Home')} style={{ marginTop: spacing.lg }} />
      </View>
    );
  }

  const { trip, summary } = lastSummary;

  const handleDone = () => {
    clearSummary();
    navigation.replace('Home');
  };

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={styles.container}>
      <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>
        <Text style={[styles.eyebrow, { color: colors.textMuted }]}>TRIP COMPLETE</Text>
        <Text style={[styles.tripName, { color: colors.textPrimary }]}>{trip.name}</Text>
        {trip.destination && (
          <Text style={[styles.destination, { color: colors.textSecondary }]}>{trip.destination}</Text>
        )}

        <View style={styles.heroStats}>
          <View style={styles.heroStat}>
            <Text style={[styles.heroValue, { color: colors.textPrimary }]}>
              {summary.photos.toLocaleString()}
            </Text>
            <Text style={[styles.heroLabel, { color: colors.textMuted }]}>Photos</Text>
          </View>
          <View style={[styles.heroDivider, { backgroundColor: colors.border }]} />
          <View style={styles.heroStat}>
            <Text style={[styles.heroValue, { color: colors.textPrimary }]}>
              {summary.videos.toLocaleString()}
            </Text>
            <Text style={[styles.heroLabel, { color: colors.textMuted }]}>Videos</Text>
          </View>
        </View>

        <Card style={[styles.freedCard, { backgroundColor: colors.accentSoft, borderColor: 'transparent' }]}>
          <Text style={[styles.freedValue, { color: colors.accent }]}>
            {formatBytes(summary.totalFreedBytes)}
          </Text>
          <Text style={[styles.freedLabel, { color: colors.accent }]}>freed on your device</Text>
        </Card>

        <View style={styles.detailGrid}>
          <DetailCard
            label="Total uploaded"
            value={formatBytes(summary.totalUploadedBytes)}
            colors={colors}
          />
          <DetailCard
            label="Trip duration"
            value={formatDuration(summary.durationDays)}
            colors={colors}
          />
        </View>

        {summary.failedUploads > 0 && (
          <Card style={[styles.failedNotice, { borderColor: colors.danger }]}>
            <Text style={{ color: colors.danger, fontWeight: '600' }}>
              {summary.failedUploads} file{summary.failedUploads > 1 ? 's' : ''} failed to upload
            </Text>
            <Text style={{ color: colors.textMuted, fontSize: typography.scale.caption, marginTop: 4 }}>
              These files are still on your device. Check the upload queue to retry.
            </Text>
          </Card>
        )}

        <Button label="Done" onPress={handleDone} style={{ marginTop: spacing.xxl }} />
      </Animated.View>
    </ScrollView>
  );
}

function DetailCard({ label, value, colors }: { label: string; value: string; colors: any }) {
  return (
    <Card style={styles.detailCard}>
      <Text style={[styles.detailValue, { color: colors.textPrimary }]}>{value}</Text>
      <Text style={[styles.detailLabel, { color: colors.textMuted }]}>{label}</Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: { padding: spacing.lg, paddingTop: spacing.xxl, paddingBottom: spacing.xxxl },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  eyebrow: { fontSize: typography.scale.micro, fontWeight: '700', letterSpacing: 1, textAlign: 'center' },
  tripName: { fontSize: typography.scale.display, fontWeight: '700', textAlign: 'center', marginTop: 4 },
  destination: { fontSize: typography.scale.body, textAlign: 'center', marginTop: 2 },

  heroStats: {
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center',
    marginTop: spacing.xxl, gap: spacing.xxl,
  },
  heroStat: { alignItems: 'center' },
  heroValue: { fontSize: 48, fontWeight: '700', fontVariant: ['tabular-nums'] },
  heroLabel: { fontSize: typography.scale.caption, marginTop: -4, textTransform: 'uppercase', letterSpacing: 0.5 },
  heroDivider: { width: 1, height: 48 },

  freedCard: {
    marginTop: spacing.xxl, alignItems: 'center', paddingVertical: spacing.xl,
  },
  freedValue: { fontSize: 32, fontWeight: '700' },
  freedLabel: { fontSize: typography.scale.caption, marginTop: 2, fontWeight: '600' },

  detailGrid: { flexDirection: 'row', gap: spacing.md, marginTop: spacing.lg },
  detailCard: { flex: 1, alignItems: 'center', paddingVertical: spacing.lg },
  detailValue: { fontSize: typography.scale.h2, fontWeight: '700' },
  detailLabel: { fontSize: typography.scale.micro, marginTop: 2, textTransform: 'uppercase' },

  failedNotice: { marginTop: spacing.lg, borderWidth: 1 },
});
