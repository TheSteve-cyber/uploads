import React, { useCallback, useMemo } from 'react';
import { View, Text, StyleSheet, Image, Dimensions } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { useFocusEffect } from '@react-navigation/native';
import { useTheme } from '../theme/useTheme';
import { spacing, radius, typography } from '../theme/tokens';
import { useTripStore } from '../store/tripStore';
import { useQueueStore } from '../store/queueStore';
import { EmptyState, ScreenHeader } from '../components/common/UI';
import { QueueItem } from '../services/queueService';

const { width } = Dimensions.get('window');
const COLUMNS = 3;
const GAP = 3;
const THUMB_SIZE = (width - spacing.lg * 2 - GAP * (COLUMNS - 1)) / COLUMNS;

interface Section {
  title: string;
  data: QueueItem[];
}

export default function GalleryScreen() {
  const { colors } = useTheme();
  const activeTrip = useTripStore(s => s.activeTrip);
  const items = useQueueStore(s => s.items);
  const refresh = useQueueStore(s => s.refresh);

  useFocusEffect(
    useCallback(() => {
      if (activeTrip) refresh(activeTrip.id);
    }, [activeTrip?.id])
  );

  // Only show synchronized media, per spec: "Show only synchronized media"
  const synced = useMemo(
    () => items.filter(i => i.status === 'completed').sort((a, b) => b.addedAt - a.addedAt),
    [items]
  );

  const sections = useMemo(() => buildSections(synced), [synced]);

  // Flatten sections into a single list with section headers as special rows
  const flatData = useMemo(() => {
    const rows: Array<{ type: 'header'; title: string } | { type: 'item'; item: QueueItem }> = [];
    sections.forEach(section => {
      if (section.data.length === 0) return;
      rows.push({ type: 'header', title: section.title });
      section.data.forEach(item => rows.push({ type: 'item', item }));
    });
    return rows;
  }, [sections]);

  if (synced.length === 0) {
    return (
      <View style={[styles.screen, { backgroundColor: colors.bg }]}>
        <ScreenHeader title="Gallery" subtitle={activeTrip?.name} />
        <EmptyState
          title="Nothing synced yet"
          message="Photos and videos appear here once they're safely backed up to Drive"
        />
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.bg }]}>
      <ScreenHeader title="Gallery" subtitle={`${synced.length} synced`} />
      <FlashList
        data={flatData}
        keyExtractor={(row, idx) => row.type === 'header' ? `h-${row.title}` : row.item.id}
        estimatedItemSize={THUMB_SIZE}
        contentContainerStyle={{ padding: spacing.lg }}
        renderItem={({ item: row }) => {
          if (row.type === 'header') {
            return (
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>{row.title}</Text>
            );
          }
          return <Thumbnail item={row.item} colors={colors} />;
        }}
      />
    </View>
  );
}

function Thumbnail({ item, colors }: { item: QueueItem; colors: any }) {
  const isVideo = item.mimeType.startsWith('video/');
  return (
    <View style={[styles.thumb, { backgroundColor: colors.surfaceAlt }]}>
      <Image source={{ uri: item.uri }} style={styles.thumbImage} resizeMode="cover" />
      {isVideo && (
        <View style={styles.videoBadge}>
          <Text style={styles.videoBadgeText}>▶</Text>
        </View>
      )}
    </View>
  );
}

function buildSections(items: QueueItem[]): Section[] {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfYesterday = startOfToday - 86_400_000;
  const startOfWeek = startOfToday - 7 * 86_400_000;

  const today: QueueItem[] = [];
  const yesterday: QueueItem[] = [];
  const thisWeek: QueueItem[] = [];
  const older: QueueItem[] = [];

  items.forEach(item => {
    if (item.addedAt >= startOfToday) today.push(item);
    else if (item.addedAt >= startOfYesterday) yesterday.push(item);
    else if (item.addedAt >= startOfWeek) thisWeek.push(item);
    else older.push(item);
  });

  return [
    { title: 'Today', data: today },
    { title: 'Yesterday', data: yesterday },
    { title: 'This Week', data: thisWeek },
    { title: 'Trip Timeline', data: older },
  ];
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  sectionTitle: {
    fontSize: typography.scale.h3, fontWeight: '700',
    marginTop: spacing.lg, marginBottom: spacing.sm,
  },
  thumb: {
    width: THUMB_SIZE, height: THUMB_SIZE,
    borderRadius: radius.sm, overflow: 'hidden',
    marginRight: GAP, marginBottom: GAP,
  },
  thumbImage: { width: '100%', height: '100%' },
  videoBadge: {
    position: 'absolute', bottom: 4, right: 4,
    backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 10,
    width: 20, height: 20, alignItems: 'center', justifyContent: 'center',
  },
  videoBadgeText: { color: '#FFF', fontSize: 9 },
});
