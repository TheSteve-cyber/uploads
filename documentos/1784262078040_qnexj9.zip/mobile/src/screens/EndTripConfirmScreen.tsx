import React, { useState } from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import { useTheme } from '../theme/useTheme';
import { spacing, typography } from '../theme/tokens';
import { useTripStore } from '../store/tripStore';
import { useQueueStore } from '../store/queueStore';
import { Button, Card, Badge } from '../components/common/UI';

export default function EndTripConfirmScreen({ navigation }: any) {
  const { colors } = useTheme();
  const activeTrip = useTripStore(s => s.activeTrip);
  const endTrip = useTripStore(s => s.endTrip);
  const waitingCount = useQueueStore(s => s.waitingCount());
  const uploadingCount = useQueueStore(s => s.uploadingCount());

  const [isEnding, setIsEnding] = useState(false);

  const pendingCount = waitingCount + uploadingCount;

  const handleEndTrip = async () => {
    setIsEnding(true);
    try {
      await endTrip();
      navigation.replace('TripSummary');
    } catch (err: any) {
      Alert.alert('Could not end trip', err?.response?.data?.error ?? 'Please try again.');
      setIsEnding(false);
    }
  };

  if (!activeTrip) return null;

  return (
    <View style={[styles.container, { backgroundColor: colors.bg }]}>
      <Text style={[styles.title, { color: colors.textPrimary }]}>End "{activeTrip.name}"?</Text>
      <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
        This stops camera monitoring and generates your trip summary.
      </Text>

      {pendingCount > 0 && (
        <Card style={[styles.warningCard, { borderColor: colors.warning }]}>
          <Badge label={`${pendingCount} still syncing`} tone="warning" />
          <Text style={[styles.warningText, { color: colors.textSecondary }]}>
            Some files haven't finished uploading yet. They'll continue in the background, but we recommend waiting until sync completes before ending the trip.
          </Text>
        </Card>
      )}

      <Card style={styles.summaryCard}>
        <SummaryRow label="Photos" value={activeTrip.photo_count} colors={colors} />
        <SummaryRow label="Videos" value={activeTrip.video_count} colors={colors} />
      </Card>

      <View style={{ flex: 1 }} />

      <Button
        label={pendingCount > 0 ? 'End Trip Anyway' : 'End Trip'}
        variant={pendingCount > 0 ? 'danger' : 'primary'}
        onPress={handleEndTrip}
        loading={isEnding}
      />
      <Button
        label="Keep Syncing"
        variant="ghost"
        onPress={() => navigation.goBack()}
        style={{ marginTop: spacing.sm }}
      />
    </View>
  );
}

function SummaryRow({ label, value, colors }: { label: string; value: number; colors: any }) {
  return (
    <View style={styles.summaryRow}>
      <Text style={{ color: colors.textSecondary, fontSize: typography.scale.body }}>{label}</Text>
      <Text style={{ color: colors.textPrimary, fontSize: typography.scale.body, fontWeight: '700' }}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.lg, paddingTop: spacing.xxl },
  title: { fontSize: typography.scale.h1, fontWeight: '700' },
  subtitle: { fontSize: typography.scale.body, marginTop: spacing.sm, lineHeight: 21 },
  warningCard: { marginTop: spacing.xl, borderWidth: 1, gap: spacing.sm },
  warningText: { fontSize: typography.scale.caption, lineHeight: 18 },
  summaryCard: { marginTop: spacing.lg, gap: spacing.sm },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between' },
});
