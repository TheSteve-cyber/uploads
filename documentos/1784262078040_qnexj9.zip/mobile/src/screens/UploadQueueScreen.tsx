import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { useFocusEffect } from '@react-navigation/native';
import { useTheme } from '../theme/useTheme';
import { spacing, radius, typography } from '../theme/tokens';
import { useTripStore } from '../store/tripStore';
import { useQueueStore } from '../store/queueStore';
import { Badge, ProgressBar, EmptyState, ScreenHeader } from '../components/common/UI';
import { QueueItem, updateQueueItem } from '../services/queueService';
import { formatBytes, formatClockTime } from '../utils/format';

type FilterTab = 'all' | 'waiting' | 'failed' | 'completed';

export default function UploadQueueScreen() {
  const { colors } = useTheme();
  const activeTrip = useTripStore(s => s.activeTrip);
  const items = useQueueStore(s => s.items);
  const refresh = useQueueStore(s => s.refresh);
  const [filter, setFilter] = useState<FilterTab>('all');

  useFocusEffect(
    useCallback(() => {
      if (activeTrip) refresh(activeTrip.id);
      const interval = setInterval(() => activeTrip && refresh(activeTrip.id), 3000);
      return () => clearInterval(interval);
    }, [activeTrip?.id])
  );

  const filtered = items.filter(item => {
    if (filter === 'all') return true;
    if (filter === 'waiting') return item.status === 'waiting' || item.status === 'uploading' || item.status === 'verifying';
    if (filter === 'failed') return item.status === 'failed';
    if (filter === 'completed') return item.status === 'completed';
    return true;
  });

  const handleRetry = async (item: QueueItem) => {
    await updateQueueItem(item.id, { status: 'waiting', retries: 0, error: undefined });
    if (activeTrip) refresh(activeTrip.id);
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.bg }]}>
      <ScreenHeader title="Upload Queue" subtitle={`${items.length} items`} />

      <View style={styles.tabs}>
        {(['all', 'waiting', 'failed', 'completed'] as FilterTab[]).map(tab => (
          <Pressable
            key={tab}
            onPress={() => setFilter(tab)}
            style={[
              styles.tab,
              filter === tab && { backgroundColor: colors.accent },
              filter !== tab && { backgroundColor: colors.surfaceAlt },
            ]}
          >
            <Text style={[
              styles.tabText,
              { color: filter === tab ? '#FFFFFF' : colors.textSecondary },
            ]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>

      {filtered.length === 0 ? (
        <EmptyState
          title="Nothing here"
          message={filter === 'all' ? 'Take a photo to start syncing' : `No ${filter} items`}
        />
      ) : (
        <FlashList
          data={filtered}
          keyExtractor={item => item.id}
          estimatedItemSize={88}
          contentContainerStyle={{ padding: spacing.lg }}
          renderItem={({ item }) => (
            <QueueRow item={item} colors={colors} onRetry={() => handleRetry(item)} />
          )}
        />
      )}
    </View>
  );
}

function QueueRow({ item, colors, onRetry }: { item: QueueItem; colors: any; onRetry: () => void }) {
  const statusConfig: Record<string, { label: string; tone: any }> = {
    waiting: { label: 'Waiting', tone: 'warning' },
    uploading: { label: `${item.progress}%`, tone: 'accent' },
    verifying: { label: 'Verifying', tone: 'accent' },
    deleting: { label: 'Freeing space', tone: 'accent' },
    completed: { label: 'Synced', tone: 'success' },
    failed: { label: 'Failed', tone: 'danger' },
  };
  const cfg = statusConfig[item.status] ?? statusConfig.waiting;

  return (
    <View style={[styles.row, { borderColor: colors.border, backgroundColor: colors.surface }]}>
      <View style={{ flex: 1 }}>
        <Text style={[styles.fileName, { color: colors.textPrimary }]} numberOfLines={1}>
          {item.fileName}
        </Text>
        <Text style={[styles.meta, { color: colors.textMuted }]}>
          {formatBytes(item.fileSize)} · {formatClockTime(item.addedAt)}
        </Text>

        {item.status === 'uploading' && (
          <View style={{ marginTop: spacing.sm }}>
            <ProgressBar progress={item.progress} height={4} />
          </View>
        )}

        {item.status === 'failed' && item.error && (
          <Text style={[styles.errorText, { color: colors.danger }]} numberOfLines={2}>
            {item.error}
          </Text>
        )}
      </View>

      <View style={styles.rowRight}>
        <Badge label={cfg.label} tone={cfg.tone} />
        {item.status === 'failed' && (
          <Pressable onPress={onRetry} style={{ marginTop: spacing.sm }}>
            <Text style={[styles.retryLink, { color: colors.accent }]}>Retry</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  tabs: {
    flexDirection: 'row', gap: spacing.sm,
    paddingHorizontal: spacing.lg, marginBottom: spacing.sm,
  },
  tab: {
    paddingHorizontal: spacing.lg, paddingVertical: spacing.sm,
    borderRadius: radius.pill,
  },
  tabText: { fontSize: typography.scale.caption, fontWeight: '600' },

  row: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md,
    padding: spacing.md, borderRadius: radius.md, borderWidth: 1,
    marginBottom: spacing.sm,
  },
  fileName: { fontSize: typography.scale.body, fontWeight: '600' },
  meta: { fontSize: typography.scale.micro, marginTop: 2 },
  errorText: { fontSize: typography.scale.micro, marginTop: spacing.xs },
  rowRight: { alignItems: 'flex-end' },
  retryLink: { fontSize: typography.scale.caption, fontWeight: '700' },
});
