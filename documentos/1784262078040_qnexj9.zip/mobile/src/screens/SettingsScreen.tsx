import React from 'react';
import { View, Text, StyleSheet, Switch, Pressable, ScrollView, Alert } from 'react-native';
import Slider from '@react-native-community/slider';
import { useTheme } from '../theme/useTheme';
import { spacing, radius, typography } from '../theme/tokens';
import { useSettingsStore, WifiMode } from '../store/settingsStore';
import { useAuth } from '../contexts/AuthContext';
import { Card, ScreenHeader } from '../components/common/UI';

export default function SettingsScreen() {
  const { colors } = useTheme();
  const { user, signOut } = useAuth();
  const settings = useSettingsStore();

  const handleSignOut = () => {
    Alert.alert('Sign out', 'You can sign back in anytime with Google.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: signOut },
    ]);
  };

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={styles.container}>
      <ScreenHeader title="Settings" />

      {/* ── Account ─────────────────────────────────────────────── */}
      <SectionLabel colors={colors}>Account</SectionLabel>
      <Card style={styles.accountCard}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.accountName, { color: colors.textPrimary }]}>{user?.name}</Text>
          <Text style={[styles.accountEmail, { color: colors.textMuted }]}>{user?.email}</Text>
        </View>
      </Card>

      {/* ── Upload Settings ─────────────────────────────────────── */}
      <SectionLabel colors={colors}>Upload</SectionLabel>
      <Card style={styles.card}>
        {(['wifi_only', 'wifi_and_mobile', 'paused'] as WifiMode[]).map((mode, idx) => (
          <React.Fragment key={mode}>
            {idx > 0 && <View style={[styles.divider, { backgroundColor: colors.border }]} />}
            <Pressable
              style={styles.optionRow}
              onPress={() => settings.setWifiMode(mode)}
            >
              <Text style={[styles.optionLabel, { color: colors.textPrimary }]}>
                {wifiModeLabel(mode)}
              </Text>
              <RadioDot selected={settings.wifiMode === mode} colors={colors} />
            </Pressable>
          </React.Fragment>
        ))}
      </Card>

      {/* ── Storage Threshold ───────────────────────────────────── */}
      <SectionLabel colors={colors}>Storage</SectionLabel>
      <Card style={styles.card}>
        <View style={styles.sliderHeader}>
          <Text style={[styles.optionLabel, { color: colors.textPrimary }]}>Keep free</Text>
          <Text style={[styles.sliderValue, { color: colors.accent }]}>
            {settings.minFreeStorageGB} GB
          </Text>
        </View>
        <Slider
          minimumValue={5}
          maximumValue={100}
          step={5}
          value={settings.minFreeStorageGB}
          onSlidingComplete={settings.setMinFreeStorageGB}
          minimumTrackTintColor={colors.accent}
          maximumTrackTintColor={colors.surfaceAlt}
          thumbTintColor={colors.accent}
        />
        <Text style={[styles.helperText, { color: colors.textMuted }]}>
          When free space drops below this, TravelFlow uploads and clears your oldest synced files first.
        </Text>
      </Card>

      <Card style={[styles.card, styles.switchRow]}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.optionLabel, { color: colors.textPrimary }]}>Auto-delete after upload</Text>
          <Text style={[styles.helperText, { color: colors.textMuted, marginTop: 2 }]}>
            Turn off to keep local copies even after they're backed up
          </Text>
        </View>
        <Switch
          value={settings.autoDeleteEnabled}
          onValueChange={settings.setAutoDeleteEnabled}
          trackColor={{ false: colors.surfaceAlt, true: colors.accent }}
        />
      </Card>

      {/* ── Battery ──────────────────────────────────────────────── */}
      <SectionLabel colors={colors}>Battery</SectionLabel>
      <Card style={styles.card}>
        <View style={styles.sliderHeader}>
          <Text style={[styles.optionLabel, { color: colors.textPrimary }]}>Pause below</Text>
          <Text style={[styles.sliderValue, { color: colors.accent }]}>
            {settings.minBatteryLevel}%
          </Text>
        </View>
        <Slider
          minimumValue={0}
          maximumValue={50}
          step={5}
          value={settings.minBatteryLevel}
          onSlidingComplete={settings.setMinBatteryLevel}
          minimumTrackTintColor={colors.accent}
          maximumTrackTintColor={colors.surfaceAlt}
          thumbTintColor={colors.accent}
        />
        <Text style={[styles.helperText, { color: colors.textMuted }]}>
          Uploads pause below this level unless your phone is charging.
        </Text>
      </Card>

      {/* ── Appearance ───────────────────────────────────────────── */}
      <SectionLabel colors={colors}>Appearance</SectionLabel>
      <Card style={styles.card}>
        {(['system', 'light', 'dark'] as const).map((mode, idx) => (
          <React.Fragment key={mode}>
            {idx > 0 && <View style={[styles.divider, { backgroundColor: colors.border }]} />}
            <Pressable
              style={styles.optionRow}
              onPress={() => settings.setDarkMode(mode)}
            >
              <Text style={[styles.optionLabel, { color: colors.textPrimary }]}>
                {mode.charAt(0).toUpperCase() + mode.slice(1)}
              </Text>
              <RadioDot selected={settings.darkMode === mode} colors={colors} />
            </Pressable>
          </React.Fragment>
        ))}
      </Card>

      {/* ── Sign Out ─────────────────────────────────────────────── */}
      <Pressable onPress={handleSignOut} style={styles.signOutButton}>
        <Text style={[styles.signOutText, { color: colors.danger }]}>Sign Out</Text>
      </Pressable>
    </ScrollView>
  );
}

function SectionLabel({ children, colors }: { children: string; colors: any }) {
  return (
    <Text style={[styles.sectionLabel, { color: colors.textMuted }]}>{children.toUpperCase()}</Text>
  );
}

function RadioDot({ selected, colors }: { selected: boolean; colors: any }) {
  return (
    <View style={[
      styles.radioOuter,
      { borderColor: selected ? colors.accent : colors.border },
    ]}>
      {selected && <View style={[styles.radioInner, { backgroundColor: colors.accent }]} />}
    </View>
  );
}

function wifiModeLabel(mode: WifiMode): string {
  switch (mode) {
    case 'wifi_only': return 'Upload only on Wi-Fi';
    case 'wifi_and_mobile': return 'Wi-Fi and Mobile Data';
    case 'paused': return 'Pause uploads';
  }
}

const styles = StyleSheet.create({
  container: { paddingBottom: spacing.xxxl },
  sectionLabel: {
    fontSize: typography.scale.micro, fontWeight: '700', letterSpacing: 0.8,
    marginHorizontal: spacing.lg, marginTop: spacing.xl, marginBottom: spacing.sm,
  },
  card: { marginHorizontal: spacing.lg, padding: 0, overflow: 'hidden' },
  accountCard: { marginHorizontal: spacing.lg, flexDirection: 'row', alignItems: 'center' },
  accountName: { fontSize: typography.scale.body, fontWeight: '700' },
  accountEmail: { fontSize: typography.scale.caption, marginTop: 2 },

  optionRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.lg,
  },
  optionLabel: { fontSize: typography.scale.body, fontWeight: '500' },
  divider: { height: StyleSheet.hairlineWidth, marginHorizontal: spacing.lg },

  sliderHeader: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingTop: spacing.lg,
  },
  sliderValue: { fontSize: typography.scale.body, fontWeight: '700' },
  helperText: {
    fontSize: typography.scale.micro, lineHeight: 16,
    paddingHorizontal: spacing.lg, paddingBottom: spacing.lg,
  },

  switchRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.lg,
  },

  radioOuter: {
    width: 20, height: 20, borderRadius: 10, borderWidth: 2,
    alignItems: 'center', justifyContent: 'center',
  },
  radioInner: { width: 10, height: 10, borderRadius: 5 },

  signOutButton: { alignItems: 'center', marginTop: spacing.xxl },
  signOutText: { fontSize: typography.scale.body, fontWeight: '700' },
});
