import React, { useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useTheme } from '../theme/useTheme';
import { spacing, radius, typography } from '../theme/tokens';
import { useTripStore } from '../store/tripStore';
import { tripsApi } from '../services/api';
import { Button, Card, EmptyState } from '../components/common/UI';
import { formatBytes, formatDate } from '../utils/format';

export default function HomeScreen({ navigation }: any) {
  const { colors } = useTheme();
  const activeTrip = useTripStore(s => s.activeTrip);
  const loadActiveTrip = useTripStore(s => s.loadActiveTrip);

  const [pastTrips, setPastTrips] = React.useState<any[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  useFocusEffect(
    useCallback(() => {
      (async () => {
        setIsLoading(true);
        await loadActiveTrip();
        try {
          const { data } = await tripsApi.list();
          setPastTrips(data.filter((t: any) => t.status === 'ended'));
        } catch { /* offline – ignore */ }
        setIsLoading(false);
      })();
    }, [])
  );

  // Redirect to dashboard if a trip is already active
  useFocusEffect(
    useCallback(() => {
      if (activeTrip) {
        navigation.replace('TripDashboard');
      }
    }, [activeTrip?.id])
  );

  if (isLoading) {
    return (
      <View style={[styles.centered, { backgroundColor: colors.bg }]}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={styles.container}>
      <Text style={[styles.eyebrow, { color: colors.textMuted }]}>TRAVELFLOW</Text>
      <Text style={[styles.title, { color: colors.textPrimary }]}>Ready when you are</Text>
      <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
        Start a trip to begin automatic backup of your photos and videos.
      </Text>

      <Button
        label="Start Trip"
        onPress={() => navigation.navigate('StartTrip')}
        style={{ marginTop: spacing.xl }}
      />

      {pastTrips.length > 0 && (
        <>
          <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Past trips</Text>
          {pastTrips.map(trip => (
            <Card key={trip.id} style={styles.pastTripCard}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.pastTripName, { color: colors.textPrimary }]}>{trip.name}</Text>
                <Text style={[styles.pastTripMeta, { color: colors.textMuted }]}>
                  {formatDate(trip.start_date)} · {trip.photo_count + trip.video_count} items
                </Text>
              </View>
              <Text style={[styles.pastTripFreed, { color: colors.success }]}>
                {formatBytes(trip.total_freed_bytes)}
              </Text>
            </Card>
          ))}
        </>
      )}

      {pastTrips.length === 0 && (
        <EmptyState
          title="No trips yet"
          message="Your trip history will appear here"
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: spacing.lg, paddingTop: spacing.xxl, paddingBottom: spacing.xxxl },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  eyebrow: { fontSize: typography.scale.micro, fontWeight: '700', letterSpacing: 1 },
  title: { fontSize: typography.scale.display, fontWeight: '700', marginTop: 4 },
  subtitle: { fontSize: typography.scale.body, marginTop: spacing.sm, lineHeight: 21 },

  sectionTitle: {
    fontSize: typography.scale.h3, fontWeight: '700',
    marginTop: spacing.xxl, marginBottom: spacing.md,
  },
  pastTripCard: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm },
  pastTripName: { fontSize: typography.scale.body, fontWeight: '600' },
  pastTripMeta: { fontSize: typography.scale.micro, marginTop: 2 },
  pastTripFreed: { fontSize: typography.scale.body, fontWeight: '700' },
});
