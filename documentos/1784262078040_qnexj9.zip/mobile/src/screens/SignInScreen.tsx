import React, { useState } from 'react';
import { View, Text, StyleSheet, Alert, Image } from 'react-native';
import { useTheme } from '../theme/useTheme';
import { spacing, typography } from '../theme/tokens';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/common/UI';

export default function SignInScreen() {
  const { colors } = useTheme();
  const { signIn, isSigningIn } = useAuth();

  const handleSignIn = async () => {
    try {
      await signIn();
    } catch (err: any) {
      Alert.alert('Sign-in failed', err?.message ?? 'Please try again.');
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.bg }]}>
      <View style={styles.hero}>
        <View style={[styles.logoMark, { backgroundColor: colors.accent }]}>
          <Text style={styles.logoGlyph}>◈</Text>
        </View>
        <Text style={[styles.title, { color: colors.textPrimary }]}>TravelFlow</Text>
        <Text style={[styles.tagline, { color: colors.textSecondary }]}>
          Travel light. We'll handle the storage.
        </Text>
      </View>

      <View style={styles.features}>
        <Feature colors={colors} text="Keeps using your phone's camera app" />
        <Feature colors={colors} text="Backs up to your own Google Drive" />
        <Feature colors={colors} text="Frees space automatically, only after it's safe" />
      </View>

      <View style={{ flex: 1 }} />

      <Button
        label="Continue with Google"
        onPress={handleSignIn}
        loading={isSigningIn}
        style={styles.signInButton}
      />
      <Text style={[styles.disclaimer, { color: colors.textMuted }]}>
        We only access files TravelFlow creates in your Drive — nothing else.
      </Text>
    </View>
  );
}

function Feature({ text, colors }: { text: string; colors: any }) {
  return (
    <View style={styles.featureRow}>
      <View style={[styles.featureDot, { backgroundColor: colors.accent }]} />
      <Text style={[styles.featureText, { color: colors.textSecondary }]}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.xl, paddingTop: spacing.xxxl * 1.5 },
  hero: { alignItems: 'center' },
  logoMark: {
    width: 64, height: 64, borderRadius: 20,
    alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg,
  },
  logoGlyph: { fontSize: 28, color: '#FFF' },
  title: { fontSize: typography.scale.display, fontWeight: '700' },
  tagline: { fontSize: typography.scale.body, marginTop: spacing.sm, textAlign: 'center' },

  features: { marginTop: spacing.xxxl, gap: spacing.lg, paddingHorizontal: spacing.md },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  featureDot: { width: 6, height: 6, borderRadius: 3 },
  featureText: { fontSize: typography.scale.body, flex: 1 },

  signInButton: { marginBottom: spacing.md },
  disclaimer: {
    fontSize: typography.scale.micro, textAlign: 'center',
    marginBottom: spacing.xl, paddingHorizontal: spacing.lg, lineHeight: 16,
  },
});
