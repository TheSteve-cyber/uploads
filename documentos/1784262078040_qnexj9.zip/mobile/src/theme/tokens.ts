/**
 * TravelFlow Design Tokens
 * ────────────────────────
 * Signature concept: "Field Log" — the visual language of a travel journal
 * crossed with a flight-tracker display. Warm paper tones for content,
 * a deep "night-map" ink for chrome, and a signal-orange accent borrowed
 * from luggage tags and expedition gear (not the cream/terracotta default —
 * this skews darker and more instrument-panel, with the accent used only
 * for live/active states, like a beacon).
 *
 * Signature element: the animated "sync beacon" — a small pulsing dot-and-ring
 * that appears next to anything actively syncing, echoing a GPS ping.
 */

export const palette = {
  // Night-map ink — chrome, headers, nav
  ink900: '#12181F',
  ink800: '#1B242E',
  ink700: '#26313D',
  ink600: '#3A4854',

  // Paper — content surfaces
  paper50: '#FAF7F0',
  paper100: '#F2EDE1',
  paper200: '#E6DDC9',

  // Signal orange — the beacon accent, used sparingly for active/live states
  signal500: '#FF6B35',
  signal400: '#FF8A5C',
  signal100: '#FFE4D6',

  // Compass teal — secondary accent, used for completed/verified states
  teal500: '#2A9D8F',
  teal400: '#4DB6A8',
  teal100: '#D9F0ED',

  // Functional
  amber500: '#E8A33D',   // waiting/paused
  red500: '#D64545',     // failed/error
  neutral400: '#8C93A0',
  neutral300: '#B8BEC7',

  white: '#FFFFFF',
  overlay: 'rgba(18, 24, 31, 0.6)',
} as const;

export interface ThemeColors {
  bg: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  accent: string;
  accentSoft: string;
  success: string;
  successSoft: string;
  warning: string;
  danger: string;
  chrome: string;
  chromeText: string;
}

export const lightTheme: ThemeColors = {
  bg: palette.paper50,
  surface: palette.white,
  surfaceAlt: palette.paper100,
  border: palette.paper200,
  textPrimary: palette.ink900,
  textSecondary: palette.ink600,
  textMuted: palette.neutral400,
  accent: palette.signal500,
  accentSoft: palette.signal100,
  success: palette.teal500,
  successSoft: palette.teal100,
  warning: palette.amber500,
  danger: palette.red500,
  chrome: palette.ink900,
  chromeText: palette.paper50,
};

export const darkTheme: ThemeColors = {
  bg: palette.ink900,
  surface: palette.ink800,
  surfaceAlt: palette.ink700,
  border: palette.ink600,
  textPrimary: palette.paper50,
  textSecondary: palette.neutral300,
  textMuted: palette.neutral400,
  accent: palette.signal400,
  accentSoft: 'rgba(255,107,53,0.16)',
  success: palette.teal400,
  successSoft: 'rgba(42,157,143,0.16)',
  warning: palette.amber500,
  danger: '#E86A6A',
  chrome: palette.ink900,
  chromeText: palette.paper50,
};

// ── Typography ────────────────────────────────────────────────────────────────
// Display: a condensed, slightly technical grotesk for numbers/headers (stats
// should feel like a departures board). Body: a warm humanist sans for
// readability. Using system-safe fallbacks since custom fonts require
// native linking — swap in actual font files via react-native.config.js.

export const typography = {
  display: {
    fontFamily: 'sans-serif-condensed', // Android system condensed grotesk
    fontWeight: '700' as const,
  },
  body: {
    fontFamily: 'sans-serif',
    fontWeight: '400' as const,
  },
  mono: {
    fontFamily: 'monospace', // Timeline timestamps, checksums
    fontWeight: '400' as const,
  },

  scale: {
    display: 40,
    h1: 28,
    h2: 22,
    h3: 18,
    body: 15,
    caption: 13,
    micro: 11,
  },
};

// ── Spacing (4px base grid) ──────────────────────────────────────────────────

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
  xl: 28,
  pill: 999,
};

export const elevation = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 4,
  },
};
