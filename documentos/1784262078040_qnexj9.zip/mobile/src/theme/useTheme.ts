import { useColorScheme } from 'react-native';
import { lightTheme, darkTheme, ThemeColors } from './tokens';
import { useSettingsStore } from '../store/settingsStore';

export function useTheme(): { colors: ThemeColors; isDark: boolean } {
  const systemScheme = useColorScheme();
  const darkModePref = useSettingsStore(s => s.darkMode);

  const isDark = darkModePref === 'system'
    ? systemScheme === 'dark'
    : darkModePref === 'dark';

  return { colors: isDark ? darkTheme : lightTheme, isDark };
}
