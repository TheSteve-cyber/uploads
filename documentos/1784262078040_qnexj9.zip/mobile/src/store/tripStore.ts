import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { tripsApi } from '../services/api';

export interface Trip {
  id: string;
  user_id: string;
  name: string;
  destination: string | null;
  start_date: string | null;
  end_date: string | null;
  status: 'active' | 'ended';
  drive_folder_id: string | null;
  photo_count: number;
  video_count: number;
  total_uploaded_bytes: number;
  total_freed_bytes: number;
  created_at: number;
  ended_at: number | null;
}

export interface TripSummary {
  photos: number;
  videos: number;
  totalUploadedBytes: number;
  totalFreedBytes: number;
  durationDays: number;
  failedUploads: number;
}

interface TripState {
  activeTrip: Trip | null;
  isLoading: boolean;
  lastSummary: { trip: Trip; summary: TripSummary } | null;

  loadActiveTrip: () => Promise<void>;
  startTrip: (data: { name: string; destination?: string; startDate?: string; endDate?: string }) => Promise<Trip>;
  endTrip: () => Promise<void>;
  refreshTrip: () => Promise<void>;
  clearSummary: () => void;
}

export const useTripStore = create<TripState>((set, get) => ({
  activeTrip: null,
  isLoading: false,
  lastSummary: null,

  loadActiveTrip: async () => {
    set({ isLoading: true });
    try {
      const { data } = await tripsApi.active();
      set({ activeTrip: data, isLoading: false });
      if (data) {
        await AsyncStorage.setItem('@travelflow/activeTrip', JSON.stringify(data));
        await AsyncStorage.setItem('trip_active', 'true'); // For native BootReceiver check
      }
    } catch {
      // Fallback to cached trip if offline
      const cached = await AsyncStorage.getItem('@travelflow/activeTrip');
      set({ activeTrip: cached ? JSON.parse(cached) : null, isLoading: false });
    }
  },

  startTrip: async (data) => {
    const { data: trip } = await tripsApi.create(data);
    set({ activeTrip: trip });
    await AsyncStorage.multiSet([
      ['@travelflow/activeTrip', JSON.stringify(trip)],
      ['trip_active', 'true'],
    ]);
    return trip;
  },

  endTrip: async () => {
    const trip = get().activeTrip;
    if (!trip) return;

    const { data } = await tripsApi.end(trip.id);
    set({ activeTrip: null, lastSummary: data });
    await AsyncStorage.multiRemove(['@travelflow/activeTrip']);
    await AsyncStorage.setItem('trip_active', 'false');
  },

  refreshTrip: async () => {
    const trip = get().activeTrip;
    if (!trip) return;
    try {
      const { data } = await tripsApi.get(trip.id);
      set({ activeTrip: data });
    } catch {
      /* keep stale data on network failure */
    }
  },

  clearSummary: () => set({ lastSummary: null }),
}));
