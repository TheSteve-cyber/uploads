import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type WifiMode = 'wifi_only' | 'wifi_and_mobile' | 'paused';

interface SettingsState {
  wifiMode: WifiMode;
  minBatteryLevel: number;      // 0–100, pause uploads below this unless charging
  minFreeStorageGB: number;     // Trigger auto-sync when free space drops below this
  autoDeleteEnabled: boolean;   // Master switch for local deletion after upload
  darkMode: 'system' | 'light' | 'dark';
  isLoaded: boolean;

  load: () => Promise<void>;
  setWifiMode: (mode: WifiMode) => Promise<void>;
  setMinBatteryLevel: (level: number) => Promise<void>;
  setMinFreeStorageGB: (gb: number) => Promise<void>;
  setAutoDeleteEnabled: (enabled: boolean) => Promise<void>;
  setDarkMode: (mode: 'system' | 'light' | 'dark') => Promise<void>;
}

const STORAGE_KEY = '@travelflow/settings';

const DEFAULTS = {
  wifiMode: 'wifi_only' as WifiMode,
  minBatteryLevel: 15,
  minFreeStorageGB: 20,
  autoDeleteEnabled: true,
  darkMode: 'system' as const,
};

export const useSettingsStore = create<SettingsState>((set, get) => ({
  ...DEFAULTS,
  isLoaded: false,

  load: async () => {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        set({ ...DEFAULTS, ...JSON.parse(raw), isLoaded: true });
      } else {
        set({ isLoaded: true });
      }
    } catch {
      set({ isLoaded: true });
    }
  },

  setWifiMode: async (mode) => {
    set({ wifiMode: mode });
    await persist(get());
  },
  setMinBatteryLevel: async (level) => {
    set({ minBatteryLevel: level });
    await persist(get());
  },
  setMinFreeStorageGB: async (gb) => {
    set({ minFreeStorageGB: gb });
    await persist(get());
  },
  setAutoDeleteEnabled: async (enabled) => {
    set({ autoDeleteEnabled: enabled });
    await persist(get());
  },
  setDarkMode: async (mode) => {
    set({ darkMode: mode });
    await persist(get());
  },
}));

async function persist(state: SettingsState) {
  const { wifiMode, minBatteryLevel, minFreeStorageGB, autoDeleteEnabled, darkMode } = state;
  await AsyncStorage.setItem(
    STORAGE_KEY,
    JSON.stringify({ wifiMode, minBatteryLevel, minFreeStorageGB, autoDeleteEnabled, darkMode })
  );
}
