import { create } from 'zustand';
import {
  QueueItem, loadQueue, addToQueue, getFullQueue,
  getPendingItems, invalidateCache,
} from '../services/queueService';

interface QueueState {
  items: QueueItem[];
  isSyncing: boolean;
  currentUploadId: string | null;

  refresh: (tripId?: string) => Promise<void>;
  addItem: (item: Omit<QueueItem, 'status' | 'progress' | 'bytesUploaded' | 'retries' | 'addedAt'>) => Promise<void>;
  setSyncing: (syncing: boolean) => void;
  setCurrentUpload: (id: string | null) => void;

  // Derived getters
  waitingCount: () => number;
  uploadingCount: () => number;
  failedCount: () => number;
  completedCount: () => number;
  totalBytesUploaded: () => number;
  totalBytesFreed: () => number;
}

export const useQueueStore = create<QueueState>((set, get) => ({
  items: [],
  isSyncing: false,
  currentUploadId: null,

  refresh: async (tripId) => {
    invalidateCache();
    const items = await getFullQueue(tripId);
    // Sort: uploading/waiting first, then by addedAt desc
    items.sort((a, b) => {
      const statusOrder = { uploading: 0, verifying: 0, deleting: 0, waiting: 1, failed: 2, completed: 3 };
      const aOrder = statusOrder[a.status] ?? 4;
      const bOrder = statusOrder[b.status] ?? 4;
      if (aOrder !== bOrder) return aOrder - bOrder;
      return b.addedAt - a.addedAt;
    });
    set({ items });
  },

  addItem: async (item) => {
    await addToQueue(item);
    await get().refresh(item.tripId);
  },

  setSyncing: (syncing) => set({ isSyncing: syncing }),
  setCurrentUpload: (id) => set({ currentUploadId: id }),

  waitingCount: () => get().items.filter(i => i.status === 'waiting').length,
  uploadingCount: () => get().items.filter(i =>
    i.status === 'uploading' || i.status === 'verifying' || i.status === 'deleting'
  ).length,
  failedCount: () => get().items.filter(i => i.status === 'failed').length,
  completedCount: () => get().items.filter(i => i.status === 'completed').length,

  totalBytesUploaded: () => get().items
    .filter(i => i.status === 'completed')
    .reduce((sum, i) => sum + i.fileSize, 0),

  totalBytesFreed: () => get().items
    .filter(i => i.status === 'completed')
    .reduce((sum, i) => sum + i.fileSize, 0),
}));
