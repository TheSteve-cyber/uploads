import AsyncStorage from '@react-native-async-storage/async-storage';

const QUEUE_KEY = '@travelflow/uploadQueue';

export type UploadStatus =
  | 'waiting'
  | 'uploading'
  | 'verifying'
  | 'completed'
  | 'failed'
  | 'deleting';

export interface QueueItem {
  id: string;           // local UUID
  sessionId?: string;   // backend session ID (set after initiate)
  tripId: string;
  mediaId: string;      // Android MediaStore ID
  uri: string;          // content:// URI
  fileName: string;
  fileSize: number;
  mimeType: string;
  checksum?: string;
  status: UploadStatus;
  progress: number;     // 0–100
  bytesUploaded: number;
  driveFileId?: string;
  resumableUri?: string;
  error?: string;
  retries: number;
  addedAt: number;      // ms timestamp
  completedAt?: number;
}

// ── In-memory cache ──────────────────────────────────────────────────────────
let memCache: QueueItem[] | null = null;

export async function loadQueue(): Promise<QueueItem[]> {
  if (memCache) return memCache;
  try {
    const raw = await AsyncStorage.getItem(QUEUE_KEY);
    memCache = raw ? JSON.parse(raw) : [];
    return memCache!;
  } catch {
    return [];
  }
}

async function saveQueue(queue: QueueItem[]): Promise<void> {
  memCache = queue;
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
}

export async function addToQueue(item: Omit<QueueItem, 'status' | 'progress' | 'bytesUploaded' | 'retries' | 'addedAt'>): Promise<QueueItem> {
  const queue = await loadQueue();
  const newItem: QueueItem = {
    ...item,
    status: 'waiting',
    progress: 0,
    bytesUploaded: 0,
    retries: 0,
    addedAt: Date.now(),
  };
  queue.push(newItem);
  await saveQueue(queue);
  return newItem;
}

export async function updateQueueItem(
  id: string,
  updates: Partial<QueueItem>
): Promise<QueueItem | null> {
  const queue = await loadQueue();
  const idx = queue.findIndex(item => item.id === id);
  if (idx === -1) return null;
  queue[idx] = { ...queue[idx], ...updates };
  await saveQueue(queue);
  return queue[idx];
}

export async function removeQueueItem(id: string): Promise<void> {
  const queue = await loadQueue();
  const filtered = queue.filter(item => item.id !== id);
  await saveQueue(filtered);
}

export async function getQueueItem(id: string): Promise<QueueItem | null> {
  const queue = await loadQueue();
  return queue.find(item => item.id === id) ?? null;
}

/** Items waiting to be picked up and uploaded. */
export async function getPendingItems(tripId?: string): Promise<QueueItem[]> {
  const queue = await loadQueue();
  return queue.filter(item =>
    (item.status === 'waiting' || item.status === 'failed' && item.retries < 3) &&
    (!tripId || item.tripId === tripId)
  );
}

/** Remove all completed items (housekeeping, call periodically). */
export async function pruneCompleted(): Promise<void> {
  const queue = await loadQueue();
  const pruned = queue.filter(
    item => item.status !== 'completed' ||
    // Keep completed items for 24 hours for the timeline view
    (Date.now() - (item.completedAt ?? 0)) < 24 * 60 * 60 * 1000
  );
  await saveQueue(pruned);
}

/** Clear the in-memory cache (force reload from storage). */
export function invalidateCache(): void {
  memCache = null;
}

/** Full queue for display (all statuses). */
export async function getFullQueue(tripId?: string): Promise<QueueItem[]> {
  const queue = await loadQueue();
  if (!tripId) return queue;
  return queue.filter(item => item.tripId === tripId);
}
