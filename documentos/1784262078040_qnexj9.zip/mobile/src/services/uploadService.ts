import { Platform } from 'react-native';
import RNFS from 'react-native-fs';
import { uploadsApi } from './api';
import { updateQueueItem, QueueItem } from './queueService';
import MediaSync, { DeleteResult } from '../modules/MediaSync';

const CHUNK_SIZE = 5 * 1024 * 1024; // 5 MB
const SMALL_FILE_THRESHOLD = 5 * 1024 * 1024;

// ── Checksum ─────────────────────────────────────────────────────────────────

/**
 * Compute SHA-256 of a local file. Delegates to the native module, which
 * streams the content:// URI in 8KB chunks via MessageDigest — the file is
 * never fully loaded into JS memory, which matters for multi-hundred-MB
 * videos.
 */
export async function computeFileChecksum(uri: string): Promise<string> {
  try {
    return await MediaSync.computeFileChecksum(uri);
  } catch (err) {
    console.warn('[Upload] Checksum failed, proceeding without it:', err);
    return '';
  }
}

// ── Initiate Session ──────────────────────────────────────────────────────────

export async function initiateUploadSession(item: QueueItem): Promise<{
  sessionId: string;
  resumableUri: string | null;
  uploadType: 'direct' | 'resumable';
}> {
  const { data } = await uploadsApi.initiate({
    tripId: item.tripId,
    fileName: item.fileName,
    fileSize: item.fileSize,
    mimeType: item.mimeType,
    checksum: item.checksum,
  });

  await updateQueueItem(item.id, { sessionId: data.sessionId, resumableUri: data.resumableUri });

  return {
    sessionId: data.sessionId,
    resumableUri: data.resumableUri ?? null,
    uploadType: data.uploadType,
  };
}

// ── Direct Upload (< 5 MB) ────────────────────────────────────────────────────

export async function uploadDirect(
  item: QueueItem,
  sessionId: string,
  onProgress: (pct: number) => void
): Promise<{ driveFileId: string }> {
  const filePath = item.uri.replace('content://', '').startsWith('/')
    ? item.uri
    : await resolveContentUri(item.uri);

  const formData = new FormData();
  formData.append('file', {
    uri: item.uri,
    name: item.fileName,
    type: item.mimeType,
  } as any);

  const { data } = await uploadsApi.direct(sessionId, formData);
  onProgress(100);
  return { driveFileId: data.driveFileId };
}

// ── Chunked/Resumable Upload (≥ 5 MB) ─────────────────────────────────────────

export async function uploadChunked(
  item: QueueItem,
  sessionId: string,
  onProgress: (pct: number) => void
): Promise<{ driveFileId: string }> {
  const totalSize = item.fileSize;
  let offset = item.bytesUploaded ?? 0; // Resume support
  let driveFileId = '';

  while (offset < totalSize) {
    const chunkEnd = Math.min(offset + CHUNK_SIZE - 1, totalSize - 1);
    const chunkLength = chunkEnd - offset + 1;

    // Read this slice as base64 (RNFS supports partial reads via length+position),
    // then write it out to a small temp file. React Native's FormData only
    // accepts a 2-argument append(name, value) — unlike the browser DOM API,
    // there is no 3-arg (name, blob, filename) overload — and the value must
    // be a { uri, name, type } descriptor, not a Blob instance. So rather than
    // constructing an in-memory Blob, we hand FormData a uri pointing at this
    // chunk's own temp file, exactly like the whole-file case in uploadDirect()
    // above. The temp file is removed immediately after the chunk is sent.
    const base64Chunk = await RNFS.read(item.uri, chunkLength, offset, 'base64');
    const tempChunkPath = `${RNFS.TemporaryDirectoryPath}/${sessionId}-${offset}.chunk`;
    await RNFS.writeFile(tempChunkPath, base64Chunk, 'base64');

    try {
      const formData = new FormData();
      formData.append('chunk', {
        uri: `file://${tempChunkPath}`,
        name: item.fileName,
        type: item.mimeType,
      } as any);

      const { data } = await uploadsApi.chunk(sessionId, formData, offset, chunkEnd, totalSize);

      offset = chunkEnd + 1;
      const pct = Math.round((offset / totalSize) * 100);
      onProgress(pct);

      await updateQueueItem(item.id, { bytesUploaded: offset, progress: pct });

      if (data.done) {
        driveFileId = data.driveFileId;
        break;
      }
    } finally {
      await RNFS.unlink(tempChunkPath).catch(() => {
        // Best-effort cleanup; a leftover temp chunk is harmless and the OS
        // will reclaim TemporaryDirectoryPath eventually.
      });
    }
  }

  return { driveFileId };
}

// ── Verification ──────────────────────────────────────────────────────────────

export async function verifyUpload(sessionId: string): Promise<boolean> {
  const { data } = await uploadsApi.verify(sessionId);
  return data.verified === true;
}

// ── Local Deletion ─────────────────────────────────────────────────────────────

/**
 * Delete the local copy after successful verification.
 * Handles Android 11+ permission requirement gracefully.
 */
export async function deleteLocalFile(
  item: QueueItem,
  pendingBatchUris: React.MutableRefObject<string[]>
): Promise<{ deleted: boolean; pendingBatch: boolean }> {
  const mediaType: 'image' | 'video' = item.mimeType.startsWith('video/') ? 'video' : 'image';

  const result: DeleteResult = await MediaSync.deleteLocalFile(item.mediaId, mediaType);

  if (result.requiresPermission && result.uri) {
    // Queue this URI for batch system dialog (shown periodically)
    pendingBatchUris.current.push(result.uri);
    return { deleted: false, pendingBatch: true };
  }

  return { deleted: result.success === true, pendingBatch: false };
}

// ── Full Upload Pipeline ───────────────────────────────────────────────────────

export interface UploadResult {
  success: boolean;
  driveFileId?: string;
  error?: string;
  needsBatchDelete?: boolean;
}

export async function runUploadPipeline(
  item: QueueItem,
  pendingBatchUris: React.MutableRefObject<string[]>,
  onProgress: (pct: number) => void
): Promise<UploadResult> {
  try {
    // 1. Compute checksum if not already done
    let checksum = item.checksum;
    if (!checksum) {
      checksum = await computeFileChecksum(item.uri);
      await updateQueueItem(item.id, { checksum });
    }

    // 2. Initiate session
    await updateQueueItem(item.id, { status: 'uploading', progress: 0 });
    const { sessionId, uploadType } = await initiateUploadSession({ ...item, checksum });

    // 3. Upload
    let driveFileId: string;
    if (uploadType === 'direct' || item.fileSize < SMALL_FILE_THRESHOLD) {
      ({ driveFileId } = await uploadDirect({ ...item, checksum }, sessionId, onProgress));
    } else {
      ({ driveFileId } = await uploadChunked({ ...item, checksum }, sessionId, onProgress));
    }

    // 4. Verify on Drive
    await updateQueueItem(item.id, { status: 'verifying', progress: 100 });
    const verified = await verifyUpload(sessionId);

    if (!verified) {
      await uploadsApi.fail(sessionId, 'Drive verification failed');
      throw new Error('Upload verification failed – file may be corrupted');
    }

    // 5. Delete local copy
    await updateQueueItem(item.id, { status: 'deleting', driveFileId });
    const { deleted, pendingBatch } = await deleteLocalFile(item, pendingBatchUris);

    // 6. Mark complete
    await updateQueueItem(item.id, {
      status: 'completed',
      driveFileId,
      progress: 100,
      completedAt: Date.now(),
    });

    return { success: true, driveFileId, needsBatchDelete: pendingBatch };
  } catch (err: any) {
    const errMsg = err?.response?.data?.error ?? err?.message ?? 'Unknown error';
    await updateQueueItem(item.id, {
      status: 'failed',
      error: errMsg,
      retries: (item.retries ?? 0) + 1,
    });
    return { success: false, error: errMsg };
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

async function resolveContentUri(contentUri: string): Promise<string> {
  // content:// URIs can be used directly with fetch on Android
  return contentUri;
}
