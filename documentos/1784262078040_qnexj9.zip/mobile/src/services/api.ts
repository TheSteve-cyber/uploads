import axios, { AxiosInstance, AxiosError } from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE_URL = __DEV__
  ? 'http://10.0.2.2:3000'   // Android emulator → host machine
  : 'https://your-travelflow-api.com';  // Replace with production URL

let isRefreshing = false;
let refreshQueue: Array<(token: string) => void> = [];

function createApiClient(): AxiosInstance {
  const client = axios.create({
    baseURL: BASE_URL,
    timeout: 30_000,
    headers: { 'Content-Type': 'application/json' },
  });

  // ── Request: attach JWT ────────────────────────────────────────────────────
  client.interceptors.request.use(async config => {
    const token = await AsyncStorage.getItem('@travelflow/token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  });

  // ── Response: handle 401 with silent refresh ───────────────────────────────
  client.interceptors.response.use(
    res => res,
    async (error: AxiosError) => {
      const original = error.config as any;

      if (
        error.response?.status === 401 &&
        !original._retry &&
        (error.response?.data as any)?.code === 'TOKEN_EXPIRED'
      ) {
        original._retry = true;

        if (isRefreshing) {
          // Queue this request until refresh is done
          return new Promise(resolve => {
            refreshQueue.push((token: string) => {
              original.headers.Authorization = `Bearer ${token}`;
              resolve(client(original));
            });
          });
        }

        isRefreshing = true;
        try {
          const refreshToken = await AsyncStorage.getItem('@travelflow/refreshToken');
          const { data } = await axios.post(`${BASE_URL}/api/auth/refresh`, { refreshToken });

          await AsyncStorage.multiSet([
            ['@travelflow/token', data.token],
            ['@travelflow/refreshToken', data.refreshToken],
          ]);

          refreshQueue.forEach(cb => cb(data.token));
          refreshQueue = [];

          original.headers.Authorization = `Bearer ${data.token}`;
          return client(original);
        } catch {
          // Refresh failed → force sign-out
          await AsyncStorage.multiRemove(['@travelflow/token', '@travelflow/refreshToken']);
          refreshQueue = [];
          // Signal the auth context to clear user
          return Promise.reject({ ...error, code: 'SESSION_EXPIRED' });
        } finally {
          isRefreshing = false;
        }
      }

      return Promise.reject(error);
    }
  );

  return client;
}

export const api = createApiClient();
export { BASE_URL };

// ── Typed API helpers ──────────────────────────────────────────────────────

export const authApi = {
  googleToken: (payload: { accessToken?: string; serverAuthCode?: string }) =>
    api.post('/api/auth/google/token', payload),
  me: () => api.get('/api/auth/me'),
  refresh: (refreshToken: string) => api.post('/api/auth/refresh', { refreshToken }),
  logout: () => api.post('/api/auth/logout'),
};

export const tripsApi = {
  create: (data: { name: string; destination?: string; startDate?: string; endDate?: string }) =>
    api.post('/api/trips', data),
  list: () => api.get('/api/trips'),
  active: () => api.get('/api/trips/active'),
  get: (id: string) => api.get(`/api/trips/${id}`),
  end: (id: string) => api.post(`/api/trips/${id}/end`),
};

export const uploadsApi = {
  initiate: (data: {
    tripId: string;
    fileName: string;
    fileSize: number;
    mimeType: string;
    checksum?: string;
  }) => api.post('/api/uploads/initiate', data),

  direct: (sessionId: string, formData: FormData) =>
    api.post(`/api/uploads/${sessionId}/direct`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 120_000,
    }),

  chunk: (sessionId: string, formData: FormData, start: number, end: number, total: number) =>
    api.put(`/api/uploads/${sessionId}/chunk`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'Content-Range': `bytes ${start}-${end}/${total}`,
      },
      timeout: 60_000,
    }),

  verify: (sessionId: string) => api.post(`/api/uploads/${sessionId}/verify`),
  fail: (sessionId: string, error: string) =>
    api.post(`/api/uploads/${sessionId}/fail`, { error }),
  status: (sessionId: string) => api.get(`/api/uploads/session/${sessionId}`),
};
