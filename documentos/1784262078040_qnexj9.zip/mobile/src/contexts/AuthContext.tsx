import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import { authApi } from '../services/api';

const GOOGLE_WEB_CLIENT_ID = 'YOUR_GOOGLE_WEB_CLIENT_ID.apps.googleusercontent.com';

export interface User {
  id: string;
  email: string;
  name: string;
  picture?: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isSigningIn: boolean;
}

interface AuthContextValue extends AuthState {
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    token: null,
    isLoading: true,
    isSigningIn: false,
  });

  // ── Init Google Sign-In ──────────────────────────────────────────────────
  useEffect(() => {
    GoogleSignin.configure({
      webClientId: GOOGLE_WEB_CLIENT_ID,
      offlineAccess: true,  // Get serverAuthCode to exchange for refresh_token
      scopes: ['https://www.googleapis.com/auth/drive.file'],
    });
  }, []);

  // ── Restore Session ──────────────────────────────────────────────────────
  useEffect(() => {
    restoreSession();
  }, []);

  const restoreSession = async () => {
    try {
      const [token, userJson] = await AsyncStorage.multiGet([
        '@travelflow/token',
        '@travelflow/user',
      ]);
      const storedToken = token[1];
      const storedUser = userJson[1] ? JSON.parse(userJson[1]) : null;

      if (storedToken && storedUser) {
        // Verify token is still valid
        try {
          const { data } = await authApi.me();
          setState(s => ({ ...s, user: data, token: storedToken, isLoading: false }));
        } catch {
          // Token expired or invalid – clear storage
          await clearStorage();
          setState(s => ({ ...s, isLoading: false }));
        }
      } else {
        setState(s => ({ ...s, isLoading: false }));
      }
    } catch {
      setState(s => ({ ...s, isLoading: false }));
    }
  };

  // ── Sign In ──────────────────────────────────────────────────────────────
  const signIn = useCallback(async () => {
    setState(s => ({ ...s, isSigningIn: true }));
    try {
      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();

      const tokens = await GoogleSignin.getTokens();

      const { data } = await authApi.googleToken({
        accessToken: tokens.accessToken,
        serverAuthCode: userInfo.serverAuthCode ?? undefined,
      });

      await AsyncStorage.multiSet([
        ['@travelflow/token', data.token],
        ['@travelflow/refreshToken', data.refreshToken],
        ['@travelflow/user', JSON.stringify(data.user)],
      ]);

      setState(s => ({
        ...s,
        user: data.user,
        token: data.token,
        isSigningIn: false,
      }));
    } catch (err: any) {
      setState(s => ({ ...s, isSigningIn: false }));

      if (err.code === statusCodes.SIGN_IN_CANCELLED) return;
      if (err.code === statusCodes.IN_PROGRESS) return;
      if (err.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
        throw new Error('Google Play Services not available');
      }
      throw err;
    }
  }, []);

  // ── Sign Out ─────────────────────────────────────────────────────────────
  const signOut = useCallback(async () => {
    try {
      await authApi.logout();
    } catch { /* ignore */ }

    try {
      await GoogleSignin.signOut();
    } catch { /* ignore */ }

    await clearStorage();
    setState({ user: null, token: null, isLoading: false, isSigningIn: false });
  }, []);

  return (
    <AuthContext.Provider value={{ ...state, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

async function clearStorage() {
  await AsyncStorage.multiRemove([
    '@travelflow/token',
    '@travelflow/refreshToken',
    '@travelflow/user',
    '@travelflow/activeTrip',
  ]);
}
