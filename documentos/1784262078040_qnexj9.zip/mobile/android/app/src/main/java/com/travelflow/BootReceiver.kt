package com.travelflow

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * Restarts the sync foreground service after device reboot,
 * so monitoring resumes without the user opening the app.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val validActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON"
        )
        if (intent.action !in validActions) return

        // Only restart if a trip was active (check shared prefs)
        val prefs = context.getSharedPreferences("TravelFlowPrefs", Context.MODE_PRIVATE)
        val tripActive = prefs.getBoolean("trip_active", false)

        if (tripActive) {
            Log.i("TravelFlow.Boot", "Restarting sync service after boot")
            val serviceIntent = Intent(context, SyncForegroundService::class.java).apply {
                action = SyncForegroundService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
