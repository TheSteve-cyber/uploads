package com.travelflow

import android.content.Context
import android.util.Log
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * WorkManager worker that handles background uploads when the React Native
 * layer is unavailable (app backgrounded/killed).
 *
 * The JS layer is the primary upload path. This worker handles queued items
 * that were scheduled via MediaSyncModule.scheduleBackgroundUpload().
 */
class UploadWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {

    companion object {
        const val TAG = "TravelFlow.UploadWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val queueJson = inputData.getString("queue_json") ?: return@withContext Result.failure()

        Log.i(TAG, "Starting background upload worker")

        try {
            // Notify foreground service about background upload start
            val prefs = applicationContext.getSharedPreferences("TravelFlowPrefs", 0)
            val authToken = prefs.getString("auth_token", null)
            val apiBase = prefs.getString("api_base_url", null)

            if (authToken == null || apiBase == null) {
                Log.w(TAG, "No auth token or API URL – skipping background upload")
                return@withContext Result.success()
            }

            // The queue JSON is an array of { sessionId, filePath, mimeType, fileSize }
            // Each item was already initiated on the backend – we just need to stream the bytes
            val items = parseQueueJson(queueJson)

            var failed = 0
            for (item in items) {
                try {
                    uploadItem(item, authToken, apiBase)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to upload ${item["fileName"]}: ${e.message}")
                    failed++
                }
            }

            if (failed > 0 && failed == items.size) {
                Log.w(TAG, "All uploads failed, scheduling retry")
                return@withContext Result.retry()
            }

            Log.i(TAG, "Background upload complete. Failed: $failed/${items.size}")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Worker fatal error: ${e.message}", e)
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    private suspend fun uploadItem(
        item: Map<String, String>,
        authToken: String,
        apiBase: String
    ) = withContext(Dispatchers.IO) {
        val sessionId = item["sessionId"] ?: return@withContext
        val filePath = item["filePath"] ?: return@withContext
        val mimeType = item["mimeType"] ?: "application/octet-stream"
        val resumableUri = item["resumableUri"]

        val file = File(filePath)
        if (!file.exists()) {
            Log.w(TAG, "File not found: $filePath")
            markFailed(sessionId, "File not found", authToken, apiBase)
            return@withContext
        }

        val fileSize = file.length()

        if (resumableUri != null) {
            // Chunked upload via resumable URI
            uploadInChunks(file, mimeType, resumableUri, sessionId, fileSize, authToken, apiBase)
        } else {
            // Direct upload endpoint
            uploadDirect(file, mimeType, sessionId, authToken, apiBase)
        }
    }

    private fun uploadDirect(
        file: File, mimeType: String, sessionId: String,
        authToken: String, apiBase: String
    ) {
        val boundary = "TravelFlow${System.currentTimeMillis()}"
        val url = URL("$apiBase/api/uploads/$sessionId/direct")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Authorization", "Bearer $authToken")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }

        conn.outputStream.use { out ->
            val header = "--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"${file.name}\"\r\nContent-Type: $mimeType\r\n\r\n".toByteArray()
            val footer = "\r\n--$boundary--\r\n".toByteArray()
            out.write(header)
            file.inputStream().use { it.copyTo(out) }
            out.write(footer)
        }

        val code = conn.responseCode
        conn.disconnect()
        if (code !in 200..299) throw Exception("Direct upload failed: HTTP $code")
        Log.d(TAG, "Direct upload OK for session $sessionId")
    }

    private fun uploadInChunks(
        file: File, mimeType: String, resumableUri: String,
        sessionId: String, totalSize: Long, authToken: String, apiBase: String
    ) {
        val chunkSize = 5 * 1024 * 1024 // 5 MB
        var offset = 0L
        file.inputStream().use { input ->
            val buffer = ByteArray(chunkSize)
            while (offset < totalSize) {
                val read = input.read(buffer)
                if (read == -1) break
                val chunk = buffer.copyOf(read)
                val end = offset + read - 1

                val url = URL("$apiBase/api/uploads/$sessionId/chunk")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "PUT"
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $authToken")
                    setRequestProperty("Content-Type", mimeType)
                    setRequestProperty("Content-Range", "bytes $offset-$end/$totalSize")
                    setRequestProperty("Content-Length", read.toString())
                }
                conn.outputStream.use { it.write(chunk, 0, read) }
                val code = conn.responseCode
                conn.disconnect()

                if (code !in 200..209 && code != 308) {
                    throw Exception("Chunk upload failed at offset $offset: HTTP $code")
                }
                offset += read
            }
        }
        Log.d(TAG, "Chunked upload complete for session $sessionId")
    }

    private fun markFailed(sessionId: String, error: String, authToken: String, apiBase: String) {
        try {
            val url = URL("$apiBase/api/uploads/$sessionId/fail")
            val body = """{"error":"$error"}""".toByteArray()
            (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Authorization", "Bearer $authToken")
                setRequestProperty("Content-Type", "application/json")
                outputStream.write(body)
                responseCode // Trigger the request
                disconnect()
            }
        } catch (_: Exception) {}
    }

    private fun parseQueueJson(json: String): List<Map<String, String>> {
        // Minimal JSON parser for upload queue items
        // In production, use a proper JSON library (Gson is already included via RN)
        return try {
            val result = mutableListOf<Map<String, String>>()
            // Basic extraction – replace with Gson if available in worker context
            val pattern = Regex(""""(\w+)"\s*:\s*"([^"]*)"?""")
            val itemPattern = Regex("""\{([^}]+)\}""")
            itemPattern.findAll(json).forEach { match ->
                val item = mutableMapOf<String, String>()
                pattern.findAll(match.groupValues[1]).forEach { p ->
                    item[p.groupValues[1]] = p.groupValues[2]
                }
                if (item.isNotEmpty()) result.add(item)
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse queue JSON", e)
            emptyList()
        }
    }
}
