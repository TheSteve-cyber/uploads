package com.travelflow

import android.app.Activity
import android.content.Intent
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate

class MainActivity : ReactActivity() {

  /**
   * Returns the name of the main component registered from JavaScript.
   * This is used to schedule the rendering of the component.
   */
  override fun getMainComponentName(): String = "TravelFlow"

  /**
   * Returns the instance of the [ReactActivityDelegate]. We use [DefaultReactActivityDelegate]
   * which allows you to enable New Architecture with a single boolean flag [fabricEnabled]
   */
  override fun createReactActivityDelegate(): ReactActivityDelegate =
      DefaultReactActivityDelegate(this, mainComponentName, fabricEnabled)

  /**
   * Handles the result of MediaStore.createDeleteRequest() launched from
   * MediaSyncModule.requestBatchDelete(). Resolves the pending JS Promise
   * so the upload pipeline knows whether the user approved the deletion.
   */
  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)

    if (requestCode == MediaSyncModule.REQUEST_DELETE_CODE) {
      val approved = resultCode == Activity.RESULT_OK
      MediaSyncModule.pendingDeletePromise?.resolve(approved)
      MediaSyncModule.pendingDeletePromise = null
    }
  }
}
