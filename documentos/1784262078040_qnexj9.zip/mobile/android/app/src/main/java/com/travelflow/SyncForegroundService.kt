package com.travelflow

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Foreground service that keeps TravelFlow alive during sync.
 * Displays a persistent notification with upload progress.
 */
class SyncForegroundService : Service() {

    companion object {
        const val ACTION_START = "com.travelflow.action.START"
        const val ACTION_STOP = "com.travelflow.action.STOP"
        const val ACTION_UPDATE_NOTIFICATION = "com.travelflow.action.UPDATE"
        const val CHANNEL_ID = "travelflow_sync"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val notification = buildNotification("TravelFlow is active", "Monitoring your photos", 0)
                startForeground(NOTIFICATION_ID, notification)
            }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_UPDATE_NOTIFICATION -> {
                val message = intent.getStringExtra("message") ?: "Syncing..."
                val progress = intent.getIntExtra("progress", 0)
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIFICATION_ID, buildNotification("TravelFlow Sync", message, progress))
            }
        }
        return START_STICKY // Restart if killed by system
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(title: String, text: String, progress: Int): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_upload)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .apply {
                if (progress > 0) {
                    setProgress(100, progress, false)
                } else {
                    setProgress(100, 0, true) // Indeterminate
                }
            }
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "TravelFlow Sync",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background photo sync status"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }
}
