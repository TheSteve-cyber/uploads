package com.travelflow

import android.database.ContentObserver
import android.net.Uri
import android.os.Handler

/**
 * Watches the MediaStore for changes in DCIM and notifies via callback.
 * Debounced to avoid multiple rapid triggers from a single save operation.
 */
class MediaObserver(
    handler: Handler,
    private val onNewMedia: (Uri) -> Unit
) : ContentObserver(handler) {

    private val debounceMs = 500L
    private val debounceRunnable = mutableMapOf<String, Runnable>()
    private val handler = handler

    override fun onChange(selfChange: Boolean, uri: Uri?) {
        super.onChange(selfChange, uri)
        val key = uri?.toString() ?: "unknown"

        // Remove previous debounce for this URI
        debounceRunnable[key]?.let { handler.removeCallbacks(it) }

        val runnable = Runnable {
            uri?.let { onNewMedia(it) }
            debounceRunnable.remove(key)
        }
        debounceRunnable[key] = runnable
        handler.postDelayed(runnable, debounceMs)
    }

    override fun onChange(selfChange: Boolean) {
        onChange(selfChange, null)
    }
}
