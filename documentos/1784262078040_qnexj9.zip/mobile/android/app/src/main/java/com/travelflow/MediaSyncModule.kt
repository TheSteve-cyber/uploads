package com.travelflow

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import androidx.work.*
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class MediaSyncModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    companion object {
        const val MODULE_NAME = "MediaSync"
        const val EVENT_NEW_MEDIA = "onNewMediaDetected"
        const val EVENT_STORAGE_LOW = "onStorageLow"
        const val TAG = "TravelFlow.MediaSync"
        // Shared prefs for persisting last-seen timestamp between app restarts
        const val PREFS_NAME = "TravelFlowPrefs"
        const val PREF_LAST_SCAN = "last_scan_timestamp"
    }

    private var mediaObserver: MediaObserver? = null

    override fun getName() = MODULE_NAME

    // ── Monitoring Control ────────────────────────────────────────────────────

    @ReactMethod
    fun startMonitoring(promise: Promise) {
        try {
            val serviceIntent = Intent(reactContext, SyncForegroundService::class.java).apply {
                action = SyncForegroundService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                reactContext.startForegroundService(serviceIntent)
            } else {
                reactContext.startService(serviceIntent)
            }

            // Register ContentObserver on DCIM/Camera changes
            val handler = Handler(Looper.getMainLooper())
            mediaObserver = MediaObserver(handler) { contentUri ->
                sendEvent(EVENT_NEW_MEDIA, contentUri.toString())
            }

            reactContext.contentResolver.apply {
                registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaObserver!!)
                registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaObserver!!)
            }

            Log.i(TAG, "Media monitoring started")
            promise.resolve(true)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start monitoring", e)
            promise.reject("MONITORING_ERROR", e.message, e)
        }
    }

    @ReactMethod
    fun stopMonitoring(promise: Promise) {
        try {
            mediaObserver?.let {
                reactContext.contentResolver.unregisterContentObserver(it)
                mediaObserver = null
            }
            val intent = Intent(reactContext, SyncForegroundService::class.java).apply {
                action = SyncForegroundService.ACTION_STOP
            }
            reactContext.stopService(intent)
            Log.i(TAG, "Media monitoring stopped")
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("STOP_ERROR", e.message, e)
        }
    }

    // ── Media Queries ─────────────────────────────────────────────────────────

    /**
     * Query MediaStore for new DCIM/Camera files since sinceTimestamp (ms).
     */
    @ReactMethod
    fun getNewMedia(sinceTimestampMs: Double, promise: Promise) {
        try {
            val sinceSeconds = (sinceTimestampMs / 1000).toLong()
            val results = WritableNativeArray()

            val projection = arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.MediaColumns.RELATIVE_PATH
            )

            // Only files inside DCIM (covers Camera, Screenshots, etc.)
            val selection = buildString {
                append("${MediaStore.MediaColumns.DATE_ADDED} > ? AND (")
                append("${MediaStore.MediaColumns.RELATIVE_PATH} LIKE 'DCIM/%'")
                append(")")
            }
            val args = arrayOf(sinceSeconds.toString())
            val sort = "${MediaStore.MediaColumns.DATE_ADDED} ASC"

            queryMediaStore(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort, "image", results)
            queryMediaStore(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort, "video", results)

            promise.resolve(results)
        } catch (e: Exception) {
            Log.e(TAG, "getNewMedia failed", e)
            promise.reject("QUERY_ERROR", e.message, e)
        }
    }

    private fun queryMediaStore(
        uri: Uri, projection: Array<String>, selection: String,
        args: Array<String>, sort: String, type: String,
        results: WritableNativeArray
    ) {
        reactContext.contentResolver.query(uri, projection, selection, args, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val contentUri = ContentUris.withAppendedId(uri, id)
                val map = WritableNativeMap().apply {
                    putString("id", id.toString())
                    putString("uri", contentUri.toString())
                    putString("name", cursor.getString(nameCol))
                    putDouble("size", cursor.getLong(sizeCol).toDouble())
                    putString("mimeType", cursor.getString(mimeCol) ?: "application/octet-stream")
                    putDouble("timestamp", cursor.getLong(dateCol).toDouble() * 1000)
                    putString("relativePath", cursor.getString(pathCol) ?: "")
                    putString("type", type)
                }
                results.pushMap(map)
            }
        }
    }

    // ── Storage Info ──────────────────────────────────────────────────────────

    @ReactMethod
    fun getStorageInfo(promise: Promise) {
        try {
            val path = Environment.getExternalStorageDirectory()
            val stat = StatFs(path.absolutePath)
            val blockSize = stat.blockSizeLong
            val total = stat.blockCountLong * blockSize
            val available = stat.availableBlocksLong * blockSize
            val used = total - available

            promise.resolve(WritableNativeMap().apply {
                putDouble("totalBytes", total.toDouble())
                putDouble("availableBytes", available.toDouble())
                putDouble("usedBytes", used.toDouble())
            })
        } catch (e: Exception) {
            promise.reject("STORAGE_ERROR", e.message, e)
        }
    }

    // ── Battery Info ──────────────────────────────────────────────────────────

    /**
     * Reads battery level (0.0–1.0) and charging state via the system
     * BATTERY_CHANGED sticky broadcast — no extra native dependency required,
     * unlike the equivalent Expo module this replaces.
     */
    @ReactMethod
    fun getBatteryInfo(promise: Promise) {
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = reactContext.registerReceiver(null, filter)

            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

            val batteryPct = if (level >= 0 && scale > 0) level.toFloat() / scale.toFloat() else -1f
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

            promise.resolve(WritableNativeMap().apply {
                putDouble("level", batteryPct.toDouble()) // 0.0–1.0, matches expo-battery's convention
                putBoolean("isCharging", isCharging)
            })
        } catch (e: Exception) {
            Log.e(TAG, "getBatteryInfo failed", e)
            promise.reject("BATTERY_ERROR", e.message, e)
        }
    }

    // ── File Checksum ─────────────────────────────────────────────────────────

    /**
     * Computes SHA-256 of a content:// URI in streamed 8KB chunks so large
     * video files never need to be fully loaded into memory. Replaces the
     * equivalent expo-crypto call with a zero-dependency native path,
     * consistent with the rest of this module.
     */
    @ReactMethod
    fun computeFileChecksum(contentUri: String, promise: Promise) {
        Thread {
            var input: InputStream? = null
            try {
                val uri = Uri.parse(contentUri)
                input = reactContext.contentResolver.openInputStream(uri)
                    ?: throw Exception("Could not open input stream for $contentUri")

                val digest = MessageDigest.getInstance("SHA-256")
                val buffer = ByteArray(8192)
                var bytesRead: Int

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    digest.update(buffer, 0, bytesRead)
                }

                val hashHex = digest.digest().joinToString("") { "%02x".format(it) }
                promise.resolve(hashHex)
            } catch (e: Exception) {
                Log.e(TAG, "computeFileChecksum failed", e)
                promise.reject("CHECKSUM_ERROR", e.message, e)
            } finally {
                input?.close()
            }
        }.start()
    }

    // ── File Deletion ─────────────────────────────────────────────────────────

    /**
     * Delete a local file after successful upload verification.
     * Android 11+: returns requiresPermission=true and the content URI.
     *              The JS layer must call requestBatchDelete() to show the system dialog.
     * Android ≤ 10: deletes directly via ContentResolver.
     */
    @ReactMethod
    fun deleteLocalFile(mediaId: String, mediaType: String, promise: Promise) {
        try {
            val baseUri = if (mediaType == "video")
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI

            val contentUri = ContentUris.withAppendedId(baseUri, mediaId.toLong())

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Android 11+: batch delete requires a system dialog
                promise.resolve(WritableNativeMap().apply {
                    putBoolean("requiresPermission", true)
                    putString("uri", contentUri.toString())
                    putString("mediaId", mediaId)
                })
            } else {
                val deleted = reactContext.contentResolver.delete(contentUri, null, null)
                promise.resolve(WritableNativeMap().apply {
                    putBoolean("requiresPermission", false)
                    putBoolean("success", deleted > 0)
                    putString("mediaId", mediaId)
                })
            }
        } catch (e: Exception) {
            Log.e(TAG, "deleteLocalFile failed", e)
            promise.reject("DELETE_ERROR", e.message, e)
        }
    }

    /**
     * Request batch delete for Android 11+ (shows system confirmation dialog).
     * mediaUris: array of content:// URI strings
     */
    @ReactMethod
    fun requestBatchDelete(mediaUrisArray: ReadableArray, promise: Promise) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            promise.resolve(false)
            return
        }
        try {
            val uris = ArrayList<Uri>()
            for (i in 0 until mediaUrisArray.size()) {
                uris.add(Uri.parse(mediaUrisArray.getString(i)))
            }
            val pendingIntent = MediaStore.createDeleteRequest(reactContext.contentResolver, uris)
            // The intent needs to be launched from an Activity
            currentActivity?.startIntentSenderForResult(
                pendingIntent.intentSender,
                REQUEST_DELETE_CODE,
                null, 0, 0, 0
            ) ?: promise.reject("NO_ACTIVITY", "No active Activity to show delete dialog")
            // Result handled in MainActivity via onActivityResult → bridge
            pendingDeletePromise = promise
        } catch (e: Exception) {
            promise.reject("BATCH_DELETE_ERROR", e.message, e)
        }
    }

    // ── WorkManager ───────────────────────────────────────────────────────────

    @ReactMethod
    fun scheduleBackgroundUpload(queueJson: String, wifiOnly: Boolean, promise: Promise) {
        try {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .build()

            val data = Data.Builder()
                .putString("queue_json", queueJson)
                .build()

            val workRequest = OneTimeWorkRequestBuilder<UploadWorker>()
                .setInputData(data)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.MINUTES)
                .addTag("travelflow_upload")
                .build()

            WorkManager.getInstance(reactContext)
                .enqueueUniqueWork("travelflow_sync", ExistingWorkPolicy.APPEND_OR_REPLACE, workRequest)

            Log.d(TAG, "Background upload scheduled")
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("SCHEDULE_ERROR", e.message, e)
        }
    }

    // ── Notification Control ──────────────────────────────────────────────────

    @ReactMethod
    fun updateSyncNotification(message: String, progress: Int, promise: Promise) {
        try {
            val intent = Intent(reactContext, SyncForegroundService::class.java).apply {
                action = SyncForegroundService.ACTION_UPDATE_NOTIFICATION
                putExtra("message", message)
                putExtra("progress", progress)
            }
            reactContext.startService(intent)
            promise.resolve(true)
        } catch (e: Exception) {
            promise.resolve(false) // Non-critical
        }
    }

    // ── Last Scan Persistence ─────────────────────────────────────────────────

    @ReactMethod
    fun getLastScanTimestamp(promise: Promise) {
        val prefs = reactContext.getSharedPreferences(PREFS_NAME, 0)
        val ts = prefs.getLong(PREF_LAST_SCAN, 0L)
        promise.resolve(ts.toDouble())
    }

    @ReactMethod
    fun setLastScanTimestamp(timestampMs: Double, promise: Promise) {
        reactContext.getSharedPreferences(PREFS_NAME, 0)
            .edit()
            .putLong(PREF_LAST_SCAN, timestampMs.toLong())
            .apply()
        promise.resolve(true)
    }

    // ── Event Bridge ──────────────────────────────────────────────────────────

    private fun sendEvent(eventName: String, data: String) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(eventName, data)
    }

    // Required for NativeEventEmitter
    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}

    companion object {
        const val REQUEST_DELETE_CODE = 7777
        var pendingDeletePromise: Promise? = null
    }
}
