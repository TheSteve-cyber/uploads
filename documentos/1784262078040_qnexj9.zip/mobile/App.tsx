import React, { useEffect, useState } from 'react';
import { StatusBar, LogBox } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { PaperProvider } from 'react-native-paper';
import { AuthProvider } from './src/contexts/AuthContext';
import { useSettingsStore } from './src/store/settingsStore';
import { useTripStore } from './src/store/tripStore';
import { useTheme } from './src/theme/useTheme';
import RootNavigator from './src/navigation/RootNavigator';

// react-native-reanimated must be imported once at the entry point
import 'react-native-reanimated';

LogBox.ignoreLogs(['new NativeEventEmitter']); // Expected on native modules without addListener warnings

function AppShell() {
  const { colors, isDark } = useTheme();
  const loadSettings = useSettingsStore(s => s.load);
  const settingsLoaded = useSettingsStore(s => s.isLoaded);
  const [bootReady, setBootReady] = useState(false);

  useEffect(() => {
    (async () => {
      await loadSettings();
      setBootReady(true);
    })();
  }, []);

  if (!bootReady || !settingsLoaded) return null; // Could render a splash here

  return (
    <>
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.bg}
      />
      <RootNavigator />
    </>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <PaperProvider>
          <AuthProvider>
            <AppShell />
          </AuthProvider>
        </PaperProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
