// ═══════════════════════════════════════════════════════════
//  cron.js — Motor de Jobs Temporizados  (Kaius v34)
//
//  Permite que o bot faça ações proativas SEM precisar que
//  alguém mande mensagem. Exemplos:
//    - Enviar bom-dia todo dia às 08:00 em vários grupos
//    - Mencionar @todos em horários específicos
//    - Executar tarefas recorrentes (backups, avisos, etc.)
//
//  Uso em comandos:
//    import { addCronJob, removeCronJob } from '../../src/cron.js'
//    addCronJob({ id: 'meu-job', time: '08:00', days: [1,2,3,4,5],
//                 handle: async ({ sock }) => { ... } })
// ═══════════════════════════════════════════════════════════

import { logInfo, logOk, logError, logWarn } from './logger.js'
import JsonDB from './database.js'

const cronDB = new JsonDB('cronjobs')  // jobs persistidos

// ── Estado em memória ─────────────────────────────────────
const _jobs     = new Map()   // id → { config + handle fn }
let   _sock     = null
let   _interval = null
let   _lastTick = ''          // evitar disparar 2x no mesmo minuto
let   _ready    = false       // true somente após connection.open

// ── Dia da semana atual (0=Dom, 1=Seg... 6=Sab) ───────────
const todayDow = () => new Date().getDay()

// ── HH:MM do momento ─────────────────────────────────────
const nowHHMM = () => {
  const d = new Date()
  return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0')
}

// ── Checar se um job deve rodar agora ─────────────────────
function shouldRun(job, hhmm) {
  // Intervalo em minutos (ex: a cada 30min)
  if (job.intervalMinutes) {
    const now   = Date.now()
    const last  = job._lastRun || 0
    return (now - last) >= job.intervalMinutes * 60 * 1000
  }

  // Horário específico
  if (job.time && job.time !== hhmm) return false

  // Filtro de dias da semana ([0-6], 0=Dom)
  if (job.days && job.days.length > 0 && !job.days.includes(todayDow())) return false

  // Filtro de datas específicas (YYYY-MM-DD)
  if (job.date) {
    const today = new Date().toISOString().split('T')[0]
    return job.date === today
  }

  return true
}

// ── Loop principal (checa a cada 30 segundos) ─────────────
async function tick() {
  if (!_ready || !_sock) return   // não dispara antes de connection.open
  const hhmm = nowHHMM()

  // Evitar disparar 2x no mesmo minuto (tick roda 2x por minuto)
  if (hhmm === _lastTick) return
  _lastTick = hhmm

  for (const [id, job] of _jobs) {
    if (!job.enabled) continue
    if (!shouldRun(job, hhmm)) continue

    // Marcar como executado antes para evitar double-fire
    job._lastRun = Date.now()

    try {
      await job.handle({ sock: _sock, id, hhmm })
      logOk(`[Cron] "${id}" executado às ${hhmm}`)

      // Job de execução única — remover após rodar
      if (job.once) {
        _jobs.delete(id)
        cronDB.delete(id)
        logInfo(`[Cron] "${id}" removido (execução única)`)
      }
    } catch (e) {
      logError(`[Cron] Erro em "${id}": ${e.message}`)
    }
  }
}

// ── API Pública ───────────────────────────────────────────

/**
 * addCronJob — Registra um job temporizado
 *
 * @param {object} config
 *   id             string   — identificador único
 *   name           string   — nome legível (aparece no painel)
 *   time           string   — "HH:MM" (ex: "08:00")
 *   days           number[] — dias da semana [0-6], 0=Dom. [] = todos
 *   date           string   — "YYYY-MM-DD" para executar 1 vez numa data
 *   intervalMinutes number  — a cada N minutos (ignora time/days)
 *   once           boolean  — true = remove após executar
 *   enabled        boolean  — false = pausado
 *   targets        string[] — JIDs padrão (para uso no handle)
 *   handle         async fn — ({ sock, id, hhmm }) => void
 */
export function addCronJob(config) {
  if (!config.id) throw new Error('id obrigatório')
  if (!config.handle && typeof config.handle !== 'function') throw new Error('handle obrigatório')

  // Preservar _lastRun do job existente — evita disparo imediato após reconexão
  const existing = _jobs.get(config.id)

  const job = {
    id:              config.id,
    name:            config.name || config.id,
    time:            config.time || null,
    days:            config.days || [],
    date:            config.date || null,
    intervalMinutes: config.intervalMinutes || null,
    once:            config.once ?? false,
    enabled:         config.enabled ?? true,
    targets:         config.targets || [],
    createdAt:       config.createdAt || new Date().toISOString(),
    handle:          config.handle,
    _lastRun:        existing?._lastRun ?? 0,  // ← preserva de reconexão
  }

  _jobs.set(job.id, job)

  // Persistir no banco (sem a função handle — fns não são serializáveis)
  const { handle, _lastRun, ...storable } = job
  cronDB.set(job.id, storable)

  logInfo(`[Cron] Job registrado: "${job.id}" ${job.time ? 'às '+job.time : job.intervalMinutes ? 'a cada '+job.intervalMinutes+'min' : ''}`)
  return job
}

export function removeCronJob(id) {
  const ok = _jobs.delete(id)
  cronDB.delete(id)
  if (ok) logInfo(`[Cron] Job removido: "${id}"`)
  return ok
}

export function updateCronJob(id, changes) {
  const job = _jobs.get(id)
  if (!job) return false
  Object.assign(job, changes)
  const { handle, _lastRun, ...storable } = job
  cronDB.set(id, storable)
  return true
}

export function listCronJobs() {
  return [..._jobs.values()].map(({ handle, _lastRun, ...rest }) => ({
    ...rest,
    lastRunAt: _lastRun ? new Date(_lastRun).toLocaleTimeString('pt-BR') : null,
  }))
}

export function getCronJob(id) {
  return _jobs.get(id) || null
}

export function getCronDB() { return cronDB }

// ── Inicialização ─────────────────────────────────────────
export function initCron(sock) {
  _sock  = sock
  _ready = true   // habilita tick() — só deve ser chamado após connection.open

  // Carregar jobs que foram salvos no DB (sem handles — os handles
  // vêm dos comandos/reminders que se re-registram ao loadCommands)
  const saved = cronDB.all()
  let restored = 0
  for (const id in saved) {
    // Só restaura se ainda não está registrado (para não sobrescrever handles vivos)
    if (!_jobs.has(id)) {
      // Jobs sem handle precisam ser re-registrados pelos módulos que os criaram
      // (reminders.js faz isso no init)
    }
    restored++
  }

  // Iniciar loop (a cada 30s)
  if (_interval) clearInterval(_interval)
  _interval = setInterval(tick, 30000)

  logOk(`[Cron] Motor iniciado — ${_jobs.size} jobs ativos, ${restored} persistidos`)
}

export function setCronSock(sock) { _sock = sock }

// Forçar uma execução imediata de um job específico (para testes)
export async function runNow(id) {
  const job = _jobs.get(id)
  if (!job) throw new Error(`Job "${id}" não encontrado`)
  await job.handle({ sock: _sock, id, hhmm: nowHHMM(), forced: true })
}

export { cronDB }
