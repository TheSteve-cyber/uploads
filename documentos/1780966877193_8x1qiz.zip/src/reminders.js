// ═══════════════════════════════════════════════════════════
//  reminders.js — Sistema de Lembretes Proativos  (Kaius v34)
//
//  O bot manda mensagem e @menciona pessoas SEM elas precisarem
//  mandar nada primeiro. Funciona com:
//    - Horários fixos (08:00, 18:30...)
//    - Dias da semana (Seg-Sex, fim de semana, todo dia...)
//    - Intervalos (a cada X minutos/horas)
//    - @menção de usuários específicos ou @all (todos do grupo)
//    - Mensagens com variáveis: {hora}, {data}, {diaSemana}
// ═══════════════════════════════════════════════════════════

import { addCronJob, removeCronJob, listCronJobs, updateCronJob, runNow } from './cron.js'
import { logInfo, logError } from './logger.js'
import JsonDB from './database.js'

export const remindersDB = new JsonDB('reminders')

const DIAS_PT = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado']
const MESES_PT = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']

// ── Substituir variáveis no texto ──────────────────────────
function fillTemplate(text) {
  const now = new Date()
  const hhmm = now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0')
  const data  = `${now.getDate().toString().padStart(2,'0')}/${(now.getMonth()+1).toString().padStart(2,'0')}`
  const dia   = DIAS_PT[now.getDay()]
  const mes   = MESES_PT[now.getMonth()]
  const ano   = now.getFullYear()

  return text
    .replace(/\{hora\}/g,       hhmm)
    .replace(/\{data\}/g,       data)
    .replace(/\{diaSemana\}/g,  dia)
    .replace(/\{mes\}/g,        mes)
    .replace(/\{ano\}/g,        String(ano))
    .replace(/\{emoji_dia\}/g,  getDayEmoji(now.getDay()))
}

function getDayEmoji(dow) {
  return ['🌅','💼','💪','🌿','⚡','🎉','😴'][dow] || '📅'
}

// ── Buscar participantes do grupo ──────────────────────────
async function getMembersJids(sock, groupJid) {
  try {
    const meta = await sock.groupMetadata(groupJid)
    return meta.participants.map(p => p.id)
  } catch { return [] }
}

// ── Construir mensagem com menções ─────────────────────────
async function buildMsg(reminder, sock) {
  const text     = fillTemplate(reminder.text)
  const mentions = []

  if (!reminder.mentions?.length) {
    return { text, mentions: [] }
  }

  // @all — mencionar todos do grupo
  if (reminder.mentions.includes('@all') || reminder.mentions.includes('all')) {
    const jids = await getMembersJids(sock, reminder.jid)
    const nums = jids.map(j => j.split('@')[0].split(':')[0])
    const mentionStr = nums.map(n => `@${n}`).join(' ')
    return {
      text: mentionStr + '\n\n' + text,
      mentions: jids,
    }
  }

  // JIDs específicos
  for (const m of reminder.mentions) {
    const jid = m.includes('@') ? m : m.replace(/\D/g,'') + '@s.whatsapp.net'
    mentions.push(jid)
  }

  const mentionStr = mentions.map(j => `@${j.split('@')[0].split(':')[0]}`).join(' ')
  return {
    text: mentionStr + '\n\n' + text,
    mentions,
  }
}

// ── Registrar lembrete como cron job ──────────────────────
function registerReminderJob(reminder) {
  addCronJob({
    id:              `rem_${reminder.id}`,
    name:            reminder.label || 'Lembrete',
    time:            reminder.time || null,
    days:            reminder.days || [],
    date:            reminder.date || null,
    intervalMinutes: reminder.intervalMinutes || null,
    once:            !reminder.repeat && !reminder.days?.length,
    enabled:         reminder.enabled ?? true,
    targets:         [reminder.jid],
    createdAt:       reminder.createdAt,

    handle: async ({ sock }) => {
      try {
        const { text, mentions } = await buildMsg(reminder, sock)
        const msgOpts = { text }
        if (mentions.length) msgOpts.mentions = mentions

        await sock.sendMessage(reminder.jid, msgOpts)
        logInfo(`[Lembrete] "${reminder.label||reminder.id}" enviado para ${reminder.jid}`)

        // Remover se for único
        if (!reminder.repeat && !reminder.days?.length && !reminder.intervalMinutes) {
          remindersDB.delete(reminder.id)
          removeCronJob(`rem_${reminder.id}`)
        }
      } catch (e) {
        logError(`[Lembrete] Erro "${reminder.id}": ${e.message}`)

        // 403 = bot não está mais no grupo (foi removido, grupo excluído, etc.)
        // Desativa automaticamente para não ficar gerando erro a cada disparo
        if (e.data === 403 || String(e.message).toLowerCase().includes('forbidden')) {
          logWarn(`[Lembrete] "${reminder.label||reminder.id}" desativado — bot sem acesso ao destino ${reminder.jid}`)
          const current = remindersDB.get(reminder.id, reminder)
          remindersDB.set(reminder.id, { ...current, enabled: false })
          removeCronJob(`rem_${reminder.id}`)
        }
      }
    },
  })
}

// ── API Pública ───────────────────────────────────────────

/**
 * addReminder — Cria um lembrete
 *
 * @param {object} config
 *   label          string   — Nome do lembrete
 *   jid            string   — JID do grupo ou usuário destino
 *   text           string   — Texto (aceita {hora}, {data}, {diaSemana})
 *   mentions       string[] — JIDs para @mencionar, ou ['all'] para @todos
 *   time           string   — "HH:MM"
 *   days           number[] — [0-6], 0=Dom. Vazio = todo dia
 *   date           string   — "YYYY-MM-DD" (data única)
 *   intervalMinutes number  — a cada N minutos
 *   repeat         boolean  — true = repete todo dia (+ days)
 *   enabled        boolean
 */
export function addReminder(config) {
  const id = 'rem_' + Date.now()
  const reminder = {
    id,
    label:           config.label || 'Lembrete',
    jid:             config.jid,
    text:            config.text || '🔔 Lembrete!',
    mentions:        config.mentions || [],
    time:            config.time || null,
    days:            config.days || [],
    date:            config.date || null,
    intervalMinutes: config.intervalMinutes || null,
    repeat:          config.repeat ?? true,
    enabled:         config.enabled ?? true,
    createdAt:       new Date().toISOString(),
  }

  if (!reminder.jid) throw new Error('jid é obrigatório')
  if (!reminder.time && !reminder.intervalMinutes && !reminder.date) {
    throw new Error('defina time, intervalMinutes ou date')
  }

  remindersDB.set(id, reminder)
  registerReminderJob(reminder)

  logInfo(`[Lembrete] Criado: "${reminder.label}" → ${reminder.jid} às ${reminder.time||'intervalo '+reminder.intervalMinutes+'min'}`)
  return reminder
}

export function removeReminder(id) {
  remindersDB.delete(id)
  removeCronJob(`rem_${id}`)
  return true
}

export function toggleReminder(id, enabled) {
  const r = remindersDB.get(id, null)
  if (!r) return false
  r.enabled = enabled
  remindersDB.set(id, r)
  updateCronJob(`rem_${id}`, { enabled })
  return true
}

export function listReminders() {
  return Object.values(remindersDB.all())
    .sort((a, b) => (a.time||'').localeCompare(b.time||''))
}

export function getReminder(id) {
  return remindersDB.get(id, null)
}

// Forçar envio imediato de um lembrete (teste)
export async function testReminder(id) {
  return runNow(`rem_${id}`)
}

// ── Inicialização — recarregar lembretes do banco ─────────
export function initReminders() {
  const all = Object.values(remindersDB.all())
  let count = 0
  for (const reminder of all) {
    if (!reminder.enabled) continue
    registerReminderJob(reminder)
    count++
  }
  logInfo(`[Lembretes] ${count} lembretes carregados`)
}
