// ══════════════════════════════════════════════════════════
//  buttons.js — Botões Nativos WhatsApp v35
//
//  Baseado no Gojo System + ZMS System (DocBotoes.md).
//  ⚠️  IMAGEM É OBRIGATÓRIA — sem ela o WhatsApp mostra
//      "mensagem não suportada" em todos os 6 tipos.
//
//  DUAS ESTRATÉGIAS:
//  ┌─ carousel (sendCard) ──────────────────────────────────
//  │  Usa generateWAMessageFromContent + carouselMessage.
//  │  Confirmado funcionando. Requer imageUrl obrigatório.
//  │  É o que testarbotoes.js usa.
//  └─ direct (sendDirect) ──────────────────────────────────
//     Usa relayMessage + interactiveMessage direto.
//     Suporta image OU video no header.
//     Fonte: ZMS botoes.js.
//
//  USO NOS COMANDOS (via ctx):
//    await ctx.quickReply({ body, buttons, imageUrl })
//    await ctx.singleSelect({ body, sections, imageUrl })
//    await ctx.ctaUrl({ body, url, imageUrl })
//    const id = ctx.buttonId   // ID do botão que o usuário tocou
//    const id = ctx.listId     // ID da linha selecionada
//
//  USO STANDALONE / DIRETO:
//    import { quickReply, getButtonId } from '../../buttons.js'
//    await quickReply(sock, jid, null, { body, buttons, imageUrl })
// ══════════════════════════════════════════════════════════

import {
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  proto
} from '@whiskeysockets/baileys'

// ── Internos ──────────────────────────────────────────────

async function _prepareHeader(sock, imageUrl) {
  if (!imageUrl) {
    return proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false })
  }
  const media = await prepareWAMessageMedia(
    { image: { url: imageUrl } },
    { upload: sock.waUploadToServer }
  )
  return proto.Message.InteractiveMessage.Header.create({
    hasMediaAttachment: true,
    imageMessage: media.imageMessage
  })
}

// Estratégia carousel — usa generateWAMessageFromContent
async function _sendViaCarousel(sock, from, card, quotedMsg) {
  const gen = generateWAMessageFromContent(
    from,
    { interactiveMessage: { carouselMessage: { cards: [card] } } },
    { quoted: quotedMsg }
  )
  return sock.relayMessage(from, gen.message, { messageId: gen.key.id })
}

// ─────────────────────────────────────────────────────────
//  ESTRATÉGIA 2 — Direct (ZMS botoes.js)
//  Suporta image OU video no header.
//  Não usa carrossel — envia interactiveMessage diretamente.
// ─────────────────────────────────────────────────────────
export async function sendDirect(sock, from, msg, {
  body,
  footer   = '',
  buttons  = [],   // array já montado: [{ name, buttonParamsJson }, ...]
  imageUrl = null,
  videoUrl = null,
  mentions = [],
}) {
  const payload = {
    body:   { text: body },
    footer: { text: footer },
    contextInfo: {
      ...(mentions.length && { mentionedJid: mentions }),
    },
    nativeFlowMessage: { buttons, messageParamsJson: '' }
  }

  if (imageUrl) {
    const img = await prepareWAMessageMedia(
      { image: { url: imageUrl } },
      { upload: sock.waUploadToServer }
    )
    payload.header     = { hasMediaAttachment: true, imageMessage: img.imageMessage }
    payload.headerType = 'IMAGE'
  } else if (videoUrl) {
    const vid = await prepareWAMessageMedia(
      { video: { url: videoUrl } },
      { upload: sock.waUploadToServer }
    )
    payload.header     = { hasMediaAttachment: true, videoMessage: vid.videoMessage }
    payload.headerType = 'VIDEO'
  }

  return sock.relayMessage(from, { interactiveMessage: payload }, {})
}

// ─────────────────────────────────────────────────────────
//  1. single_select — Lista de seleção
//     ⚠️ imageUrl obrigatório
//     O usuário clica e uma lista aparece.
//     Capture a resposta com: getListId(msg)
// ─────────────────────────────────────────────────────────
export async function singleSelect(sock, from, msg, {
  body,
  footer    = '',
  btnText   = 'Ver opções',
  sections  = [],
  imageUrl,
}) {
  if (!imageUrl) throw new Error('[buttons] singleSelect: imageUrl obrigatório')
  const header = await _prepareHeader(sock, imageUrl)
  return _sendViaCarousel(sock, from, {
    header,
    body:   { text: body },
    footer: { text: footer },
    nativeFlowMessage: {
      buttons: [{
        name: 'single_select',
        buttonParamsJson: JSON.stringify({
          title: btnText,
          sections: sections.map(s => ({
            title: s.title || '',
            rows:  (s.rows || s.items || []).map((r, i) => ({
              header:      r.header      || '',
              title:       r.title       || r.text || '',
              description: r.description || r.desc || '',
              id:          r.id          || `row_${i}`,
            }))
          }))
        })
      }]
    }
  }, msg)
}

// ─────────────────────────────────────────────────────────
//  2. quick_reply — Botões de resposta rápida
//     ⚠️ imageUrl obrigatório
//     buttons: ['Texto', ...] ou [{ text, id }, ...]
//     Capture com: getButtonId(msg)
// ─────────────────────────────────────────────────────────
export async function quickReply(sock, from, msg, {
  body,
  footer   = '',
  buttons  = [],
  imageUrl,
}) {
  if (!imageUrl) throw new Error('[buttons] quickReply: imageUrl obrigatório')
  const header = await _prepareHeader(sock, imageUrl)
  return _sendViaCarousel(sock, from, {
    header,
    body:   { text: body },
    footer: { text: footer },
    nativeFlowMessage: {
      buttons: buttons.map(b => ({
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: typeof b === 'string' ? b : b.text,
          id:           typeof b === 'string' ? b : (b.id || b.text),
        })
      }))
    }
  }, msg)
}

// ─────────────────────────────────────────────────────────
//  3. cta_url — Abre link no navegador
//     ⚠️ imageUrl obrigatório
// ─────────────────────────────────────────────────────────
export async function ctaUrl(sock, from, msg, {
  body,
  footer   = '',
  btnText  = 'Abrir link',
  url,
  imageUrl,
}) {
  if (!imageUrl) throw new Error('[buttons] ctaUrl: imageUrl obrigatório')
  const header = await _prepareHeader(sock, imageUrl)
  return _sendViaCarousel(sock, from, {
    header,
    body:   { text: body },
    footer: { text: footer },
    nativeFlowMessage: {
      buttons: [{
        name: 'cta_url',
        buttonParamsJson: JSON.stringify({ display_text: btnText, url, merchant_url: url })
      }]
    }
  }, msg)
}

// ─────────────────────────────────────────────────────────
//  4. cta_copy — Copia texto para a área de transferência
//     ⚠️ imageUrl obrigatório
// ─────────────────────────────────────────────────────────
export async function ctaCopy(sock, from, msg, {
  body,
  footer   = '',
  btnText  = 'Copiar',
  copyText,
  imageUrl,
}) {
  if (!imageUrl) throw new Error('[buttons] ctaCopy: imageUrl obrigatório')
  const header = await _prepareHeader(sock, imageUrl)
  return _sendViaCarousel(sock, from, {
    header,
    body:   { text: body },
    footer: { text: footer },
    nativeFlowMessage: {
      buttons: [{
        name: 'cta_copy',
        buttonParamsJson: JSON.stringify({ display_text: btnText, copy_code: copyText })
      }]
    }
  }, msg)
}

// ─────────────────────────────────────────────────────────
//  5. cta_call — Inicia ligação
//     ⚠️ imageUrl obrigatório
// ─────────────────────────────────────────────────────────
export async function ctaCall(sock, from, msg, {
  body,
  footer   = '',
  btnText  = 'Ligar agora',
  phone,
  imageUrl,
}) {
  if (!imageUrl) throw new Error('[buttons] ctaCall: imageUrl obrigatório')
  const header = await _prepareHeader(sock, imageUrl)
  const phoneNum = String(phone).startsWith('+') ? phone : `+${phone}`
  return _sendViaCarousel(sock, from, {
    header,
    body:   { text: body },
    footer: { text: footer },
    nativeFlowMessage: {
      buttons: [{
        name: 'cta_call',
        buttonParamsJson: JSON.stringify({ display_text: btnText, phone_number: phoneNum })
      }]
    }
  }, msg)
}

// ─────────────────────────────────────────────────────────
//  6. cta_reminder — Botão de lembrete do WhatsApp
//     ⚠️ imageUrl obrigatório
// ─────────────────────────────────────────────────────────
export async function ctaReminder(sock, from, msg, {
  body,
  footer   = '',
  btnText  = 'Me lembrar depois',
  id       = 'lembrete',
  imageUrl,
}) {
  if (!imageUrl) throw new Error('[buttons] ctaReminder: imageUrl obrigatório')
  const header = await _prepareHeader(sock, imageUrl)
  return _sendViaCarousel(sock, from, {
    header,
    body:   { text: body },
    footer: { text: footer },
    nativeFlowMessage: {
      buttons: [{
        name: 'cta_reminder',
        buttonParamsJson: JSON.stringify({ display_text: btnText, id })
      }]
    }
  }, msg)
}

// ─────────────────────────────────────────────────────────
//  carousel — Múltiplos cards de uma vez (construção manual)
// ─────────────────────────────────────────────────────────
export async function carousel(sock, from, msg, cards) {
  const gen = generateWAMessageFromContent(
    from,
    { interactiveMessage: { carouselMessage: { cards } } },
    { quoted: msg }
  )
  return sock.relayMessage(from, gen.message, { messageId: gen.key.id })
}

// ─────────────────────────────────────────────────────────
//  CAPTURA DE RESPOSTA
//  Use no execute() do seu comando para saber o que o
//  usuário tocou / selecionou.
// ─────────────────────────────────────────────────────────

/**
 * Retorna o ID do botão tocado (quick_reply, cta_call, cta_copy, cta_reminder).
 * Verifica tanto buttonsResponseMessage (legado) quanto
 * interactiveResponseMessage (nativeFlow atual).
 */
export function getButtonId(msg) {
  // Resposta legada
  const legacy = msg?.message?.buttonsResponseMessage?.selectedButtonId
  if (legacy) return legacy
  // Resposta nativeFlow (formato atual)
  try {
    const params = msg?.message?.interactiveResponseMessage
      ?.nativeFlowResponseMessage?.paramsJson
    if (params) return JSON.parse(params).id ?? null
  } catch {}
  return null
}

/**
 * Retorna o ID da linha selecionada no single_select.
 * Verifica tanto listResponseMessage (legado) quanto
 * interactiveResponseMessage (nativeFlow atual).
 */
export function getListId(msg) {
  // Resposta legada
  const legacy = msg?.message?.listResponseMessage?.singleSelectReply?.selectedRowId
  if (legacy) return legacy
  // Resposta nativeFlow
  try {
    const params = msg?.message?.interactiveResponseMessage
      ?.nativeFlowResponseMessage?.paramsJson
    if (params) return JSON.parse(params).id ?? null
  } catch {}
  return null
}

// ─────────────────────────────────────────────────────────
//  makeButtonsCtx — injeta todos os helpers no ctx
//
//  Retorna objeto que é espalhado (...) no ctx do handler:
//    ctx.quickReply({ body, buttons, imageUrl })
//    ctx.singleSelect({ body, sections, imageUrl })
//    ctx.ctaUrl({ body, url, imageUrl })
//    ctx.ctaCopy({ body, copyText, imageUrl })
//    ctx.ctaCall({ body, phone, imageUrl })
//    ctx.ctaReminder({ body, id, imageUrl })
//    ctx.sendDirect({ body, buttons, imageUrl, videoUrl })
//    ctx.buttonId    — ID já resolvido do botão tocado
//    ctx.listId      — ID já resolvido da linha selecionada
// ─────────────────────────────────────────────────────────
export function makeButtonsCtx(sock, from, msg) {
  return {
    singleSelect: (opts)  => singleSelect(sock, from, msg, opts),
    quickReply:   (opts)  => quickReply  (sock, from, msg, opts),
    ctaUrl:       (opts)  => ctaUrl      (sock, from, msg, opts),
    ctaCopy:      (opts)  => ctaCopy     (sock, from, msg, opts),
    ctaCall:      (opts)  => ctaCall     (sock, from, msg, opts),
    ctaReminder:  (opts)  => ctaReminder (sock, from, msg, opts),
    sendDirect:   (opts)  => sendDirect  (sock, from, msg, opts),
    carousel:     (cards) => carousel    (sock, from, msg, cards),
    buttonId:     getButtonId(msg),  // ID do botão tocado (null se não for resposta de botão)
    listId:       getListId(msg),    // ID da linha selecionada (null se não for resposta de lista)
  }
}
