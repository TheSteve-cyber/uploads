// ═══════════════════════════════════════════════════════════
//  msgQueue.js — Rate Limiter para WhatsApp
//  Evita rate-overlimit espaçando os envios automaticamente.
//
//  Como usar:
//    import { wrapSock } from './msgQueue.js'
//    wrapSock(sock)   ← depois do makeWASocket()
//
//  Após isso, todo sock.sendMessage() é enfileirado automáticamente.
//  Código dos comandos não precisa mudar nada.
// ═══════════════════════════════════════════════════════════

import { logWarn } from './logger.js'

// ── Configurações ─────────────────────────────────────────
const DELAY_NORMAL = 700    // ms entre mensagens normais
const DELAY_REACT  = 300    // ms entre reactions (mais baratas)
const DELAY_DELETE = 200    // ms entre deletes (silenciosos)
const MAX_QUEUE    = 80     // descarta se fila encher demais
const MAX_RETRY    = 2      // tentativas por mensagem

// ── Estado interno ────────────────────────────────────────
const _queue = []
let _running  = false
let _lastSend = 0
let _dropped  = 0

// ── Limpar fila ao reconectar ──────────────────────────────
// Itens antigos na fila apontam para o sendMessage do sock morto —
// rejeitá-los imediatamente evita erros silenciosos e travamentos.
function resetQueue() {
  for (const item of _queue) {
    try { item.reject(new Error('connection-reset')) } catch {}
  }
  _queue.length = 0
  _running = false
  logWarn('[Queue] Fila resetada (nova conexão)')
}

// ── Detectar tipo de mensagem ──────────────────────────────
function getDelay(content) {
  if (content?.react !== undefined)   return DELAY_REACT
  if (content?.delete !== undefined)  return DELAY_DELETE
  return DELAY_NORMAL
}

// ── Processador da fila ───────────────────────────────────
async function processQueue() {
  if (_running) return
  _running = true

  while (_queue.length > 0) {
    const item = _queue.shift()
    const wait = item.delay - (Date.now() - _lastSend)
    if (wait > 0) await sleep(wait)

    let attempt = 0
    let sent = false

    while (attempt < MAX_RETRY && !sent) {
      attempt++
      try {
        const result = await item.fn()
        _lastSend = Date.now()
        item.resolve(result)
        sent = true
      } catch (e) {
        const msg = e?.message || ''

        // Rate limit — esperar antes de tentar de novo
        if (msg.includes('rate') || msg.includes('overlimit') || msg.includes('429')) {
          const backoff = 1500 * attempt
          logWarn(`[Queue] Rate limit — aguardando ${backoff}ms (tentativa ${attempt}/${MAX_RETRY})`)
          await sleep(backoff)
          continue
        }

        // Erro não recuperável — rejeita imediatamente
        item.reject(e)
        sent = true
      }
    }

    if (!sent) {
      item.reject(new Error('rate-limit-max-retry'))
    }
  }

  _running = false
}

// ── Wrapper principal ──────────────────────────────────────
export function wrapSock(sock) {
  resetQueue()  // Descartar itens do sock anterior (evita envios com conexão morta)
  const _original = sock.sendMessage.bind(sock)

  sock.sendMessage = (jid, content, opts = {}) => {
    // Fila cheia — descarta silenciosamente (não quebra o bot)
    if (_queue.length >= MAX_QUEUE) {
      _dropped++
      if (_dropped % 10 === 1) {
        logWarn(`[Queue] Fila cheia (${MAX_QUEUE}) — ${_dropped} msgs descartadas`)
      }
      return Promise.resolve(null)
    }

    return new Promise((resolve, reject) => {
      _queue.push({
        fn:      () => _original(jid, content, opts),
        delay:   getDelay(content),
        resolve,
        reject,
        jid,
      })
      processQueue()
    })
  }

  return sock
}

// ── Stats (para o dashboard) ──────────────────────────────
export function getQueueStats() {
  return {
    queueSize:  _queue.length,
    dropped:    _dropped,
    lastSend:   _lastSend,
  }
}

// ── Helper ────────────────────────────────────────────────
const sleep = (ms) => new Promise(r => setTimeout(r, ms))
