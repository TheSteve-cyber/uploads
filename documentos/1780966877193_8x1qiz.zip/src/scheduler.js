// ═══════════════════════════════════════════════════════════
//  scheduler.js v34 — Agendador reescrito sobre cron.js
//
//  Agora usa o motor de cron para maior robustez:
//    - Dias da semana (seg, ter... todo dia, fim de semana)
//    - Intervalos (a cada N minutos)
//    - @menções de usuários ou @todos do grupo
//    - Variáveis no texto: {hora}, {data}, {diaSemana}
//    - Execução única ou recorrente
// ═══════════════════════════════════════════════════════════

import { addCronJob, removeCronJob, listCronJobs, runNow } from './cron.js'
import { schedulerDB } from './database.js'
import { logInfo, logOk, logError } from './logger.js'

const DIAS_PT = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado']

// ── Template de texto ─────────────────────────────────────
function fillTemplate(text) {
  const now = new Date()
  const hhmm = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`
  const data  = `${now.getDate().toString().padStart(2,'0')}/${(now.getMonth()+1).toString().padStart(2,'0')}`
  return text
    .replace(/\{hora\}/g,      hhmm)
    .replace(/\{data\}/g,      data)
    .replace(/\{diaSemana\}/g, DIAS_PT[now.getDay()])
}

// ── Buscar JIDs do grupo para @all ────────────────────────
async function getMembersJids(sock, groupJid) {
  try {
    const meta = await sock.groupMetadata(groupJid)
    return meta.participants.map(p => p.id)
  } catch { return [] }
}

// ── Registrar tarefa como cron job ────────────────────────
function registerTask(task) {
  addCronJob({
    id:              `sched_${task.id}`,
    name:            `Agendado: ${task.text?.slice(0,30)||task.jid}`,
    time:            task.time      || null,
    days:            task.days      || [],
    intervalMinutes: task.intervalMinutes || null,
    once:            !task.repeat && !task.days?.length,
    enabled:         task.enabled ?? true,
    createdAt:       task.createdAt || new Date().toISOString(),

    handle: async ({ sock }) => {
      try {
        const text     = fillTemplate(task.text || '')
        const mentions = []
        let   finalTxt = text

        if (task.mentions?.length) {
          if (task.mentions.includes('@all') || task.mentions.includes('all')) {
            // Mencionar todos do grupo
            const jids = task.jid.endsWith('@g.us') ? await getMembersJids(sock, task.jid) : []
            mentions.push(...jids)
            if (jids.length) {
              const nums = jids.map(j => '@'+j.split('@')[0].split(':')[0]).join(' ')
              finalTxt = nums + '\n\n' + text
            }
          } else {
            // Mencionar usuários específicos
            for (const m of task.mentions) {
              const jid = m.includes('@') ? m : m.replace(/\D/g,'')+'@s.whatsapp.net'
              mentions.push(jid)
            }
            const nums = mentions.map(j => '@'+j.split('@')[0].split(':')[0]).join(' ')
            finalTxt = nums + '\n\n' + text
          }
        }

        const msgOpts = { text: finalTxt }
        if (mentions.length) msgOpts.mentions = mentions

        await sock.sendMessage(task.jid, msgOpts)
        logOk(`[Sched] "${task.id}" → ${task.jid}`)

        // Tarefa única — remover após executar
        if (!task.repeat && !task.days?.length) {
          schedulerDB.delete(task.id)
          removeCronJob(`sched_${task.id}`)
        }
      } catch (e) {
        logError(`[Sched] Erro "${task.id}": ${e.message}`)
      }
    },
  })
}

// ── initScheduler — compatibilidade com código existente ──
export function initScheduler(sock) {
  // Carregar tarefas salvas no DB
  const tasks = schedulerDB.all()
  let count = 0
  for (const id in tasks) {
    if (id.startsWith('lastRun_')) continue  // Ignorar chaves legadas
    const task = tasks[id]
    if (!task.jid || !task.text) continue
    registerTask({ ...task, id })
    count++
  }
  logOk(`[Sched] ${count} tarefas agendadas`)
}

// ── API pública ───────────────────────────────────────────

/**
 * addTask — Cria uma tarefa agendada
 * @param {object} task
 *   jid             string   — JID do destino
 *   text            string   — Texto (aceita {hora}, {data}, {diaSemana})
 *   time            string   — "HH:MM"
 *   days            number[] — dias da semana [0-6]
 *   intervalMinutes number   — a cada N minutos
 *   mentions        string[] — JIDs ou ['all'] para @todos
 *   repeat          boolean  — repete ou executa uma vez
 */
export function addTask(task) {
  const id = `task_${Date.now()}`
  const record = { ...task, id, createdAt: new Date().toISOString(), enabled: true }
  schedulerDB.set(id, record)
  registerTask(record)
  return record
}

export function removeTask(id) {
  schedulerDB.delete(id)
  removeCronJob(`sched_${id}`)
  return true
}

export function toggleTask(id, enabled) {
  const task = schedulerDB.get(id, null)
  if (!task) return false
  task.enabled = enabled
  schedulerDB.set(id, task)
  // Atualizar o cron job correspondente
  const job = listCronJobs().find(j => j.id === `sched_${id}`)
  if (job) job.enabled = enabled
  return true
}

export function listTasks() {
  return Object.entries(schedulerDB.all())
    .filter(([k]) => !k.startsWith('lastRun_'))
    .map(([id, t]) => ({ ...t, id }))
    .sort((a, b) => (a.time||'').localeCompare(b.time||''))
}

// Executar agora (para teste)
export async function runTaskNow(id) {
  return runNow(`sched_${id}`)
}
