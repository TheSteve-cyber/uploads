// ══════════════════════════════════════════════════════════
//  standalone.js — Motor de Eventos Independentes v35
//
//  Executa qualquer coisa sem depender de mensagem do usuário.
//  Suporta: cron (hora/intervalo/data), eventos do bot (pub/sub),
//  botões, listas, templates, broadcast, etc.
//
//  Uso nos seus comandos:
//    export const events = [{ id, execute, time?, on?, ... }]
// ══════════════════════════════════════════════════════════

import { addCronJob, removeCronJob } from './cron.js'
import { onEvent, EVENTS }           from './hooks.js'
import { logInfo, logOk, logWarn, logError } from './logger.js'
import { CONFIG }                    from './config.js'
import {
  singleSelect, quickReply, ctaUrl, ctaCopy, ctaCall, ctaReminder,
  sendDirect, carousel, getButtonId, getListId
} from './buttons.js'

// ── Estado ────────────────────────────────────────────────
let _sock = null
const _registered = new Map()   // id → config

export function setStandaloneSock(sock) { _sock = sock }
export function getStandaloneSock()     { return _sock  }

// ─────────────────────────────────────────────────────────
//  makeCtx — Contexto rico entregue ao execute()
//  Expõe TUDO: sock bruto, helpers de envio, construtores
//  de mensagens ricas, consulta de grupo, tempo, config, ...
// ─────────────────────────────────────────────────────────
function makeCtx(sock, extra = {}) {
  const now = new Date()

  return {
    // ── Socket bruto — acesso total ao Baileys ────────────
    sock,

    // ── Envio simples ─────────────────────────────────────
    sendTo: (jid, content) =>
      sock.sendMessage(jid, content),

    sendText: (jid, text, mentions = []) =>
      sock.sendMessage(jid, { text, ...(mentions.length ? { mentions } : {}) }),

    sendImage: (jid, url, caption = '', mentions = []) =>
      sock.sendMessage(jid, { image: { url }, caption, ...(mentions.length ? { mentions } : {}) }),

    sendAudio: (jid, url, ptt = false) =>
      sock.sendMessage(jid, { audio: { url }, mimetype: 'audio/mpeg', ptt }),

    sendVideo: (jid, url, caption = '') =>
      sock.sendMessage(jid, { video: { url }, caption }),

    sendSticker: (jid, url) =>
      sock.sendMessage(jid, { sticker: { url } }),

    sendReaction: (key, emoji) =>
      sock.sendMessage(key.remoteJid, { react: { text: emoji, key } }),

    // ── Broadcast com delay para não levar ban ────────────
    broadcast: async (jids, content, delayMs = 800) => {
      const results = []
      for (const jid of jids) {
        try {
          const r = await sock.sendMessage(jid, content)
          results.push({ jid, ok: true, result: r })
        } catch (e) {
          results.push({ jid, ok: false, error: e.message })
        }
        if (delayMs > 0) await new Promise(r => setTimeout(r, delayMs))
      }
      return results
    },

    // ── Botões nativos WhatsApp (todos os 6 tipos) ─────────
    // ⚠️  imageUrl é OBRIGATÓRIO — sem foto = "não suportado" no WhatsApp
    // Nos eventos cron: passe o jid como 1º argumento.
    // Nos eventos pub/sub: use `from` ou `groupJid` do payload.
    //   execute: async ({ singleSelect, groupJid }) =>
    //     singleSelect(groupJid, { body, sections, imageUrl })
    singleSelect: (jid, opts) => singleSelect(sock, jid, null, opts),
    quickReply:   (jid, opts) => quickReply  (sock, jid, null, opts),
    ctaUrl:       (jid, opts) => ctaUrl      (sock, jid, null, opts),
    ctaCopy:      (jid, opts) => ctaCopy     (sock, jid, null, opts),
    ctaCall:      (jid, opts) => ctaCall     (sock, jid, null, opts),
    ctaReminder:  (jid, opts) => ctaReminder (sock, jid, null, opts),
    // sendDirect: sem carousel, aceita image OU video no header
    sendDirect:   (jid, opts) => sendDirect  (sock, jid, null, opts),
    carousel:     (jid, cards) => carousel   (sock, jid, null, cards),
    // Captura de resposta (quando evento é disparado por toque em botão)
    getButtonId:  (m) => getButtonId(m),
    getListId:    (m) => getListId(m),

    // ── Consultas de grupo ────────────────────────────────
    getGroupMembers: async (gid) => {
      const m = await sock.groupMetadata(gid)
      return m.participants
    },
    getGroupAdmins: async (gid) => {
      const m = await sock.groupMetadata(gid)
      return m.participants.filter(p => p.admin)
    },
    getGroupInfo: async (gid) => sock.groupMetadata(gid),

    // ── Ações de grupo ────────────────────────────────────
    kickFromGroup:   (gid, jids) => sock.groupParticipantsUpdate(gid, Array.isArray(jids) ? jids : [jids], 'remove'),
    promoteInGroup:  (gid, jids) => sock.groupParticipantsUpdate(gid, Array.isArray(jids) ? jids : [jids], 'promote'),
    demoteInGroup:   (gid, jids) => sock.groupParticipantsUpdate(gid, Array.isArray(jids) ? jids : [jids], 'demote'),
    closeGroup:      (gid)       => sock.groupSettingUpdate(gid, 'announcement'),
    openGroup:       (gid)       => sock.groupSettingUpdate(gid, 'not_announcement'),
    leaveGroup:      (gid)       => sock.groupLeave(gid),

    // ── Presença ─────────────────────────────────────────
    sendTyping: (jid, durationMs = 2000) => {
      sock.sendPresenceUpdate('composing', jid)
      return new Promise(r => setTimeout(() => { sock.sendPresenceUpdate('paused', jid); r() }, durationMs))
    },
    sendRecording: (jid, durationMs = 2000) => {
      sock.sendPresenceUpdate('recording', jid)
      return new Promise(r => setTimeout(() => { sock.sendPresenceUpdate('paused', jid); r() }, durationMs))
    },

    // ── Tempo ─────────────────────────────────────────────
    now,
    hhmm:      now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    data:      now.toLocaleDateString('pt-BR'),
    timestamp: now.getTime(),
    sleep:     (ms) => new Promise(r => setTimeout(r, ms)),

    // ── Config ────────────────────────────────────────────
    CONFIG,
    EVENTS,

    // Propagado do payload do evento/cron
    ...extra
  }
}

// ─────────────────────────────────────────────────────────
//  registerStandalone — Registro público
//
//  config: {
//    id:              string          (obrigatório, único)
//    name:            string          (exibição)
//    enabled:         boolean         (default: true)
//    execute:         async fn(ctx)   (obrigatório)
//
//    -- Modo cron (escolha um ou combine) --
//    time:            'HH:MM'         ex: '08:00'
//    days:            number[]        0=Dom...6=Sáb, [] = todo dia
//    date:            'YYYY-MM-DD'    data específica
//    intervalMinutes: number          a cada N minutos
//    once:            boolean         executa uma vez e remove
//
//    -- Modo evento (pub/sub) --
//    on: string | string[]   ex: EVENTS.GROUP_JOIN | ['group.join','bot.connect']
//  }
// ─────────────────────────────────────────────────────────
export function registerStandalone(config) {
  if (!config.id)                        throw new Error('[Standalone] id obrigatório')
  if (typeof config.execute !== 'function') throw new Error('[Standalone] execute() obrigatório')

  // Preservar _lastRun do cron para evitar disparo duplo em reload
  const existing = _registered.get(config.id)
  _registered.set(config.id, { ...existing, ...config })

  // ── Modo cron ──────────────────────────────────────────
  const isCron = config.time || config.intervalMinutes || config.date
  if (isCron) {
    addCronJob({
      id:              `stand_${config.id}`,
      name:            config.name || config.id,
      time:            config.time            ?? null,
      days:            config.days            ?? [],
      date:            config.date            ?? null,
      intervalMinutes: config.intervalMinutes ?? null,
      once:            config.once            ?? false,
      enabled:         config.enabled         ?? true,
      handle: async (cronCtx) => {
        if (!(config.enabled ?? true)) return
        const sock = cronCtx.sock || _sock
        if (!sock) { logWarn(`[Standalone] "${config.id}": sem sock`); return }
        try {
          await config.execute(makeCtx(sock, { ...cronCtx, jobId: config.id }))
        } catch (e) {
          logError(`[Standalone] "${config.id}": ${e.message}`)
        }
      }
    })
  }

  // ── Modo evento pub/sub ────────────────────────────────
  if (config.on) {
    const evList = Array.isArray(config.on) ? config.on : [config.on]
    for (const ev of evList) {
      onEvent(ev, `stand_${config.id}__${ev}`, async (payload) => {
        if (!(config.enabled ?? true)) return
        const sock = payload.sock || _sock
        if (!sock) return
        try {
          await config.execute(makeCtx(sock, payload))
        } catch (e) {
          logError(`[Standalone] "${config.id}" on "${ev}": ${e.message}`)
        }
      })
    }
  }

  const badge = [
    isCron             ? `⏱ ${config.time || config.intervalMinutes+'min'}` : '',
    config.on          ? `📡 ${[].concat(config.on).join(',')}` : '',
  ].filter(Boolean).join(' ')
  logInfo(`[Standalone] ✔ ${config.id} ${badge}`)

  return config
}

export function removeStandalone(id) {
  _registered.delete(id)
  removeCronJob(`stand_${id}`)
}

export function enableStandalone(id)  { const c = _registered.get(id); if (c) c.enabled = true  }
export function disableStandalone(id) { const c = _registered.get(id); if (c) c.enabled = false }
export function listStandalone()      { return [..._registered.values()] }

// Re-exporta EVENTS para módulos não precisarem importar separado
export { EVENTS }
