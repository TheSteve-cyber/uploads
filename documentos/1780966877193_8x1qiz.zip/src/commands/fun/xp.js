// ══════════════════════════════════════════════════════════
//  xp.js — Sistema de XP e Níveis Real (persistente)
// ══════════════════════════════════════════════════════════
import JsonDB from '../../database.js'
import { resolveName } from '../../utils.js'
const xpDB = new JsonDB('xp')

const XP_POR_MSG = 3
const XP_BASE    = 100  // XP para o nível 2

function getNivel(xp) { return Math.floor(Math.sqrt(xp / XP_BASE)) + 1 }
function xpParaProximo(nivel) { return XP_BASE * (nivel) ** 2 }

export function addXP(userId, nome, qtd = XP_POR_MSG) {
  const u = xpDB.get(userId, { xp: 0, nivel: 1, nome, msgs: 0 })
  const xpAntes  = u.xp
  u.xp   += qtd
  u.msgs += 1
  u.nome  = nome
  const nivelNovo = getNivel(u.xp)
  const levelUp   = nivelNovo > u.nivel
  u.nivel = nivelNovo
  xpDB.set(userId, u)
  return { levelUp, nivel: u.nivel, xp: u.xp }
}

export const xpCmd = {
  name: 'xp',
  aliases: ['nivel', 'level', 'exp', 'perfil'],
  description: 'Mostra seu nível e XP real',
  category: 'fun',
  usage: '.xp [@alguém]',
  cooldown: 10,
  async execute({ reply, msg, userId, usuario, membros }) {
    const mentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
    const alvoId   = mentions[0] || userId
    const alvoNome = alvoId === userId ? usuario : resolveName(alvoId, membros, 'Usuário')

    const u = xpDB.get(alvoId, { xp: 0, nivel: 1, nome: alvoNome, msgs: 0 })
    const prox  = xpParaProximo(u.nivel + 1)
    const prog  = u.xp - xpParaProximo(u.nivel)
    const range = prox - xpParaProximo(u.nivel)
    const pct   = Math.min(Math.floor((prog / range) * 10), 10)
    const barra = '█'.repeat(pct) + '░'.repeat(10 - pct)

    await reply(
      `⚡ *${u.nome || alvoNome}*\n\n` +
      `🏆 Nível: *${u.nivel}*\n` +
      `✨ XP: *${u.xp}* / ${prox}\n` +
      `💬 Mensagens: *${u.msgs}*\n\n` +
      `[${barra}] ${Math.floor((prog/range)*100)}%`
    )
  }
}

export const ranking = {
  name: 'ranking',
  aliases: ['top', 'topxp', 'rank'],
  description: 'Ranking de XP do grupo',
  category: 'fun',
  usage: '.ranking',
  cooldown: 15,
  async execute({ reply }) {
    const top = Object.values(xpDB.all())
      .sort((a, b) => b.xp - a.xp).slice(0, 10)
    if (!top.length) return reply('Nenhum XP registrado ainda!')
    const emojis = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟']
    const lista  = top.map((u, i) =>
      `${emojis[i]} *${u.nome||'?'}* — Nv.${u.nivel} (${u.xp} XP)`
    ).join('\n')
    await reply(`🏆 *RANKING DE XP*\n\n${lista}`)
  }
}

export default [xpCmd, ranking]
