// ══════════════════════════════════════════════════════════
//  antispam.js — Anti-flood: limita msgs por intervalo
//
//  Uso:
//    .antispam on [msgs] [segundos]  → ex: .antispam on 5 10
//    .antispam off
//    .antispam status
// ══════════════════════════════════════════════════════════

import JsonDB from '../../database.js'
const asDB = new JsonDB('antispam_grupos')

// Contador em memória: { [userId]: { count, first, warned } }
const _counters = new Map()

function HOOK_ID(gid) { return `antispam-${gid}` }

function criarHook(groupJid, maxMsgs, windowSecs) {
  return {
    id:         HOOK_ID(groupJid),
    name:       `Anti-spam [${maxMsgs}msgs/${windowSecs}s]`,
    priority:   5,           // roda ANTES de tudo
    onlyGroups: true,
    groups:     [groupJid],
    handle: async ({ sock, msg, from, userId, isAdmin, isOwner, react }) => {
      if (isAdmin || isOwner) return  // imunidade para admins

      const key    = `${from}:${userId}`
      const now    = Date.now()
      const window = windowSecs * 1000

      let c = _counters.get(key) || { count: 0, first: now, warned: false }

      // Reset se janela expirou
      if (now - c.first > window) {
        c = { count: 0, first: now, warned: false }
      }

      c.count++
      _counters.set(key, c)

      if (c.count >= maxMsgs) {
        if (!c.warned) {
          c.warned = true
          await react('⚠️')
          await sock.sendMessage(from, {
            text: `⚠️ @${userId.split('@')[0]} devagar! Máximo ${maxMsgs} msgs a cada ${windowSecs}s.`,
            mentions: [userId]
          }).catch(() => {})
        }
        // Deleta a mensagem de spam
        await sock.sendMessage(from, { delete: msg.key }).catch(() => {})
        return true   // para a propagação
      }
    }
  }
}

// Boot
const saved = asDB.all()
export const hooks = Object.entries(saved)
  .filter(([, v]) => v.ativo)
  .map(([jid, v]) => criarHook(jid, v.maxMsgs || 5, v.windowSecs || 10))

export default {
  name: 'antispam',
  aliases: ['antiflood', 'flood'],
  description: 'Anti-flood por grupo',
  category: 'owner',
  usage: '.antispam on [msgs] [seg] | off | status',
  cooldown: 3,

  async execute({ from, isGrupo, nomeGrupo, args, reply, isAdmin, isOwner }) {
    if (!isGrupo) return reply('❌ Use em um grupo!')
    if (!isAdmin && !isOwner) return reply('❌ Apenas admins.')

    const sub = args[0]?.toLowerCase()

    if (sub === 'on') {
      const maxMsgs    = parseInt(args[1]) || 5
      const windowSecs = parseInt(args[2]) || 10
      asDB.set(from, { ativo: true, maxMsgs, windowSecs })
      const { registerHook } = await import('../../hooks.js')
      registerHook(criarHook(from, maxMsgs, windowSecs))
      return reply(`✅ Anti-spam ativo em _${nomeGrupo}_\n⚙️ Limite: ${maxMsgs} msgs a cada ${windowSecs}s`)
    }

    if (sub === 'off') {
      const cfg = asDB.get(from, {})
      cfg.ativo = false
      asDB.set(from, cfg)
      const { removeHook } = await import('../../hooks.js')
      removeHook(HOOK_ID(from))
      return reply(`🔕 Anti-spam desativado em _${nomeGrupo}_`)
    }

    const cfg = asDB.get(from, { ativo: false })
    return reply(
      `🛡️ *Anti-Spam* — ${cfg.ativo ? '🟢 ativo' : '🔴 inativo'}\n` +
      `⚙️ Limite: ${cfg.maxMsgs || 5} msgs / ${cfg.windowSecs || 10}s\n\n` +
      `.antispam on [msgs] [segundos]\n.antispam off`
    )
  }
}
