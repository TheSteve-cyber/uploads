// ══════════════════════════════════════════════════════════
//  antipalavrao.js — Hook de moderação de palavrões
//
//  Uso no WhatsApp:
//    .antipalavrao on     → ativa no grupo atual
//    .antipalavrao off    → desativa no grupo atual
//    .antipalavrao add palavrao → adiciona palavra
//    .antipalavrao lista  → mostra lista atual
// ══════════════════════════════════════════════════════════

import JsonDB from '../../database.js'
const apDB = new JsonDB('antipalavrao')

const HOOK_ID = (groupJid) => `antipalavrao-${groupJid}`

// Hook factory — cria um hook para um grupo específico
function criarHook(groupJid, palavras) {
  return {
    id:         HOOK_ID(groupJid),
    name:       `Anti-palavrão [${groupJid.split('@')[0].slice(-6)}]`,
    priority:   15,
    onlyGroups: true,
    groups:     [groupJid],
    handle: async ({ sock, msg, from, userId, texto, isAdmin, react }) => {
      if (isAdmin) return
      const lower = texto.toLowerCase()
      const achou = palavras.find(p => lower.includes(p.toLowerCase()))
      if (!achou) return

      await sock.sendMessage(from, { delete: msg.key }).catch(() => {})
      await react('🤐')
      await sock.sendMessage(from, {
        text: `⚠️ @${userId.split('@')[0]} tome cuidado com a linguagem!`,
        mentions: [userId]
      })
      return true
    }
  }
}

// Carrega hooks salvos no boot
const state = apDB.all()
export const hooks = Object.entries(state)
  .filter(([, v]) => v.ativo && v.palavras?.length)
  .map(([jid, v]) => criarHook(jid, v.palavras))

export default {
  name: 'antipalavrao',
  aliases: ['apwords', 'palavrao'],
  description: 'Moderação de palavrões por grupo',
  category: 'owner',
  usage: '.antipalavrao on | off | add <palavra> | lista',
  cooldown: 3,

  async execute({ sock, from, isGrupo, nomeGrupo, args, argStr, reply, isAdmin, isOwner }) {
    if (!isGrupo) return reply('❌ Use em um grupo!')
    if (!isAdmin && !isOwner) return reply('❌ Apenas admins.')

    const sub = args[0]?.toLowerCase()
    const cfg = apDB.get(from, { ativo: false, palavras: [] })

    if (sub === 'on') {
      cfg.ativo = true
      apDB.set(from, cfg)
      // Registra/atualiza o hook dinamicamente
      const { registerHook } = await import('../../hooks.js')
      registerHook(criarHook(from, cfg.palavras))
      return reply(`✅ Anti-palavrão *ativado* em _${nomeGrupo}_`)
    }

    if (sub === 'off') {
      cfg.ativo = false
      apDB.set(from, cfg)
      const { removeHook } = await import('../../hooks.js')
      removeHook(HOOK_ID(from))
      return reply(`🔕 Anti-palavrão *desativado* em _${nomeGrupo}_`)
    }

    if (sub === 'add') {
      const palavra = args.slice(1).join(' ').trim().toLowerCase()
      if (!palavra) return reply('❌ Informe a palavra: .antipalavrao add xingamento')
      if (!cfg.palavras.includes(palavra)) cfg.palavras.push(palavra)
      apDB.set(from, cfg)
      if (cfg.ativo) {
        const { registerHook } = await import('../../hooks.js')
        registerHook(criarHook(from, cfg.palavras))
      }
      return reply(`✅ Palavra adicionada: *${palavra}*\nTotal: ${cfg.palavras.length}`)
    }

    if (sub === 'lista' || sub === 'list') {
      if (!cfg.palavras.length) return reply('📋 Nenhuma palavra cadastrada.')
      return reply(`📋 *Palavras bloqueadas:*\n${cfg.palavras.map((p, i) => `${i+1}. ${p}`).join('\n')}`)
    }

    const status = cfg.ativo ? '🟢 *ativo*' : '🔴 *desativado*'
    return reply(
      `🤐 *Anti-Palavrão* — ${status}\n` +
      `📋 Palavras: ${cfg.palavras.length}\n\n` +
      `Subcomandos:\n` +
      `• *.antipalavrao on/off*\n` +
      `• *.antipalavrao add <palavra>*\n` +
      `• *.antipalavrao lista*`
    )
  }
}
