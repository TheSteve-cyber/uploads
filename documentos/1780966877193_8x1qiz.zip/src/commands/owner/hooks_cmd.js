// ══════════════════════════════════════════════════════════
//  hooks_cmd.js — Gerenciamento de hooks via WhatsApp
//
//  .hooks          → lista todos os hooks ativos
//  .hook off <id>  → desativa um hook pelo ID
// ══════════════════════════════════════════════════════════

export default [
  {
    name: 'hooks',
    aliases: ['listhooks'],
    description: 'Lista todos os hooks ativos',
    category: 'owner',
    usage: '.hooks',
    cooldown: 5,
    async execute({ reply, isOwner, isAdmin }) {
      if (!isOwner && !isAdmin) return reply('❌ Apenas dono/admin.')
      const { listHooks } = await import('../../hooks.js')
      const list = listHooks()
      if (!list.length) return reply('📋 Nenhum hook ativo no momento.')
      const texto = list.map((h, i) =>
        `${i+1}. *${h.name}*\n   ID: \`${h.id}\`\n   Prio: ${h.priority} | Grupos: ${h.groups?.length ? h.groups.length : 'todos'}`
      ).join('\n\n')
      return reply(`🔌 *Hooks Ativos (${list.length}):*\n\n${texto}`)
    }
  },
  {
    name: 'hookoff',
    aliases: ['removehook', 'rmhook'],
    description: 'Desativa um hook pelo ID',
    category: 'owner',
    usage: '.hookoff <id>',
    cooldown: 3,
    async execute({ args, reply, isOwner }) {
      if (!isOwner) return reply('❌ Apenas o dono.')
      const id = args.join(' ').trim()
      if (!id) return reply('❌ Informe o ID: .hookoff meu-hook-id')
      const { removeHook } = await import('../../hooks.js')
      const ok = removeHook(id)
      return reply(ok ? `✅ Hook *${id}* removido!` : `❌ Hook *${id}* não encontrado.\nUse *.hooks* para ver os IDs.`)
    }
  }
]
