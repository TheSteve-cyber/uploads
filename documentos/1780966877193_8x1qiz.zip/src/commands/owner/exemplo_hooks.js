// ══════════════════════════════════════════════════════════
//  exemplo_hooks.js — Exemplos comentados de hooks e eventos
//  Copie, adapte e use. Não modifique este arquivo direto.
// ══════════════════════════════════════════════════════════

// ─── EXEMPLO 1: Hook simples ───────────────────────────────
// Intercepta mensagens com "oi bot" e responde
const hookOiBot = {
  id:       'oibot',
  name:     'Resposta ao oi bot',
  priority: 20,
  match:    /\boi bot\b/i,   // filtra antes de chamar handle
  handle: async ({ reply, usuario }) => {
    await reply(`Olá, *${usuario}*! 👋 Como posso ajudar?`)
    return true   // impede que o comando !oi seja processado
  }
}

// ─── EXEMPLO 2: Hook de log ────────────────────────────────
// Registra toda mensagem em grupos específicos
/*
const hookLog = {
  id:         'log-auditoria',
  name:       'Log de auditoria',
  priority:   1,
  onlyGroups: true,
  handle: async ({ sock, from, userId, texto, usuario }) => {
    console.log(`[LOG] ${new Date().toISOString()} | ${usuario} | ${from} | ${texto}`)
    // retornar true bloquearia o comando
  }
}
*/

export const hooks = [hookOiBot]

// ─── EXEMPLO 3: Evento standalone ─────────────────────────
// Executa sem precisar de mensagem — puro, proativo
/*
import { EVENTS } from '../../standalone.js'

export const events = [
  {
    id:      'ping-diario',
    name:    '🔔 Ping diário',
    time:    '09:00',
    days:    [1, 2, 3, 4, 5],
    execute: async ({ sendTo }) => {
      await sendTo('SEUJID@s.whatsapp.net', { text: '☀️ Bot online e funcionando!' })
    }
  },
  {
    id:      'boas-vindas-custom',
    on:      EVENTS.GROUP_JOIN,
    execute: async ({ sock, sendTo, jid, groupJid }) => {
      await sendTo(groupJid, {
        text: `Bem-vindo(a)! 🎉 Digite !ajuda para ver os comandos.`,
        mentions: [jid]
      })
    }
  }
]
*/

export default []
