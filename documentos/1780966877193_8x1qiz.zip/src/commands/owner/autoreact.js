// ══════════════════════════════════════════════════════════
//  autoreact.js — Auto-reação por palavra-chave
//
//  Uso:
//    .autoreact on ❤️ bom dia  → reage com ❤️ quando alguém escreve "bom dia"
//    .autoreact off bom dia    → remove
//    .autoreact lista          → lista regras ativas
// ══════════════════════════════════════════════════════════

import JsonDB from '../../database.js'
const arDB = new JsonDB('autoreact')

function hookId(groupJid, keyword) {
  return `autoreact-${groupJid}-${keyword.replace(/\s+/g,'_')}`
}

function criarHook(groupJid, keyword, emoji) {
  return {
    id:         hookId(groupJid, keyword),
    name:       `AutoReact "${keyword}" ${emoji}`,
    priority:   20,
    onlyGroups: true,
    groups:     [groupJid],
    handle: async ({ sock, msg, texto }) => {
      if (!texto.toLowerCase().includes(keyword.toLowerCase())) return
      await sock.sendMessage(msg.key.remoteJid, {
        react: { text: emoji, key: msg.key }
      }).catch(() => {})
      // não retorna true — deixa o comando processar normalmente
    }
  }
}

// Boot — carrega hooks salvos
const all = arDB.all()
export const hooks = []
for (const [jid, rules] of Object.entries(all)) {
  for (const [keyword, emoji] of Object.entries(rules)) {
    hooks.push(criarHook(jid, keyword, emoji))
  }
}

export default {
  name: 'autoreact',
  aliases: ['reacao', 'react'],
  description: 'Auto-reação por palavra-chave',
  category: 'owner',
  usage: '.autoreact on <emoji> <palavra> | off <palavra> | lista',
  cooldown: 3,

  async execute({ from, isGrupo, nomeGrupo, args, reply, isAdmin, isOwner }) {
    if (!isGrupo) return reply('❌ Use em um grupo!')
    if (!isAdmin && !isOwner) return reply('❌ Apenas admins.')

    const sub = args[0]?.toLowerCase()

    if (sub === 'on') {
      const emoji   = args[1] || '👍'
      const keyword = args.slice(2).join(' ').trim().toLowerCase()
      if (!keyword) return reply('❌ Informe: .autoreact on <emoji> <palavra>')
      const rules = arDB.get(from, {})
      rules[keyword] = emoji
      arDB.set(from, rules)
      const { registerHook } = await import('../../hooks.js')
      registerHook(criarHook(from, keyword, emoji))
      return reply(`✅ Vou reagir com ${emoji} quando alguém escrever "*${keyword}*"`)
    }

    if (sub === 'off') {
      const keyword = args.slice(1).join(' ').trim().toLowerCase()
      if (!keyword) return reply('❌ Informe a palavra: .autoreact off bom dia')
      const rules = arDB.get(from, {})
      delete rules[keyword]
      arDB.set(from, rules)
      const { removeHook } = await import('../../hooks.js')
      removeHook(hookId(from, keyword))
      return reply(`🗑️ Reação para "*${keyword}*" removida.`)
    }

    if (sub === 'lista' || sub === 'list') {
      const rules = arDB.get(from, {})
      const entries = Object.entries(rules)
      if (!entries.length) return reply('📋 Nenhuma reação configurada.')
      return reply(`📋 *Auto-reações em ${nomeGrupo}:*\n` + entries.map(([k,e]) => `${e} → ${k}`).join('\n'))
    }

    return reply('❓ Uso: .autoreact on <emoji> <palavra> | off <palavra> | lista')
  }
}
