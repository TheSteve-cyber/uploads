// ═══════════════════════════════════════════════════════════
//  menuBuilder.js — Construtor de Menus  (Kaius v34)
//
//  Cria menus personalizados que aparecem no !menu do bot.
//
//  Uso simples em um comando:
//    import { createMenu, addToMenu, removeFromMenu } from '../../src/menuBuilder.js'
//
//    // Criar um menu customizado
//    createMenu('premium', '💎 Premium', 'Recursos exclusivos VIP')
//
//    // Adicionar comando ao menu
//    addToMenu('minhaferramenta', 'premium')
//
//  Uso em hook (adicionar ao menu no loadCommands):
//    export const hooks = []
//    export const onLoad = () => {
//      addToMenu('minhaferramenta', 'fun')
//    }
// ═══════════════════════════════════════════════════════════

import { menuTargetDB } from './database.js'

// ── Registro de menus customizados ────────────────────────
const _customMenus = new Map()

/**
 * createMenu — Registra um menu customizado
 * @param {string} id       — identificador (ex: 'premium', 'vip')
 * @param {string} label    — nome exibido (ex: '💎 Premium')
 * @param {string} desc     — descrição opcional
 */
export function createMenu(id, label, desc = '') {
  _customMenus.set(id, { id, label, desc, createdAt: new Date().toISOString() })
  return { id, label, desc }
}

export function removeCustomMenu(id) {
  return _customMenus.delete(id)
}

export function listCustomMenus() {
  return [..._customMenus.values()]
}

export function getCustomMenu(id) {
  return _customMenus.get(id) || null
}

// ── Menus padrão do sistema ───────────────────────────────
export const DEFAULT_MENUS = [
  { id: 'fun',    label: '🎮 Diversão',       desc: 'Jogos e entretenimento' },
  { id: 'info',   label: 'ℹ️ Informação',      desc: 'Pesquisa e dados' },
  { id: 'media',  label: '🎵 Mídia',           desc: 'Figurinhas, imagens, áudio' },
  { id: 'admin',  label: '🛡️ Administração',   desc: 'Moderação de grupos' },
  { id: 'owner',  label: '👑 Dono',            desc: 'Comandos do dono' },
  { id: 'rpg',    label: '⚔️ RPG',             desc: 'Sistema de RPG' },
  { id: 'jogos',  label: '🕹️ Jogos',           desc: 'Minigames' },
  { id: 'gold',   label: '🌟 Gold',            desc: 'Comandos Gold/VIP' },
  { id: 'misc',   label: '📦 Diversos',        desc: 'Outros comandos' },
]

// ── Atribuição de comandos a menus ────────────────────────

/**
 * addToMenu — Adiciona um comando a um ou mais menus
 * @param {string}          cmdName   — nome do comando (sem prefixo)
 * @param {string|string[]} menuIds   — id(s) do(s) menu(s)
 */
export function addToMenu(cmdName, menuIds) {
  const ids = Array.isArray(menuIds) ? menuIds : [menuIds]
  const current = menuTargetDB.get(cmdName, [])
  const merged  = [...new Set([...current, ...ids])]
  menuTargetDB.set(cmdName, merged)
  return merged
}

/**
 * removeFromMenu — Remove um comando de um ou mais menus
 */
export function removeFromMenu(cmdName, menuIds) {
  const ids = Array.isArray(menuIds) ? menuIds : [menuIds]
  const current = menuTargetDB.get(cmdName, [])
  const filtered = current.filter(m => !ids.includes(m))
  if (filtered.length === 0) {
    menuTargetDB.delete(cmdName)
  } else {
    menuTargetDB.set(cmdName, filtered)
  }
  return filtered
}

/**
 * setMenus — Define exatamente quais menus o comando aparece
 */
export function setMenus(cmdName, menuIds) {
  if (!menuIds || !menuIds.length) {
    menuTargetDB.delete(cmdName)
    return []
  }
  menuTargetDB.set(cmdName, [...new Set(menuIds)])
  return menuIds
}

/**
 * getMenusForCmd — Retorna em quais menus o comando está
 */
export function getMenusForCmd(cmdName) {
  return menuTargetDB.get(cmdName, [])
}

/**
 * getMenuTargets — Retorna todos os alvos de menus
 */
export function getMenuTargets() {
  return menuTargetDB.all()
}

/**
 * getAllMenus — Todos os menus (padrão + customizados)
 */
export function getAllMenus() {
  return [...DEFAULT_MENUS, ...listCustomMenus()]
}

/**
 * getCmdsInMenu — Retorna todos os comandos de um menu específico
 */
export function getCmdsInMenu(menuId) {
  const all = menuTargetDB.all()
  return Object.entries(all)
    .filter(([, menus]) => Array.isArray(menus) && menus.includes(menuId))
    .map(([name]) => name)
}
