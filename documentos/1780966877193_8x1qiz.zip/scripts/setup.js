#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════
//  Kaius Bot — Setup Wizard  (npm run config)
//  Guia interativo para configurar o .env do zero ou atualizar
// ═══════════════════════════════════════════════════════════
import readline from 'readline'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const ENV_PATH = path.join(ROOT, '.env')

// ── Cores ────────────────────────────────────────────────────
const C = {
  reset: '\x1b[0m', bold: '\x1b[1m', dim: '\x1b[2m',
  green: '\x1b[92m', cyan: '\x1b[96m', yellow: '\x1b[93m',
  red: '\x1b[91m', magenta: '\x1b[95m', white: '\x1b[97m',
  gray: '\x1b[90m', blue: '\x1b[94m',
}
const clr = (color, txt) => `${C[color]}${txt}${C.reset}`
const bold = (txt) => clr('bold', txt)

// ── Input helpers ─────────────────────────────────────────────
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })

const ask = (q, def = '') => new Promise(res => {
  const defStr = def ? clr('gray', ` (${def})`) : ''
  rl.question(`  ${clr('cyan','?')} ${clr('white', q)}${defStr}: `, a => {
    res(a.trim() || def)
  })
})

const askBool = async (q, def = true) => {
  const ans = await ask(`${q} ${clr('gray', def ? '[S/n]' : '[s/N]')}`, def ? 's' : 'n')
  return ans.toLowerCase().startsWith('s')
}

const askSecret = (q, current = '') => new Promise(res => {
  const hint = current ? clr('gray', ` (Enter = manter atual)`) : ''
  process.stdout.write(`  ${clr('cyan','?')} ${clr('white', q)}${hint}: `)
  let buf = ''
  const raw = process.stdin.isTTY
  if (raw) process.stdin.setRawMode(true)
  process.stdin.resume()
  const handler = (ch) => {
    const c = ch.toString()
    if (c === '\r' || c === '\n') {
      if (raw) process.stdin.setRawMode(false)
      process.stdin.removeListener('data', handler)
      process.stdout.write('\n')
      res(buf || current)
    } else if (c === '\x7f') {
      buf = buf.slice(0, -1)
    } else if (c === '\x03') {
      process.exit()
    } else {
      buf += c
      process.stdout.write('*')
    }
  }
  process.stdin.on('data', handler)
})

// ── UI ────────────────────────────────────────────────────────
function banner() {
  console.clear()
  console.log(`
${clr('green', bold('  ╔══════════════════════════════════════════════════╗'))}
${clr('green', bold('  ║'))}  ${clr('cyan', bold('✦  Kaius Bot'))} ${clr('white','— Assistente de Configuração')}  ${clr('green', bold('  ║'))}
${clr('green', bold('  ╚══════════════════════════════════════════════════╝'))}
  ${clr('gray', 'Pressione Enter para manter o valor atual.')}
  ${clr('gray', 'Ctrl+C para cancelar a qualquer momento.')}
`)
}

function section(title, desc = '') {
  console.log(`\n  ${clr('yellow', bold(`── ${title} ${'─'.repeat(Math.max(0, 44 - title.length))}`))}`)
  if (desc) console.log(`  ${clr('gray', desc)}\n`)
  else console.log()
}

function status(label, ok, detail = '') {
  const sym = ok ? clr('green', '✔') : clr('yellow', '⚠')
  const det = detail ? clr('gray', ` — ${detail}`) : ''
  console.log(`  ${sym} ${label}${det}`)
}

function link(url) { return clr('blue', url) }

// ── Ler .env existente ────────────────────────────────────────
let current = {}
if (fs.existsSync(ENV_PATH)) {
  fs.readFileSync(ENV_PATH, 'utf-8').split('\n').forEach(line => {
    const idx = line.indexOf('=')
    if (idx > 0 && !line.startsWith('#')) {
      const k = line.slice(0, idx).trim()
      const v = line.slice(idx + 1).trim()
      if (k) current[k] = v
    }
  })
  console.log(`\n  ${clr('green', '✔')} .env existente carregado — campos em branco mantêm valor atual`)
}

// ════════════════════════════════════════════════════════════
async function main() {
  banner()

  // ── 1. WhatsApp ──────────────────────────────────────────
  section('WhatsApp & Identidade', 'Configurações básicas do bot')

  const selfBot = await askBool(
    'É self-bot? (você usa o WhatsApp do bot como dono)',
    current.SELF_BOT === 'true'
  )

  let owner = current.OWNER_NUMBER || ''
  if (!selfBot) {
    owner = await ask('Número do dono (DDI + DDD + número, sem + ou espaços)', owner)
    if (owner && !owner.match(/^\d{10,15}$/)) {
      console.log(`  ${clr('yellow', '⚠')} Formato esperado: 5511999999999`)
    }
  } else {
    console.log(`  ${clr('green', '✔')} Self-bot: número detectado automaticamente ao iniciar\n`)
  }

  const prefix = await ask('Prefixo dos comandos', current.PREFIX || '!')
  const nome   = await ask('Nome do bot', current.BOT_NAME || 'Kaius')

  // ── 2. IA ─────────────────────────────────────────────────
  section('Inteligência Artificial', `Chave gratuita em: ${link('https://console.groq.com')}`)

  const groqKey = await askSecret('Groq API Key', current.GROQ_API_KEY || '')
  const modelo  = await ask('Modelo Groq', current.GROQ_MODEL || 'llama-3.3-70b-versatile')

  console.log(`\n  ${clr('gray', 'Modelos disponíveis:')}`)
  console.log(`  ${clr('gray', '  llama-3.3-70b-versatile  (recomendado — inteligente)')}`)
  console.log(`  ${clr('gray', '  llama-3.1-8b-instant      (rápido — menor RAM Groq)')}`)
  console.log(`  ${clr('gray', '  mixtral-8x7b-32768        (bom para código)')}`)

  const geminiKey = await askSecret(
    'Gemini API Key (opcional)',
    current.GEMINI_API_KEY || ''
  )
  if (geminiKey && geminiKey !== current.GEMINI_API_KEY) {
    console.log(`  ${clr('gray', 'Obtenha em: ' + link('https://aistudio.google.com/apikey'))}`)
  }

  const personality = await ask(
    'Personalidade do bot (system prompt)',
    current.BOT_PERSONALITY || `Você é ${nome}, um assistente inteligente e direto. Responda em português do Brasil.`
  )

  // ── 3. Painel Web ──────────────────────────────────────────
  section('Painel Web (Dashboard)')

  const dashPort = await ask('Porta do painel', current.DASHBOARD_PORT || '3000')
  const dashPass = await askSecret(
    'Senha do painel (deixe vazio para sem autenticação)',
    current.DASHBOARD_PASS || ''
  )
  if (!dashPass) {
    console.log(`  ${clr('yellow', '⚠')} Painel sem senha — não exponha na internet sem HTTPS!`)
  }

  // ── 4. GitHub ──────────────────────────────────────────────
  section('GitHub', 'Configure para sync automático com repositório (opcional)')

  const githubRepo  = await ask('URL do repositório (ex: https://github.com/user/kaius.git)', current.GITHUB_REPO || '')
  let githubToken = current.GITHUB_TOKEN || ''
  let autoUpdate  = current.AUTO_UPDATE === 'true'
  let autoUpload  = current.AUTO_UPLOAD === 'true'

  if (githubRepo) {
    githubToken = await askSecret('Token GitHub (para push)', githubToken)
    autoUpdate  = await askBool('Verificar updates automáticos a cada 6h?', autoUpdate)
    autoUpload  = await askBool('Publicar novos comandos no GitHub automaticamente?', autoUpload)
  }

  // ── 5. APIs Extras ─────────────────────────────────────────
  section('APIs Extras', 'Todas opcionais — deixe vazio para pular')

  const weatherKey  = await askSecret('OpenWeatherMap Key (comando !clima)', current.WEATHER_KEY || '')
  const newsKey     = await askSecret('NewsAPI Key (comando !noticias) — newsapi.org', current.NEWS_KEY || '')

  // ── 6. Comportamento ───────────────────────────────────────
  section('Comportamento & Performance')

  const antiSpam    = await askBool('Ativar anti-spam?', current.ANTI_SPAM !== 'false')
  const iaDefault   = await askBool('IA ativada em grupos por padrão?', current.IA_DEFAULT === 'true')
  const autoCode    = await askBool('Detector de código JS no chat?', current.AUTO_CODE_DETECT !== 'false')
  const codeOwnerOnly = autoCode
    ? await askBool('Detector só para o dono?', current.CODE_DETECT_OWNER_ONLY !== 'false')
    : false
  const dashAI      = await askBool('Gerador de comandos com IA no painel?', current.DASHBOARD_AI !== 'false')

  // ── Gerar .env ─────────────────────────────────────────────
  const repoWithToken = githubToken && githubRepo
    ? githubRepo.replace('https://', `https://${githubToken}@`)
    : githubRepo

  const env = `# ╔══════════════════════════════════════════╗
# ║      Kaius Bot — Configuração            ║
# ║   Gerado por: npm run config             ║
# ╚══════════════════════════════════════════╝

# ── WhatsApp ───────────────────────────────────────────────
OWNER_NUMBER=${owner}
PREFIX=${prefix}
BOT_NAME=${nome}
SELF_BOT=${selfBot}

# ── IA ─────────────────────────────────────────────────────
# Chave gratuita: https://console.groq.com
GROQ_API_KEY=${groqKey}
GROQ_MODEL=${modelo}
BOT_PERSONALITY=${personality}
# Gemini (opcional): https://aistudio.google.com/apikey
GEMINI_API_KEY=${geminiKey}

# ── Painel Web ─────────────────────────────────────────────
# Acesse em http://localhost:${dashPort}
DASHBOARD_PORT=${dashPort}
# ⚠️ Defina uma senha forte se exposto na internet
DASHBOARD_PASS=${dashPass}
DASHBOARD_AI=${dashAI}

# ── GitHub ─────────────────────────────────────────────────
GITHUB_REPO=${githubRepo}
GITHUB_REPO_WITH_TOKEN=${repoWithToken}
GITHUB_TOKEN=${githubToken}
AUTO_UPDATE=${autoUpdate}
AUTO_UPLOAD=${autoUpload}

# ── Detector de Código ─────────────────────────────────────
AUTO_CODE_DETECT=${autoCode}
CODE_DETECT_OWNER_ONLY=${codeOwnerOnly}

# ── APIs Extras ────────────────────────────────────────────
# openweathermap.org (gratuito)
WEATHER_KEY=${weatherKey}
# newsapi.org (gratuito)
NEWS_KEY=${newsKey}

# ── Comportamento ──────────────────────────────────────────
ANTI_SPAM=${antiSpam}
IA_DEFAULT=${iaDefault}
`

  fs.writeFileSync(ENV_PATH, env)
  rl.close()

  // ── Resumo ─────────────────────────────────────────────────
  console.log(`\n  ${clr('green', bold('╔══════════════════════════════════════════╗'))}`)
  console.log(`  ${clr('green', bold('║'))}   ${clr('white', bold('✔  .env salvo com sucesso!'))}              ${clr('green', bold('║'))}`)
  console.log(`  ${clr('green', bold('╚══════════════════════════════════════════╝'))}\n`)

  status('Bot', !!owner || selfBot,
    selfBot ? 'self-bot (número automático)' : (owner || 'OWNER_NUMBER não configurado'))
  status('IA Groq', !!groqKey,
    groqKey ? modelo : clr('red', 'GROQ_API_KEY vazia — IA não funcionará'))
  status('IA Gemini', !!geminiKey, geminiKey ? 'configurada' : 'não configurada (opcional)')
  status('Dashboard', true,
    `${link(`http://localhost:${dashPort}`)}${dashPass ? ' (com senha)' : clr('yellow', ' (sem senha!)')}`)
  status('GitHub', !!githubRepo, githubRepo || 'não configurado')
  status('Auto-update', autoUpdate && !!githubRepo, autoUpdate ? 'a cada 6h' : 'desativado')

  console.log(`\n  ${clr('gray', 'Para iniciar: ')}${clr('cyan', 'npm start')}`)
  console.log(`  ${clr('gray', 'Para editar:  ')}${clr('cyan', 'npm run config')}\n`)
}

main().catch(e => {
  console.error('\n  ' + clr('red', 'Erro: ') + e.message)
  rl.close()
  process.exit(1)
})
