# 🔌 Kaius v35 — Hooks, Eventos, Cron e Lembretes

Referência completa do sistema de automação proativa do bot.
Tudo aqui funciona **sem precisar que alguém mande mensagem**.

---

## 1. Hooks de Mensagem

Interceptam cada mensagem **antes** dos comandos.
Retornar `true` bloqueia o processamento do comando.

```js
// src/commands/admin/meu_hook.js
export const hooks = [{
  id:         'anti-palavrao',    // ID único — duplicatas são substituídas
  name:       'Anti Palavrão',   // Nome exibido no painel
  priority:   10,                 // Menor = executa primeiro
  onlyGroups: true,               // Só roda em grupos
  // onlyPrivate: true            // Só roda em privado
  // groups: ['120363xxx@g.us']  // Lista de grupos específicos (vazio = todos)
  // match: /palavrão|feio/i     // Atalho de filtro por texto (RegExp ou string)

  handle: async ({ sock, msg, from, userId, usuario, texto, reply, react, membros, isGrupo }) => {
    if (!/\bfeio\b/i.test(texto)) return   // não intercepta

    await react('⚠️')
    await reply(`${usuario}, cuide as palavras!`)
    return true  // bloqueia o comando que viria depois
  }
}]

export default []  // sem comandos neste arquivo
```

### Campos disponíveis no `ctx` do hook

| Campo | Tipo | Descrição |
|---|---|---|
| `sock` | object | Socket Baileys |
| `msg` | object | Mensagem raw do Baileys |
| `from` | string | JID do chat (grupo ou privado) |
| `userId` | string | JID de quem enviou (pode ser `@lid`) |
| `usuario` | string | Nome do remetente (pushName) |
| `texto` | string | Texto da mensagem |
| `isGrupo` | boolean | True se for grupo |
| `nomeGrupo` | string\|null | Nome do grupo |
| `membros` | array | Participantes do grupo |
| `args` | string[] | Palavras após a primeira |
| `reply(text)` | fn | Responde com citação |
| `react(emoji)` | fn | Reage à mensagem |
| `mention(jid, text)` | fn | Envia menção |

---

## 2. Sistema de Eventos Pub/Sub

Ouça eventos internos do bot (conexão, entrada/saída de grupo, comandos).

```js
import { onEvent, emitEvent, EVENTS } from '../../src/hooks.js'

// Ouvir evento
onEvent(EVENTS.GROUP_JOIN, 'meu-listener-boas-vindas', async ({ jid, groupJid, sock }) => {
  await sock.sendMessage(groupJid, {
    text: `Bem-vindo(a) ao grupo! 🎉`,
    mentions: [jid]
  })
})

// Emitir evento customizado (outros hooks podem ouvir)
await emitEvent('meu.evento', { dados: 'aqui' })
```

### Eventos disponíveis (`EVENTS`)

| Constante | String | Quando dispara |
|---|---|---|
| `EVENTS.MESSAGE` | `message` | Toda mensagem recebida |
| `EVENTS.COMMAND` | `command` | Após um comando ser executado |
| `EVENTS.GROUP_JOIN` | `group.join` | Membro entrou no grupo |
| `EVENTS.GROUP_LEAVE` | `group.leave` | Membro saiu/foi removido |
| `EVENTS.CONNECT` | `bot.connect` | Bot conectou ao WhatsApp |
| `EVENTS.DISCONNECT` | `bot.disconnect` | Bot desconectou |
| `EVENTS.RELOAD` | `cmd.reload` | Comandos recarregados |

---

## 3. Cron Jobs — Tarefas Temporizadas

O bot age **proativamente** sem depender de mensagens.
O motor cron só dispara **após `connection.open`** — nunca antes.

```js
// src/commands/owner/avisos.js
import { addCronJob } from '../../src/cron.js'

// Bom dia de seg–sex às 08:00
addCronJob({
  id:      'bom-dia',            // ID único e estável
  name:    'Bom dia automático',
  time:    '08:00',
  days:    [1, 2, 3, 4, 5],     // 0=Dom 1=Seg ... 6=Sáb  ([] = todo dia)
  enabled: true,
  targets: ['120363xxx@g.us'],   // apenas referência; use no handle

  handle: async ({ sock, id, hhmm }) => {
    await sock.sendMessage('120363xxx@g.us', {
      text: `🌅 Bom dia! São ${hhmm} ☀️`
    })
  }
})

// A cada 30 minutos
addCronJob({
  id:              'aviso-30min',
  name:            'Aviso periódico',
  intervalMinutes: 30,
  handle: async ({ sock }) => { /* ... */ }
})

// Num dia específico, uma vez
addCronJob({
  id:     'ano-novo',
  name:   'Feliz Ano Novo',
  time:   '00:00',
  date:   '2025-12-31',
  once:   true,
  handle: async ({ sock }) => {
    await sock.sendMessage('grupo@g.us', { text: '🎆 Feliz Ano Novo!' })
  }
})

export default []
```

> **Atenção:** `addCronJob` em arquivo de comando é chamado a cada `!reload`.
> Use sempre **IDs fixos e descritivos** — o sistema substitui duplicatas automaticamente.
> O `_lastRun` do job é preservado entre reconexões para evitar disparo duplo.

---

## 4. Lembretes com @menção

API de alto nível sobre o cron, com suporte a variáveis e menções.

```js
import { addReminder } from '../../src/reminders.js'

// @todos às 09h, seg–sex
addReminder({
  label:    'Standup diário',
  jid:      '120363xxx@g.us',
  text:     '📋 *Standup* — {diaSemana} {data} às {hora}\nO que fiz? O que farei? Algum impedimento?',
  time:     '09:00',
  days:     [1, 2, 3, 4, 5],
  mentions: ['all'],            // @todos do grupo
  repeat:   true,
})

// Pessoas específicas
addReminder({
  label:    'Reunião',
  jid:      '120363xxx@g.us',
  text:     'Reunião em 10min! ⏰',
  time:     '14:50',
  days:     [3],               // Quarta
  mentions: ['5511999999999', '5511888888888'],
  repeat:   true,
})

// Intervalo sem menção
addReminder({
  label:           'Água',
  jid:             '5511999@s.whatsapp.net',
  text:            '💧 Hora de beber água!',
  intervalMinutes: 120,
  repeat:          true,
})
```

> Se o bot for **removido do grupo**, o lembrete é **desativado automaticamente** (erro 403).
> Reative no painel em **Lembretes & Cron** se quiser usar novamente.

### Variáveis no texto

| Variável | Exemplo |
|---|---|
| `{hora}` | `08:00` |
| `{data}` | `19/05` |
| `{diaSemana}` | `Terça` |
| `{mes}` | `Mai` |
| `{ano}` | `2025` |
| `{emoji_dia}` | `💼` (muda por dia) |

---

## 5. Menus — atribuir comandos

```js
import { addToMenu, removeFromMenu, createMenu, setMenus } from '../../src/menuBuilder.js'

addToMenu('ping', 'core')                // adicionar a um menu
addToMenu('ping', ['core', 'info'])      // múltiplos de vez
setMenus('ping', ['core', 'info'])       // substitui todos os anteriores
removeFromMenu('ping', 'info')           // remover de um menu

// Menu customizado
createMenu('premium', '💎 Premium', 'Recursos VIP')
addToMenu('meucomandovip', 'premium')
```

Também disponível visualmente em **Painel → Menus → Atribuir Comandos**.

---

## 6. Donos e LID (WhatsApp Multi-Device)

No WhatsApp Multi-Device, alguns usuários aparecem com identificador interno (`@lid`) em vez de número de telefone.

### Como adicionar um LID como dono

**Via painel** (recomendado):
1. Painel → **Sistema → Gerenciar Donos → Adicionar**
2. Cole o LID exibido no terminal: `[Dono/LID] userId detectado: 1234567890@lid`
3. O bot reconhece imediatamente, sem reiniciar

**Via `.env`:**
```
OWNER_NUMBER=5511999999999,1234567890@lid
```

**Via código:**
```js
import { CONFIG } from './src/config.js'
CONFIG.owner = '5511999999999,1234567890@lid'
```

> O sistema mescla `CONFIG.owner` com `OWNER_NUMBER` do env — ambas as fontes são válidas simultaneamente.

---

## 7. API REST (automações externas)

```bash
BASE="http://localhost:3000"
TOKEN="sua-senha"

# Criar lembrete
curl -X POST $BASE/api/reminders \
  -H "Content-Type: application/json" -H "x-token: $TOKEN" \
  -d '{"label":"Aviso","jid":"120363@g.us","text":"Reunião!","time":"15:00","days":[1,2,3,4,5],"mentions":["all"],"repeat":true}'

# Testar lembrete agora
curl -X POST $BASE/api/reminders/ID/test -H "x-token: $TOKEN"

# Listar/executar cron jobs
curl $BASE/api/cron -H "x-token: $TOKEN"
curl -X POST $BASE/api/cron/JOB_ID/run -H "x-token: $TOKEN"

# Atribuir comando a menus
curl -X POST $BASE/api/menus/assign \
  -H "Content-Type: application/json" -H "x-token: $TOKEN" \
  -d '{"cmdName":"ping","menuIds":["core","info"]}'

# Adicionar dono (suporta LID)
curl -X POST $BASE/api/owner/add \
  -H "Content-Type: application/json" -H "x-token: $TOKEN" \
  -d '{"num":"1234567890@lid"}'
```

---

## 8. Boas práticas

1. **IDs únicos** — use nomes descritivos: `bom-dia-grupo-principal`
2. **Reconexão segura** — `_lastRun` é preservado; jobs de intervalo não disparam duplo após reconexão
3. **Cron só roda após connection.open** — nenhum job dispara com socket desconectado
4. **`@all` só funciona em grupos** — em privado não tem efeito
5. **`days: []`** = todo dia; `days: [1,2,3,4,5]` = seg–sex; `days: [0,6]` = fim de semana
6. **Prioridade de hooks** — menor número = executa primeiro; `priority: 1` roda antes de `priority: 50`
7. **Lembrete 403** — se o bot sair do grupo, o lembrete é desativado automaticamente para não poluir o log
8. **Webhooks externos** — configure em **Painel → Hooks → Super Hooks** para receber eventos em qualquer URL
